<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 17/03/16
 * Time: 12:38
 */
namespace App\User\userRegister\model;
use Zero\eventHandler\eventHandler;
class userRegister extends eventHandler
{
    protected $uId;
    protected $aadharNo;
    protected $eMail;
    protected $Contact;
    protected $Name;
    public function handleEvent()
    {

    }
    public function secureHandler()
    {

    }
    public function arrayRelationMap()
    {
    return array(   'u_id'=>'uId',
                    'aadhaar_no'=>'aadharNo',
                    'e_mail'=>'eMail',
                    'contact'=>'Contact',
                    'username'=>'Name',
                    'imei'=>'Imei'
                );
    }
    public function dbTableName()
    {
        return 'user';
    }

}