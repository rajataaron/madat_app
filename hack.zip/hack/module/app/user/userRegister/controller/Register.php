<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 17/03/16
 * Time: 21:52
 */
namespace App\User\userRegister\controller;
use App\User\userRegister\model\userRegister;
class Register extends userRegister
{
    public function handleEvent()
    {
        $this->query="INSERT INTO {$this->dbTableName()} (aadhaar_no,e_mail,password,contact,username,imei) VALUES (:0,:1,:2,:3,:4,:5)";
        $st=$this->runExecute($this->aadhar,$this->email,$this->aadhar,$this->phone,$this->name,$this->imei);
            $this->query = "SELECT aadhaar_no FROM {$this->dbTableName()} WHERE aadhaar_no=:0";
            $st=$this->runExecute($this->aadhar);
            $res=$st->fetch(\PDO::FETCH_ASSOC);
        echo json_encode(array('aadhar'=>$this->aadhar));
    }
    public function secureHandler()
    {
       $str=substr($this->qrCode,64);
        $val=(explode('"',$str));
            $this->aadhar = $val[1];
        $this->handleEvent();
    }
}