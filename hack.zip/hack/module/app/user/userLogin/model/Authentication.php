<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 06:04
 */
namespace App\user\userLogin\model;
use Zero\eventHandler\eventHandler;
class Authentication extends eventHandler
{
    protected $uId;
    protected $aadharNo;
    protected $eMail;
    public function handleEvent()
    {
        // TODO: Implement handleEvent() method.
    }
    public function secureHandler()
    {
        // TODO: Implement secureHandler() method.
    }
    public function arrayRelationMap()
    {
        return array('u_id' => 'uId',
            'aadhaar_no' => 'aadharNo',
            'e_mail' => 'eMail',
            'password'=>'Password',
            'contact' => 'Contact',
            'username' => 'Name',
            'imei' => 'Imei'
        );
    }
    public function dbTableName()
    {
        return 'user';
    }
}