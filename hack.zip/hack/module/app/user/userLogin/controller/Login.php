<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 06:12
 */
namespace App\user\userLogin\controller;
use App\user\userLogin\model\Authentication;
class Login extends Authentication
{
    public function handleEvent()
    {

    }
    public function secureHandler()
    {
        $this->query="SELECT * FROM {$this->dbTableName()} WHERE e_mail=:0 AND password=:1";
        $st=$this->runExecute($this->email,$this->password);
        if($st->rowCount()>0)
        {
            $res=$st->fetch(\PDO::FETCH_ASSOC);
            echo json_encode(array('state'=>1,'aadhar'=>$res['aadhaar_no']));
        }
        else
        {
            echo json_encode(array('state'=>0));
        }
    }
}