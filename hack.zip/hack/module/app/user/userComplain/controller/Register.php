<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 04:07
 */
namespace App\User\userComplain\controller;
use App\User\userComplain\model\Complain;
class Register extends Complain
{
    public function handleEvent()
    {
        $this->query="SELECT u_id FROM user WHERE aadhaar_no=:0";
        $st=$this->runExecute($this->aadhar);
        if($st->rowCount()>0)
        {
            $res=$st->fetch(\PDO::FETCH_ASSOC);
            $this->query="INSERT INTO complain (u_id,subject,message,x_coor,y_coor) VALUES (:0,:1,:2,:3,:4)";
            $st=$this->runExecute((int)$res['u_id'],$this->sub,$this->msg,(string)$this->xCo,(string)$this->yCo);
            echo json_encode(array('state'=>1));
        }
    }
    public function secureHandler()
    {
        $this->handleEvent();
    }
}