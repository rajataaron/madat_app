<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 06:43
 */
namespace App\user\userComplain\controller\emergency;
use App\User\userComplain\model;
class emergency extends model\Complain
{
    public function handleEvent()
    {

    }
    public function secureHandler()
    {
    $this->query="SELECT u_id FROM user WHERE aadhaar_no=:0";
    $st=$this->runExecute($this->aadhar);
    if($st->rowCount()>0)
    {
     $res=$st->fetch(\PDO::FETCH_ASSOC);
     $this->query="INSERT INTO complain (u_id,x_coor,y_coor) VALUES (:0,:1,:2)";
     $st=$this->runExecute((int)$res['u_id'],(string)$this->xCo,(string)$this->yCo);
     echo json_encode(array('state'=>1));
    }
    }
}