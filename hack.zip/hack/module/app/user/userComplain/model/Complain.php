<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 02:27
 */
namespace App\User\userComplain\model;
use Zero\eventHandler\eventHandler;
class Complain extends eventHandler
{
    public function handleEvent()
    {
        // TODO: Implement handleEvent() method.
    }
    public function secureHandler()
    {
        // TODO: Implement secureHandler() method.
    }
    public function arrayRelationMap()
    {
        return array(
            'u_id'=>'uId',
            'complain_id'=>'ComplainId',
            'subject'=>'Subject',
            'file'=>'File',
            'status'=>'Status',
            'x_coor'=>'xCoor',
            'y_coor'=>'yCoor');
    }
    public function dbTableName()
    {
        return 'user';
    }
}