<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:46
 */
namespace App\police\policeDuty\controller\crimeLocation;
interface crimeLocationInterface
{
    public function getLatitude();
    public function getLongitude();
    public function getuserId();
}