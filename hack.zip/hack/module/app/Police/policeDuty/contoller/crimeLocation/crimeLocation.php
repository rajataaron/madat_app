<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:47
 */
namespace App\police\policeDuty\controller\crimeLocation;
use App\police\policeDuty\model\crimeLocation as crimeModal;
class crimeLocation extends crimeModal\crimeLocation implements crimeLocationInterface
{
    public function getLatitude()
    {
    $this->query="SELECT * FROM {$this->dbTableName()} WHERE";
    }
    public function getLongitude()
    {
        // TODO: Implement getLongitude() method.
    }
    public function getuserId()
    {
        // TODO: Implement getuserId() method.
    }

}
