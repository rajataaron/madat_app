<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:46
 */
namespace App\police\policeDuty\controller\policeLocation;
use App\police\policeDuty\controller\crimeLocation\crimeLocation;
use App\police\policeDuty\model\policeLocation\policeLocation as police;
class policeLocation extends police implements policeLocationInterface
{
    protected $clients;
    public function __construct($dispatcher, $data)
    {
        parent::__construct($dispatcher, $data);

    }
    public function getLocation(crimeLocation $coon)
    {
        // TODO: Implement getLocation() method.
    }
    public function getimei()
    {
        // TODO: Implement getimei() method.
    }
    public function assign()
    {

    }
    public function subtract()
    {

    }
}