<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:46
 */
namespace App\police\policeDuty\controller\policeLocation;
use App\police\policeDuty\controller\crimeLocation\crimeLocation;
interface policeLocationInterface
{
    public function getLocation(crimeLocation $coon);
    public function getimei();
    public function assign();
    public function subtract();
}
