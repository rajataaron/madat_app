<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:59
 */
namespace App\police\policeDuty\model\policeLocation;
use Zero\eventHandler\eventHandler;
class policeLocation extends eventHandler
{
    protected $IMEI;
    protected $xCo;
    protected $yCo;
    protected $complainId;
    protected $uId;
    protected $Assigned;
    protected $aId;
    public function handleEvent()
    {
        // TODO: Implement handleEvent() method.
    }
    public function secureHandler()
    {
        // TODO: Implement secureHandler() method.
    }
    public function arrayRelationMap()
    {
        return array('imei'=>'IMEI',
            'x_coor'=>'xCo',
            'y_coor'=>'yCo'
        );
    }
    public function dbTableName()
    {
        return 'pcr';
    }
}