<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:59
 */
namespace App\police\policeDuty\model\crimeLocation;
use Zero\eventHandler\eventHandler;
class crimeLocation extends eventHandler
{
    protected $IMEI;
    protected $xCo;
    protected $yCo;
    protected $complainId;
    protected $uId;
    protected $Assigned;
    protected $aId;
    public function handleEvent()
    {
        // TODO: Implement handleEvent() method.
    }
    public function secureHandler()
    {
        // TODO: Implement secureHandler() method.
    }
    public function arrayRelationMap()
    {
        return array(
            'u_id'=>'uId',
            'complain_id'=>'ComplainId',
            'subject'=>'Subject',
            'file'=>'File',
            'status'=>'Status',
            'x_coor'=>'xCoor',
            'y_coor'=>'yCoor');
    }
    public function dbTableName()
    {
        return 'complain';
    }
}