<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 13:51
 */
namespace  App\police\Assign\controller;
use App\police\Assign\model\policeAssign as police;
class policeAssign extends police
{
    public function handleEvent()
    {

    }
    public function secureHandler()
    {
        $this->query="SELECT u_id,x_coor,y_coor FROM complain WHERE complain_id=:0";
        $st=$this->runExecute($this->com_id);
        $userOp=$st->fetch(\PDO::FETCH_ASSOC);
        $this->query="SELECT * FROM pcr";
        $qr=$this->runExecute();
        while($res=$qr->fetch(\PDO::FETCH_ASSOC)) {
            $this->query = "INSERT INTO assigned_to(u_id,imei,complain_id,x_coor,y_coor,assigned) VALUES (:0,:1,:2,:3,:4,:5)";
            $this->runExecute($userOp['u_id'],$res['imei'],$this->com_id,$res['x_coor'],$res['y_coor'],1);
        }
        echo json_encode(array('state'=>1));
    }
}