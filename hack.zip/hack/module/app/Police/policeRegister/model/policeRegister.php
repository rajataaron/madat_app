<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 17/03/16
 * Time: 12:36
 */
namespace App\police\policeRegister\model;

use Zero\eventHandler\eventHandler;

class policeRegister extends eventHandler
{
   protected $IMEI;
   protected $xCo;
   protected $yCo;
   public function handleEvent()
   {
       // TODO: Implement handleEvent() method.
   }
    public function secureHandler()
    {

    }
    public function arrayRelationMap()
    {
    return array('imei'=>'IMEI',
                  'x_coor'=>'xCo',
                  'y_coor'=>'yCo'
        );
    }
    public function dbTableName()
    {
        return 'pcr';
    }
}