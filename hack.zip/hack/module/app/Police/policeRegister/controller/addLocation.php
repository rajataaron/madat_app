<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 11:06
 */
namespace App\police\policeRegister\controller;
use App\police\policeRegister\model;
class addLocation extends model\policeRegister
{
    public function handleEvent()
    {

    }
    public function secureHandler()
    {
       $this->query="SELECT * FROM {$this->dbTableName()} WHERE imei=:0";
       $res=$this->runExecute($this->imei);
       if($res->rowCount()>0) {
           $this->query = "UPDATE {$this->dbTableName()} SET  x_coor=:0,y_coor=:1";
           $st = $this->runExecute((string)$this->data['xCo'], (string)$this->data['yCo']);
           echo json_encode(array('state'=>'1'));

       }
        else
        {
            $this->query = "INSERT INTO {$this->dbTableName()} (imei,x_coor,y_coor) VALUES (:0,:1,:2)";
            $st = $this->runExecute($this->imei, (string)$this->data['xCo'], (string)$this->data['yCo']);
            echo json_encode(array('state'=>'1'));
        }

    }
}