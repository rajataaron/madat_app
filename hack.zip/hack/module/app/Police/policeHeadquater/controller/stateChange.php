<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 18/03/16
 * Time: 01:00
 */
namespace App\Police\policeHeadquater\controller;
use App\Police\policeHeadquater\model\complains;
class stateChange extends complains
{
    public function handleEvent()
    {

    }
    public function secureHandler()
    {
        $this->query="UPDATE complain SET status=:0 WHERE complain_id=:1";
        $st=$this->runExecute((int)$this->state+1,$this->complain);
        if($st->rowCount()>0)
        {
            echo json_encode(array('complain_id'=>$this->complain,"state"=>(int)$this->state+1));
        }
    }
}