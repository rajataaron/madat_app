<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 17/03/16
 * Time: 19:24
 */
namespace App\Police\policeHeadquater\model;
use Zero\eventHandler\eventHandler;
class complains extends eventHandler
{
    protected $uId;
    protected $ComplainId;
    protected $Subject;
    protected $File;
    protected $Status;
    protected $xCoor;
    protected $yCoor;
    protected $aadharNo;
    protected $eMail;
    protected $Contact;
    protected $Name;
    protected $Imei;
    public function handleEvent()
    {
        foreach($this->member as $obj)
        {
           echo '<tr><td>'.$obj->complain_id.'</td>
                        <td>'.$obj->subject.'</td>
                        <td>'.$obj->contact.'</td>
                        <td>'.$obj->username.'</td>
                        <td>'.$obj->aadhaar_no.'</td>';
                     if($obj->status==0)
                        {
                      echo  '<td><a class="btn btn-square btn-default" data-complain="'.$obj->complain_id.'" data-state="'.$obj->status.'">Pending</a></td></tr>';
                        } if($obj->status==1)
                        {
                      echo  '<td><a class="btn btn-square btn-default" data-complain="'.$obj->complain_id.'" data-state="'.$obj->status.'">processing</a></td></tr>';
                        }if($obj->status==2)
                        {
                      echo  '<td><a class="btn btn-square btn-default" data-complain="'.$obj->complain_id.'" data-state="'.$obj->status.'">Closed</a></td></tr>';
                        }
        }
    }
    public function secureHandler()
    {
        $this->query="SELECT c.u_id,c.complain_id,c.subject,c.file,c.status,c.x_coor,c.y_coor,u.aadhaar_no,u.e_mail,u.contact,u.username,u.imei FROM complain c , user u WHERE u.u_id=c.u_id";
        $st=$this->runExecute();
        $i=0;
        while($res=$st->fetch(\PDO::FETCH_ASSOC))
        {
        $this->addItem(new complains('complain',$res),$i);
        $i++;
        }
    }
    public function arrayRelationMap()
    {
    return array('u_id'=>'uId',
                'complain_id'=>'ComplainId',
                'subject'=>'Subject',
                'file'=>'File',
                'status'=>'Status',
                'x_coor'=>'xCoor',
                'y_coor'=>'yCoor',
                'aadhaar_no'=>'aadharNo',
                'e_mail'=>'eMail',
                'contact'=>'Contact',
                'username'=>'Name',
                'imei'=>'Imei'
                );
    }
    public function dbTableName()
    {
    return 'complain';
    }
}
