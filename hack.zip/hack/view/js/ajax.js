/**
 * Created by niteshkumar on 17/03/16.
 */
window.addEventListener("load",function(){
    policeStation.start();
    xml.selectors();
});
var policeStation={
  start : function()
  {
    var btn=document.querySelectorAll("table tbody .btn");
    for(var i=0;i<btn.length;i++) {
        btn[i].addEventListener("click", function (e) {
            var dataset= e.target.dataset;
            if(dataset.state<2) {
                this.changeState(dataset.complain, e, dataset.state);
            }
        }.bind(this));
    }
  },
   changeState:function(complain,e,val)
    {

        Request.url="../index.php";
        Request.method="POST";
        Request.req=JSON.stringify({complainId:complain,req:"Complain",val:val});
        Request.encode="JSON";
        Request.createRequest({
        open : function(state)
            {

            },
            loading:function(state)
            {

            },
            progress :function(state)
            {

            },
            load : function(state)
            {
                var data=JSON.parse(state.responseText);
                e.target.setAttribute('data-complain',data.complain_id);
                e.target.setAttribute('data-state',data.state);
                if(data.state==1) {
                    e.target.innerHTML = "Processing";
                    policeStation.addStation(data.complain_id);
                }
                else if(data.state==2)
                    e.target.innerHTML="Closed";
            },
            error : function(state)
            {

            }
        });
    },
    addStation : function(complain)
    {
        Request.url="../index.php";
        Request.method="POST";
        Request.req=JSON.stringify({complainId:complain,req:"ComplainAssign"});
        Request.encode="JSON";
        Request.createRequest({
            open : function(state)
            {

            },
            loading:function(state)
            {

            },
            progress :function(state)
            {

            },
            load : function(state)
            {

            },
            error : function(state)
            {

            }
        });
    }
};
var Request= {
    req: '',
    url: '',
    method: '',
    reqType:{urlEncode:"Content-type,application/x-www-form-urlencoded",form:''},
    encode:'',
    createRequest: function (callback) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function (e) {
            switch (xhr.readyState) {
                case 0 :
                    callback.open(xhr);
                    break;
                case 1:
                    callback.loading(xhr);
                    break;
                case 2 :
                    callback.progress(xhr);
                    break;
                case 3 :
                    callback.progress(xhr);
                    break;
                case 4 :
                    callback.load(xhr);
                    break;
                default :
                    callback.error(-1);
                    break;
            }
        };
        xhr.open(this.method, this.url, true);
        if(this.encode=='urlEncode') {
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        }
        if(this.encode=="JSON") {
            xhr.setRequestHeader("Content-type", "application/json");
        }
        xhr.send(this.req);
    },
    setRequest : function()
    {
        var string='';
        for(var i=1;i<=arguments.length;i++)
        {
            string +='request'+i+'='+arguments[i-1]+'&'
        }
        this.req=string.substr(0,string.length-1);
    }
};
var xml={
    selectors : function()
    {
        var btn=document.querySelector(".page-header .right .btn");
        btn.addEventListener("click",function(e){
        this.changer();
        }.bind(this));
    },
    changer : function()
    {
        Request.url="../index.php";
        Request.method="POST";
        Request.req=JSON.stringify( {imei:'327811660516',req:"update",xCo:12.645,yCo:45.67});
        Request.encode="JSON";
        Request.createRequest({
            open : function(state)
            {

            },
            loading:function(state)
            {

            },
            progress :function(state)
            {

            },
            load : function(state)
            {

            },
            error : function(state)
            {

            }
        });
    }
};
