/**
 * Created by Nitesh on 21-05-2015.
 */
var arr2,arr3;
function init()
{
    var lat=arguments[0];
    var lng=arguments[1];
    var mapOptions={zoom:15,
        center:new google.maps.LatLng(lat, lng),
        scrollwheel:false,
        styles:[
            {featureType:"all",
                stylers:[{hue:"#E0F0FF"},{saturation:80}]},
            {featureType:"road",
                elementType:"geometry",
                stylers:[{lightness:100},{visibility:"standard"}]},
            {featureType:"road",
                elementType:"labels",
                stylers:[{visibility:"off"}]}
        ],mapTypeId: google.maps.MapTypeId.ROADMAP};
    var map=new google.maps.Map(document.getElementById("modification"),mapOptions);
    setMarker(map,lat,lng);

}
function sendData(lat,lng)
{
    arr2=lat;
    arr3=lng;
    init(lat,lng);
}
function setMarker(map,lat,lng)
{
    var myLatLng=new google.maps.LatLng(lat, lng);
    var marker=new google.maps.Marker({
        position:myLatLng,
        map:map,
        draggable: true
    });
   /* var contentString='<div id="title">'+
        '<h4>Credance Infotech Pvt.Ltd.</h4>'+
        '</div>';
    var infoWindow=new google.maps.InfoWindow({
        content:contentString,
        maxWidth:300
    });
    google.maps.event.addListener(marker,'mouseover',function(){
        infoWindow.open(map,marker);
    });
    google.maps.event.addListener(marker,'mouseout',function()
    {
        infoWindow.close();
    });*/
    google.maps.event.addListener(marker,'dragstart',function(event)
    {
//alert(event.latLng);
    });
    google.maps.event.addListener(marker,'dragend',function(event)
    {
        var lats=event.latLng;
        var arr=lats.toString();
        var arr1=arr.split(",");
        arr2=arr1[0].substr(1,arr1[0].length);
        arr3=arr1[1].substr(0,arr1[1].length-1);
    });
}