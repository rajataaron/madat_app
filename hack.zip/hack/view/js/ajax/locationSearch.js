/**
 * Created by niteshkumar on 26/10/15.
 */
var marker=null;
function Location()
{
    this.geocoader=new google.maps.Geocoder();
    this.Maps=null;
    this.lat=arguments[0];
    this.lng=arguments[1];
}
Location.prototype.initialize = function()
    {
        var mapOptions={zoom:15,
            center:new google.maps.LatLng(this.lat, this.lng),
            scrollwheel:false,
            styles:[
                {featureType:"all",
                    stylers:[{hue:"#E0F0FF"},{saturation:80}]},
                {featureType:"road",
                    elementType:"geometry",
                    stylers:[{lightness:100},{visibility:"standard"}]},
                {featureType:"road",
                    elementType:"labels",
                    stylers:[{visibility:"off"}]}
            ],mapTypeId: google.maps.MapTypeId.ROADMAP};
        this.Maps=new google.maps.Map(document.getElementById("modification"),mapOptions);
    };
Location.prototype.CreateMarker=function(map,loc,result)
{
    if (marker && marker.getMap) marker.setMap(map);
    marker = new google.maps.Marker({
        map: map,
        position: loc,
        draggable: true
    });
    result(marker)
};
Location.prototype.codeAddress=function(resource,callBack)
{
    var map=this.Maps;
    this.geocoader.geocode({address : resource},function(results,status){
        if(status == google.maps.GeocoderStatus.OK){
            map.setCenter(results[0].geometry.location);
            Location.prototype.CreateMarker.call(Location,map,results[0].geometry.location,function(m)
            {
                var lat=m.getPosition().lat();
                var lng=m.getPosition().lng();
                callBack(lat,lng);
                google.maps.event.addListener(m,'dragend',function(event)
                {
                    var latLng=event.latLng;
                    lat=latLng.lat();
                    lng=latLng.lng();
                    callBack(lat,lng);

                });
            });

        }
        else
        {
            alert("Error in location"+status);
        }
    });
};
