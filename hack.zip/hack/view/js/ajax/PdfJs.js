/**
 * Created by niteshkumar on 20/11/15.
 */
function PdfJs(Width,height,src)
{
    this.width=Width;
    this.height=height;
    this.src=src;
}
PdfJs.prototype={
    constructor:PdfJs,
    iframe : function()
    {
        var iframe = document.createElement("iframe");
        iframe.setAttribute("width",this.width);
        iframe.setAttribute("height",this.height);
        iframe.setAttribute("src",this.src);
        return iframe;
    }
};