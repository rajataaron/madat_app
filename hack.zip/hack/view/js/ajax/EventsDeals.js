/**
 * Created by niteshkumar on 25/11/15.
 */
function EventsDeals(header,base)
{
this.head=header;
this.base=base;
}
EventsDeals.prototype={
constructor : EventsDeals,
    createHeader : function()
    {
        var outerArea = document.createElement("div");
        outerArea.setAttribute("id","outer_area");
        outerArea.setAttribute("class","col-md-6 modify");
        var modification = document.createElement("div");
        modification.setAttribute("id","modification");
        modification.setAttribute("class","panel panel-default");
        var PanelTitle = document.createElement("div");
        PanelTitle.setAttribute("class","panel-title");
        PanelTitle.innerHTML="Fieldset";
        var panelBody = document.createElement("div");
        panelBody.setAttribute("class","panel-body");
        PanelTitle.appendChild(panelBody);
        modification.appendChild(PanelTitle);
        outerArea.appendChild(modification);
        var fieldset = document.createElement("fieldset");
        panelBody.appendChild(fieldset);
        var legend = document.createElement("legend");
        legend.innerHTML=this.head;
        fieldset.appendChild(legend);
        return [fieldset,outerArea];
    },
    createForm :function()
    {
        var form =document.createElement("form");
        form.setAttribute("id","outer_area");
        form.setAttribute("class","fieldset-form");
        form.setAttribute("enctype","multipart/form-data");
        return form;
    },
    createFormGroup : function(name,Box,placeholder,id,type,clas) {
            var form = document.createElement("div");
            form.setAttribute("class", clas);
            var label = document.createElement("label");
            label.setAttribute("for", name);
            label.setAttribute("class", "form-label");
            label.innerHTML = name;
            form.appendChild(label);
            var input = document.createElement(Box);
            if (Box == "input") {
                input.setAttribute("type", type);
            }
            input.setAttribute("class", "form-control");
            input.setAttribute("id", id);
            input.setAttribute("placeholder", placeholder.toUpperCase());
            if (type == "file") {
                input.setAttribute("accept", "image/*");
                input.setAttribute("required", "required");
            }
            if (type == "number") {
                input.setAttribute("min", 0);
            }
            form.appendChild(input);
            return [form,input];
    },
    SelectDropDown : function(id,clas,name)
    {
        var form = document.createElement("div");
        form.setAttribute("class","form-group");
        var label = document.createElement("label");
        label.setAttribute("for",name);
        label.setAttribute("class","form-label");
        label.innerHTML=name;
        form.appendChild(label);
        var select =document.createElement("select");
        select.setAttribute("id",id);
        form.appendChild(select);
        return [form,select];
    },
    createOption : function(select)
    {
        for(var i=0;i<arguments.length;i++)
        {
            var option=document.createElement("option");
            option.value=i;
            if(i==0) {
                option.innerHTML = "SELECT-SUPPORT";
            }
            else {
                option.innerHTML = arguments[i];
            }
            select.appendChild(option);
        }
    },
    createTextEditor : function(id,name)
    {
        var form = document.createElement("div");
        form.setAttribute("class", "form-group");
        var label = document.createElement("label");
        label.setAttribute("for", name);
        label.setAttribute("class", "form-label");
        label.innerHTML = name;
        form.appendChild(label);
        var note=document.createElement("div");
        note.setAttribute("id",id);
        form.appendChild(note);
        return form;
    },
    createSubmit : function(id,action,cl,type)
    {
        var button = document.createElement("button");
        button.setAttribute("id",id);
        button.setAttribute("class",cl);
        button.setAttribute("type",type);
        var i =document.createElement("i");
        i.setAttribute("class",arguments[4]);
        button.appendChild(i);
        var text=document.createTextNode(action);
        button.appendChild(text);
        return button;
    },
    createFormWitBtn : function(divId,name,Box,placeholder,id,type)
    {
        var form = document.createElement("div");
        form.setAttribute("id",divId);
        form.setAttribute("class","form-group");
        var label = document.createElement("label");
        label.setAttribute("for",name);
        label.setAttribute("class","form-label");
        label.innerHTML=name;
        form.appendChild(label);
        var input = document.createElement(Box);
        if (Box == "input") {
            input.setAttribute("type", type);
        }
        input.setAttribute("class", "form-control");
        input.setAttribute("id", id);
        input.setAttribute("placeholder", placeholder.toUpperCase());
        if(type=="file")
        {
            input.setAttribute("accept","image/*");
        }

        form.appendChild(input);
        form.appendChild(document.createElement("br"));
        var button=this.createButton("add-on","btn btn-option3 btn-xs","Add-Item","checkbox","fa fa-plus");
        form.appendChild(button);
        return [form,input,button];
    },
    createButton : function(id,cl,action,type)
    {
        var formGroup=document.createElement("div");
        formGroup.setAttribute("class","form-group");
        formGroup.setAttribute("id",id);
        var p=document.createElement("p");
        p.setAttribute("class","form-label");
        p.innerHTML="Multiple-Price";
        formGroup.appendChild(p);
        var label=document.createElement("label");
        label.setAttribute("for","Amount");
        label.setAttribute("class","checkbox-inline form-label");
        var input=document.createElement("input");
        input.setAttribute("type",type);
        input.setAttribute("id","item");
        input.addEventListener("click",function(e)
        {
            if(e.target.checked==true)
            {
                this.CreateDynamicPrice();
            }
            else {
                this.removeInput()
            }
        }.bind(this));
        label.appendChild(input);
        label.appendChild(document.createTextNode("INDIVIDUAL-PRICE"));
        formGroup.appendChild(label);
        return formGroup;
    },
    CreateDynamicPrice : function() {
        var mainDiv=document.querySelector("#adding-tabs");
        var range = new AddButton(mainDiv,0,['min-People','max-People','Price'],false,"REMOVE");
        var table=range.createTable();
        range.AddRow();
    },
    removeInput : function()
    {
        var element=document.querySelectorAll("#adding-tabs #adding-more-table");
        var count=element.length;
        if(count!=0)
        {
            var parent=document.querySelector("#adding-tabs");
            var child=document.querySelector("#adding-tabs #adding-more-table");
            parent.removeChild(child);
            var button=document.querySelector("#adding-tabs button");
            parent.removeChild(button);
        }
    }

};
