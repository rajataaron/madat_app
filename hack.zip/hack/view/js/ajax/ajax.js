/**
 * Created by Nitesh on 18-05-2015.
 */
var add_more_count=0;
var latest_entry=1;
function logme()
{
    var login=new XMLHttpRequest();
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    var level=document.getElementById("privilege").value;
    var loader=document.getElementById("loader");
    var user="user="+username+"&pass="+password+"&level="+level;
    login.open("POST","panel_controls/login.php",true);
    login.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    login.send(user);
    login.onreadystatechange=function()
    {
        if(login.status==200 && login.readyState==4)
        {
            var data=JSON.parse(login.responseText);
            if(data.stmt==true && data.levels=="admin")
            {
                location.assign("approval.php");
            }
            if(data.stmt==true && data.levels=="restaurant")
            {
                location.assign("restaurants.php?id="+data.rid);
            }
            if(data.stmt==true && data.levels=="eventCoordinator")
            {
                location.assign("eventmanager_view.php?id="+data.cid);
            }
        }
    }
    return false;
}
function logout()
{
    var logout=new XMLHttpRequest();
    var action="logout=logout";
    logout.open("POST","panel_controls/logout.php",true);
    logout.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    logout.send(action);
    logout.onreadystatechange=function()
    {
        if(logout.status==200 && logout.readyState==4)
        {
            location.reload(true);
           location.assign("index.phtml");
        }
    }
}

window.addEventListener("load",function(event)
{
    var anchorelem=document.getElementById("edit-skill-add-btn");
    anchorelem.addEventListener("click",addTags);
});
function removeElement()
{
var parent=document.getElementById("yui-gen41");
var child=document.getElementById("yui-gen"+arguments[0]+"");
    var count=arguments[0];
    elementcount.splice(count,1);
    parent.removeChild(child);
}
var elementcount=[];
var custom_id=0;
function addTags(event)
{
    var parent=document.getElementById("yui-gen41");
    var count=parent.children.length;
    var values=document.getElementById("meta").value;
    var values_expr=/^[0-9A-Z\sa-z]+$/;
    var res=values.match(values_expr);
    custom_id++;
    if((count<=4) && res) {
        var li = document.createElement("li");
        li.setAttribute("id", "yui-gen"+custom_id+"");
        li.setAttribute("class", "all-skills-list skill-pill endorse-name");
        var content = '';
        content += '<fieldset id="tags-value-column">';
        content += '<span class="skill-pill">';
        content += '<span id="endorse-name'+count+'" class="endorse-name">'+values+'';
        content += '<span class="endorse-item-name jellybean">';
        content += '<span id="removing-element" onclick="removeElement('+custom_id+')" class="remove">x</span>';
        content += '</span></span> </span> </fieldset> </li>';
        li.innerHTML += content;
        document.getElementById('meta').value="";
        parent.appendChild(li);
        elementcount[custom_id]=values;
    }
    else
    {
        alert('maximumvalue');
    }
}

function loadmap()
{
    var args=arguments[0];
    var parse=JSON.parse(args);
    var uid=parse.id;
    var city=parse.city;
    document.getElementById("modification").innerHTML="";
    sendData(28.471906, 77.512840);
    document.getElementById("modification").style.height="500px";
    var button_location=document.createElement("button");
    button_location.setAttribute("type","button");
    button_location.setAttribute("class","btn btn-default");
    button_location.setAttribute("onclick","tracelocation()");
    button_location.setAttribute("value","Trace My Location");
    button_location.innerHTML="Trace My Location";
    var parent=document.getElementById("outer_area");
    parent.insertBefore(button_location,document.getElementById("modification"));
    var button_submit=document.createElement("button");
    button_submit.setAttribute("type","button");
    button_submit.setAttribute("class","btn btn-default");
    button_submit.setAttribute("onclick","sendlocation('"+uid+"')");
    button_submit.style.float="right";
    button_submit.style.marginBottom="2%";
    button_submit.innerHTML="send Location";
    parent.appendChild(button_submit);

}
function tracelocation()
{

    if(navigator.geolocation)
    {
        navigator.geolocation.getCurrentPosition(showPosition);
    }
    else
    {
        alert("GeoLocation not supported");
    }
}
function showPosition(position)
{
    var lat=position.coords.latitude;
    var lon=position.coords.longitude;
    var data=sendData(lat,lon);
}
function sendlocation(b)
{
    var a=b;
    var lat=arr2;
    var lng=arr3;
    var values='lat='+lat+'&lngt='+lng+'&id='+a+'&request1=location';
    var req=new XMLHttpRequest();
    req.open("POST","controller/alchol.php",true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(values);
}
function approve()
{
    var id=arguments[0];
    var req_id='id='+id;
    var approval=new XMLHttpRequest();
    approval.open("POST","panel_controls/approval.php",true);
    approval.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    approval.send(req_id);
    approval.onreadystatechange=function()
    {
        if(approval.status==200 && approval.readyState==4)
        {
            var elem=document.getElementById("approved"+id+"");
            elem.setAttribute("id","reject"+id+"");
            elem.setAttribute("onclick","reject('"+id+"')");
            elem.innerHTML="Reject";
        }
    }
}
function reject()
{
    var id=arguments[0];
    var req_id='id='+id;
    var reject=new XMLHttpRequest();
    reject.open("POST","panel_controls/reject.php",true);
    reject.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    reject.send(req_id);
    reject.onreadystatechange=function()
    {
        if(reject.status==200 && reject.readyState==4)
        {
            var elem=document.getElementById("reject"+id+"");
            elem.setAttribute("id","approved"+id+"");
            elem.setAttribute("onclick","approve('"+id+"')")
            elem.innerHTML="Approve";
        }
    }
}
function nonfeatured()
{
    var id=arguments[0];
    var rid="id="+id;
    var Featured=new XMLHttpRequest();
    Featured.open("POST","panel_controls/getfeatured.php",true);
    Featured.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    Featured.send(rid);
    Featured.onreadystatechange=function()
    {
        if(Featured.status==200 && Featured.readyState==4) {
            var elem = document.getElementById("featured" + id + "");
            elem.setAttribute("id", "un-featured" + id + "");
            elem.setAttribute("onclick", "featured('" + id + "')")
            elem.innerHTML = "Non-Featured";
        }
    }
}
function featured()
{
    var id=arguments[0];
    var rid="id="+id;
    var nonFeatured=new XMLHttpRequest();
    nonFeatured.open("POST","panel_controls/removeFeatured.php",true);
    nonFeatured.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    nonFeatured.send(rid);
    nonFeatured.onreadystatechange=function()
    {
        if(nonFeatured.status==200 && nonFeatured.readyState==4) {
            var elem = document.getElementById("un-featured" + id + "");
            elem.setAttribute("id", "featured" + id + "");
            elem.setAttribute("onclick", "nonfeatured('" + id + "')");
            elem.innerHTML = "Featured";
        }
    }
}

function value_select()
{
    var selection=document.getElementById("searchkey");
    var search_item=selection.nextElementSibling.children[0].children[0];
    search_item.innerHTML="";
    var query_string=selection.value;
    if(query_string!=="")
    {
        var query="key="+query_string;
        var send_req=new XMLHttpRequest();
        send_req.open("POST","panel_controls/search_result.php",true);
        send_req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        send_req.send(query);
        send_req.onreadystatechange=function()
        {
            if(send_req.status==200 && send_req.readyState==4)
            {
                var res=document.getElementById("tabs");
                res.innerHTML="";
                var data=JSON.parse(send_req.responseText);
                var table='';
                table='<tr>';
                table +='<td class="text-center"><div class="checkbox margin-t-0"><input id="'+data.clientId+'" type="checkbox"><label for="checkbox1"></label></div></td>';
                table +='<td># <b>'+data.clientId+'</b></td>';
                table +='<td>'+data.name+'</td>';
                table +='<td>'+data.username +'</td>';
                table +='<td>'+data.date+'</td>';
                if(data.stat==0) {
                    table += "<td><button type=\"button\" id=\"approved"+data.clientId+"\" class=\"btn btn-default\" onclick=\"approve('"+data.clientId+"')\"> Approve</button> </td></td>";
                }
                else if(data.stat==1)
                {
                    table +="<td><button type=\"button\" id=\"reject"+data.clientId+"\" class=\"btn btn-default\" onclick=\"reject('"+data.clientId+"')\"> Reject</button></td>";
                }
                if(data.feature==0)
                {
                    table += "<td><button type=\"button\" id=\"featured"+data.clientId+"\" class=\"btn btn-default\" onclick=\"nonfeatured('"+data.clientId+"')\">Featured</button> </td>";
                }
                else if(data.feature==1)
                {
                    table +="<td><button type=\"button\" id=\"un-featured"+data.clientId+"\" class=\"btn btn-default\" onclick=\"featured('"+data.clientId+"')\">Non-Featured</button> </td>";
                }
                var rest=data.rating;
                table +="<td> <select id=\"change_select"+data.clientId+"\" onchange=\"change_rating('"+data.clientId+"')\" data-id="+data.clientId+">";
                for(var i=0;i<=5;i++)
                {
                    if(i==rest) {
                        table += '<option value="' + i + '" selected>' + i + '</option>';
                    }
                    else
                    {
                        table += '<option value="' + i + '">' + i + '</option>';
                    }
                }
                table +='</select></td>';
                res.innerHTML=table;
            }
        }
    }
}
function editValue()
{
    var ags=arguments[0];
var cross_symbol=document.getElementById("edit-transform");
    cross_symbol.setAttribute('onclick',"change_value('"+ags+"')");
    var icon=cross_symbol.children[0];
    icon.setAttribute("class","fa fa-check");
    var element=document.getElementById('elements-node');
    var td=element.children[0].children[1];
    var rest_name=document.createElement('input');
    rest_name.setAttribute("type","text");
    rest_name.setAttribute('id','rest-name');
    rest_name.value=td.innerHTML;
    td.innerHTML="";
    td.appendChild(rest_name);
    email=element.children[1].children[1];
    var email_field=document.createElement("input");
    email_field.setAttribute("type","email");
    email_field.setAttribute("id","email-value");
    email_field.value=email.innerHTML;
    email.innerHTML="";
    email.appendChild(email_field);
    var address=element.children[2].children[1];
    address_field=document.createElement("input");
    address_field.setAttribute("type","text");
    address_field.setAttribute("id","address-field");
    address_field.value=address.innerHTML;
    address.innerHTML="";
    address.appendChild(address_field);
    city=element.children[3].children[1];
    var city_field=document.createElement("input");
    city_field.setAttribute('type','text');
    city_field.setAttribute('id','city-name');
    city_field.value=city.innerHTML;
    city.innerHTML="";
    city.appendChild(city_field);
    mobile=element.children[4].children[1];
    var mobile_field=document.createElement('input');
    mobile_field.setAttribute('type','tel');
    mobile_field.setAttribute('id','mobile-number');
    mobile_field.value=mobile.innerHTML;
    mobile.innerHTML="";
    mobile.appendChild(mobile_field);
    meta=element.children[5].children[1];
    var meta_field=document.createElement("input");
    meta_field.setAttribute("type","text");
    meta_field.setAttribute("id","meta_form");
    meta_field.value=meta.innerHTML;
    meta.innerHTML="";
    meta.appendChild(meta_field);
}

function change_value()
{
    var name=document.getElementById('rest-name').value;
    var email=document.getElementById('email-value').value;
    var city=document.getElementById('city-name').value;
    var mobile=document.getElementById('mobile-number').value;
    var address=document.getElementById('address-field').value;
    var meta=document.getElementById('meta_form').value;
    var rid=arguments[0];
    var values='name='+name+'&email='+email+'&city='+city+'&mobile='+mobile+'&address='+address+'&meta='+meta+'&rid='+arguments[0];
    var data_update=new XMLHttpRequest();
    data_update.open("POST","panel_controls/update.php",true);
    data_update.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    data_update.send(values);
    data_update.onreadystatechange=function()
    {
        if(data_update.status==200 && data_update.readyState==4) {
            var cross_symbol=document.getElementById("edit-transform");
            cross_symbol.setAttribute('onclick',"editValue('"+rid+"')");
            var icon=cross_symbol.children[0];
            icon.setAttribute("class","fa fa-times");
            var element = document.getElementById("elements-node");
            var td = element.children[0].children[1];
           var name_field=document.getElementById('rest-name');
            td.removeChild(name_field);
            td.innerHTML=name;
            var td1=element.children[1].children[1];
            var email_field=document.getElementById('email-value');
            td1.removeChild(email_field);
            td1.innerHTML=email;
            var td2=element.children[2].children[1];
            var address_field=document.getElementById('address-field');
            td2.removeChild(address_field);
            td2.innerHTML=address;
            var td3=element.children[3].children[1];
            var city_field=document.getElementById('city-name');
            td3.removeChild(city_field);
            td3.innerHTML=city;
            var td4=element.children[4].children[1];
            var num_field=document.getElementById('mobile-number');
            td4.removeChild(num_field);
            td4.innerHTML=mobile;
            var td5=element.children[5].children[1];
            var tag_field=document.getElementById('meta_form');
            td5.removeChild(tag_field);
            td5.innerHTML=meta;
        }

    }
}
window.addEventListener("load",function(event)
{
    var element=document.getElementById('modification');
    var div=document.getElementById('button-face');
    var button=document.createElement('button');
    button.setAttribute("type","button");
    var id=element.getAttribute('data-id');
    button.setAttribute("class","btn btn-default");
    button.setAttribute("onclick","changeposition('"+id+"')");
    button.innerHTML="Change-location";
    var lat=element.getAttribute('data-lat');
    var lan=element.getAttribute('data-lng');
    div.appendChild(button);
    sendData(lat,lan);
});
function changeposition(b)
{
    var id=b;
    var lat=arr2;
    var lng=arr3;
    var values='id='+id+'&lat='+lat+'&lng='+lng;
    var clock=new XMLHttpRequest();
    clock.open("POST","panel_controls/clock.php",true);
    clock.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    clock.send(values);
}

window.addEventListener("load",function(eve)
{
    var resturant_image=document.getElementById('resturant-image');
    resturant_image.addEventListener("click",gallery);
    var menu=document.getElementById('resturant-menu');
    menu.addEventListener("click",menu_image);
});
function gallery()
{
    var element=document.getElementById('modification');
    var rid=element.getAttribute('data-id');
    var folder='restaurant_gallery'
    var data="rid="+rid+"&folder="+folder;
    var check_gallery=new XMLHttpRequest();
    check_gallery.open("POST","panel_controls/check_folder.php",true);
    check_gallery.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    check_gallery.send(data);
    check_gallery.onreadystatechange=function() {
        if (check_gallery.readyState == 4 && check_gallery.status == 200) {
            var data = JSON.parse(check_gallery.responseText);
            if(data.filename=="empty") {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">No-image</div>';
                form += '<div id="rest-gallery" class="panel-body">';
                form += '<form id="rest_image" onsubmit="return upload();" enctype="multipart/form-data"/>';
                form += '<input type="file" id="resturant_image" name="files[]" multiple="multiple"/>';
                form += '<input type="submit" id="submit" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
            else
            {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">Gallery-Image</div>';
                form += '<div id="rest-gallery" class="panel-body">';
                for(var i=0;i<data.length;i++)
                {
                    form +='<div class="box">';
                    form +='<img src="profiles/'+rid+'/restaurant_gallery/'+data[i].filename+'" width="200" height="200"/>';
                    form +="<span class=\"cross\" onclick=\"delete_image('"+data[i].filename+"','restaurant_gallery','"+rid+"')\">[x]</span>";
                    form +='</div>';
                }
                form += '<form id="rest_image" onsubmit="return upload();" enctype="multipart/form-data"/>';
                form += '<input type="file" id="resturant_image" name="files[]" multiple="multiple"/>';
                form += '<input type="submit" id="submit" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
        }
    }
}
window.addEventListener("load",function(e)
{
    var submit=document.getElementById('submit');
    submit.addEventListener("submit",handle_upload);
});
function handle_upload(e)
{
    var image=document.getElementById('submit');

}
function upload(event)
{
    var data= new FormData();
    var file_input=document.getElementById('resturant_image');
    for(var i=0;i< file_input.files.length;i++)
    {
     data.append("files[]",file_input.files[i]);
    }
    var element=document.getElementById('modification');
    var rid=element.getAttribute('data-id');
    data.append('uid',rid);
    var send_image=new XMLHttpRequest();
    send_image.open("POST","panel_controls/resturant_pic.php",true);
    send_image.setRequestHeader('Cache-Control','no-cache');
    send_image.send(data);
    send_image.onreadystatechange=function() {
        if (send_image.readyState == 4 && send_image.status == 200) {
            var data = JSON.parse(send_image.responseText);
            if(data.image!="Get-featured" || data.image=="size-error")
            {
            var event_gallery = document.getElementById('rest-gallery');
            var rest_image = document.getElementById('rest_image');
            for (var i = 0; i < data.length; i++) {
                var div = document.createElement('div');
                div.setAttribute("class", "box");
                var image = document.createElement('img');
                var path = 'profiles/' + rid + '/restaurant_gallery/' + data[i].image;
                image.setAttribute("src", path);
                image.setAttribute("width", 200);
                image.setAttribute("height", 200);
                div.appendChild(image);
                var span = document.createElement('span');
                span.setAttribute("class", "cross");
                span.setAttribute("onclick", "delete_image('" + data[i].image + "','restaurant_gallery','" + rid + "')");
                var text = document.createTextNode("[x]");
                span.appendChild(text);
                div.appendChild(span);
                event_gallery.insertBefore(div, rest_image);
                rest_image.reset();
            }
            }
            else if(data.image=="Get-Featured")
            {
                alert("get-featured");
            }
        }
    }
    return false;
}
function delete_image()
{
var image_name=arguments[0];
    var folder=arguments[1];
    var rid=arguments[2];
    var path="rid="+rid+"&folder="+folder+"&image="+image_name;
    var file_delete=new XMLHttpRequest();
    file_delete.open("POST","panel_controls/delete_image.php",true);
    file_delete.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    file_delete.send(path);
    file_delete.onreadystatechange=function()
    {
        if(file_delete.status==200 && file_delete.readyState==4)
        {
            var element;
            if(folder=="restaurant_gallery")
            {
                element=document.getElementById("rest-gallery");
            }
            if(folder=="restaurant_menu")
            {
                element=document.getElementById("menu_image");
            }
            for(var i=0;i<=element.children.length;i++)
            {
                var box=element.children[i];
                var img=box.children[0];
                var attribute=img.getAttribute("src");
                var arr=attribute.split("/");
                var imgSrc=arr[3];
                if(imgSrc==file_delete.responseText)
                {
                    element.removeChild(box);
                }
            }
        }
    }
}
function menu_image()
{
    var element=document.getElementById('modification');
    var rid=element.getAttribute('data-id');
    var folder='restaurant_menu';
    var data="rid="+rid+"&folder="+folder;
    var menu_gallery=new XMLHttpRequest();
    menu_gallery.open("POST","panel_controls/check_folder.php",true);
    menu_gallery.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    menu_gallery.send(data);
    menu_gallery.onreadystatechange=function() {
        if(menu_gallery.status==200 && menu_gallery.readyState)
        {
           var data=JSON.parse(menu_gallery.responseText);
            if(data.filename=="empty")
            {
                var base = document.getElementById('details');
                base.innerHTML = " ";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">No-image</div>';
                form += '<div id="menu_image" class="panel-body">';
                form += '<form id="rest_image" onsubmit="return menu_upload();" enctype="multipart/form-data"/>';
                form += '<input type="file" id="menu_img" name="files[]" multiple="multiple"/>';
                form += '<input type="submit" id="submit" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
            else
            {
                var base = document.getElementById('details');
                base.innerHTML = " ";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">Menu-Image</div>';
                form += '<div id="menu_image" class="panel-body">';
                for(var i=0;i<data.length;i++)
                {
                    form +='<div  class="box">';
                    form +='<img src="profiles/'+rid+'/restaurant_menu/'+data[i].filename+'" width="200" height="200"/>';
                    form +="<span class=\"cross\" onclick=\"delete_image('"+data[i].filename+"','restaurant_menu','"+rid+"')\">[x]</span>";
                    form +='</div>';
                }
                form += '<form id="rest_image" onsubmit="return menu_upload();" enctype="multipart/form-data"/>';
                form += '<input type="file" id="menu_img" name="files[]" multiple="multiple"/>';
                form += '<input type="submit" id="submit" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
        }
    }
}
function menu_upload()
{
    var data= new FormData();
    var file_input=document.getElementById('menu_img');
    for(var i=0;i< file_input.files.length;i++)
    {
        data.append("files[]",file_input.files[i]);
    }
    var element=document.getElementById('modification');
    var rid=element.getAttribute('data-id');
    data.append('uid',rid);
    var menu_img=new XMLHttpRequest();
    menu_img.open("POST","panel_controls/menu.php",true);
    menu_img.setRequestHeader('Cache-Control','no-cache');
    menu_img.send(data);
    menu_img.onreadystatechange=function()
    {
        if(menu_img.readyState==4 && menu_img.status==200)
        {
            var data=JSON.parse(menu_img.responseText);
            var menue_image = document.getElementById('menu_image');
            var rest_image=document.getElementById('rest_image');
            for(var i=0;i<data.length;i++) {
                var div=document.createElement('div');
                div.setAttribute("class","box");
                var image=document.createElement('img');
                var path="profiles/"+rid+"/restaurant_menu/"+data[i].image;
                image.setAttribute("src",path);
                image.setAttribute("width",200);
                image.setAttribute("height",200);
                div.appendChild(image);
                var span=document.createElement('span');
                span.setAttribute("class","cross");
                span.setAttribute("onclick","delete_image('"+data[i].image+"','restaurant_menu','"+rid+"')");
                var text=document.createTextNode("[x]");
                span.appendChild(text);
                div.appendChild(span);
                menue_image.insertBefore(div,rest_image);
            }
        }
    }
    return false;
}
function grabData()
{
   var eid=arguments[0];
    var obj=[];
    var elem=[];
    for(var i=1;i<add_more_count;i++)
    {
        var min=document.getElementById("elem"+i+0).value;
        var max=document.getElementById("elem"+i+1).value;
        var rate=document.getElementById("elem"+i+2).value;
        var data = "min=" + min + "&max=" + max + "&price=" + rate+"&eid="+eid;
            var multiple_req = new XMLHttpRequest();
            multiple_req.open("POST", "panel_controls/test.php", true);
            multiple_req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            multiple_req.send(data);

    }
}

function change_rating()
{
    var id=arguments[0];
    var select=document.getElementById('change_select'+id).value;
    var rate_value='rating='+select+'&id='+id;
    var con=new XMLHttpRequest();
    con.open("POST","panel_controls/update_rating.php",true);
    con.setRequestHeader("Content-type","application/x-www-form-urlencoded");
    con.send(rate_value);
}
function recheck()
{
    var email_id=document.getElementById('email_div');
    var child=email_id.children[0];
    email_id.removeChild(child);
}
function create_notification_body() {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "panel_controls/send_request.php");
    var flag = 'flag=' + 0;
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(flag);
    xhr.onreadystatechange = function () {

        if (xhr.status == 200) {
            if(xhr.readyState==4) {
                var data=JSON.parse(xhr.responseText);
                var parent = document.getElementById('notification');
                parent.setAttribute("onclick", "delete_notification()")
                var div = document.createElement("div");
                div.setAttribute("id", "gpn_notification");
                div.setAttribute("class", "__tw _4xi1 uiToggleFlyout");
                var noti = '';
                for(var i=0;i<data.length;i++) {
                    noti += '<div class="panel-body">';
                    noti += '<div class="kode-alert kode-alert-img alert1 price">';
                    noti += '<a href="#" class="closed">×</a>';
                    noti += '<a href="eventmanager.php"><b>'+data[i].mail +'</b> had registered.</div></a>';
                    noti += '</div>';
                    div.innerHTML = noti;
                }
                var button = document.getElementById('notification');
                button.appendChild(div);
            }
        }
    }
}
function delete_notification()
{
    var parent=document.getElementById('notification');
    var child=parent.children[2];
        parent.removeChild(child);
    parent.setAttribute("onclick","create_notification_body()");
}
function generate_user()
{
    var cid=arguments[0];
    var request='cid='+cid;
    var xhr=new XMLHttpRequest();
    xhr.open("POST","panel_controls/generate_user.php",true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(request);
    xhr.onreadystatechange=function()
    {
        if(xhr.status==200 && xhr.readyState==4)
        {
            var id=document.getElementById("generate"+cid);
            id.style.background="limegreen";
            id.innerHTML="user-Generated";
        }
    }
}
function approve_emgr()
{
    var cid=arguments[0];
    var req='cid='+cid+'&flag='+0;
    var xhr=new XMLHttpRequest();
    xhr.open("POST","panel_controls/approve_manager.php",true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(req);
    xhr.onreadystatechange=function()
    {
        if(xhr.status==200)
        {
            if(xhr.readyState==4)
            {
            var id=document.getElementById('approved'+cid);
                id.setAttribute('id','reject'+cid);
                id.setAttribute("onclick","reject_emgr('"+cid+"')");
                id.style.background="red";
                id.innerHTML="Block"
            }
        }
    }
}
function reject_emgr()
{
    var cid=arguments[0];
    var req='cid='+cid+'&flag='+1;
    var xhr=new XMLHttpRequest();
    xhr.open("POST","panel_controls/approve_manager.php",true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(req);
    xhr.onreadystatechange=function()
    {
        if(xhr.status==200)
        {
            if(xhr.readyState==4)
            {
                var id=document.getElementById('reject'+cid);
                id.setAttribute('id','approved'+cid);
                id.setAttribute("onclick","approve_emgr('"+cid+"')");
                id.style.background="#4DA5FF";
                id.innerHTML="Approve";
            }
        }
    }
}
function approve_featured()
{
    var cid=arguments[0];
    var req='cid='+cid+'&flag='+0;
    var xhr=new XMLHttpRequest();
    xhr.open("POST","panel_controls/featured_manager.php",true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(req);
    xhr.onreadystatechange=function()
    {
    if(xhr.status==200)
    {
        if(xhr.readyState==4)
        {
           var id=document.getElementById('featured'+cid);
            id.setAttribute("id","un-featured"+cid);
            id.setAttribute("onclick","remove_featured('"+cid+"')");
            id.style.background="red";
            id.innerHTML="Un-Featured";
        }
    }
}
}
function remove_featured() {
    var cid = arguments[0];
    var req = 'cid=' + cid + '&flag=' + 1;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "panel_controls/featured_manager.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(req);
    xhr.onreadystatechange = function () {

        if (xhr.status == 200) {
            if (xhr.readyState == 4) {
                var id = document.getElementById('un-featured' + cid);
                id.setAttribute('id', 'featured' + cid);
                id.setAttribute("onclick", "approve_featured('" + cid + "')");
                id.style.background = "#4DA5FF";
                id.innerHTML = "Featured";
            }
        }
    }
}
function hintsManager()
{
   var input=document.getElementById('search-text');
    var text=input.value;
    var input_validation=/^[a-zA-Z0-9]*[a-zA-Z0-9]$/;
    if(text.match(input_validation))
    {
        var xhr=new XMLHttpRequest();
        var match='text='+text
        xhr.open("POST","panel_controls/searchManager.php",true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(match);
        xhr.onreadystatechange=function()
        {
            if(xhr.status==200)
            {
                if(xhr.readyState==4)
                {

                }
            }
        }
    }
}
function edit_manager()
{
    var ags=arguments[0];
    var cross_symbol=document.getElementById("edit-transform");
    cross_symbol.setAttribute('onclick',"update_mgr('"+ags+"')");
    var icon=cross_symbol.children[0];
    icon.setAttribute("class","fa fa-check");
    var element=document.getElementById('elements-node');
    var table=element.parentNode;
    var div=table.parentNode;
    var topDiv=div.parentNode;
    topDiv.style.height="595px";
    var td=element.children[0].children[1];
    var rest_name=document.createElement('input');
    rest_name.setAttribute("type","text");
    rest_name.setAttribute('id','agencyname');
    rest_name.value=td.innerHTML;
    td.innerHTML="";
    td.appendChild(rest_name);
    var address=element.children[1].children[1];
    address_field=document.createElement("input");
    address_field.setAttribute("type","text");
    address_field.setAttribute("id","agentname");
    address_field.value=address.innerHTML;
    address.innerHTML="";
    address.appendChild(address_field);
    city=element.children[2].children[1];
    var city_field=document.createElement("input");
    city_field.setAttribute('type','text');
    city_field.setAttribute('id','address');
    city_field.value=city.innerHTML;
    city.innerHTML="";
    city.appendChild(city_field);
    mobile=element.children[3].children[1];
    var mobile_field=document.createElement('input');
    mobile_field.setAttribute('type','tel');
    mobile_field.setAttribute('id','mobile-number');
    mobile_field.value=mobile.innerHTML;
    mobile.innerHTML="";
    mobile.appendChild(mobile_field);
    meta=element.children[4].children[1];
    var meta_field=document.createElement("input");
    meta_field.setAttribute("type","text");
    meta_field.setAttribute("id","meta_form");
    meta_field.value=meta.innerHTML;
    meta.innerHTML="";
    meta.appendChild(meta_field);
    var regOn=element.children[5].children[1];
    var reg_field=document.createElement("input");
    reg_field.setAttribute("type","text");
    reg_field.setAttribute("id","user_name");
    reg_field.value=regOn.innerHTML;
    regOn.innerHTML="";
    regOn.appendChild(reg_field);

}
function update_mgr()
{
    var name=document.getElementById('agencyname').value;
    var agent_name=document.getElementById('agentname').value;
    var mobile=document.getElementById('mobile-number').value;
    var address=document.getElementById('address').value;
    var meta=document.getElementById('meta_form').value;
    var cid=arguments[0];
    var values='name='+name+'&agent_name='+agent_name+'&mobile='+mobile+'&address='+address+'&meta='+meta+'&cid='+arguments[0];
    var data_update=new XMLHttpRequest();
    data_update.open("POST","panel_controls/updateManager.php",true);
    data_update.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    data_update.send(values);
    data_update.onreadystatechange=function()
    {
        if(data_update.status==200 && data_update.readyState==4) {
            var cross_symbol=document.getElementById("edit-transform");
            cross_symbol.setAttribute('onclick',"edit_manager('"+cid+"')");
            var icon=cross_symbol.children[0];
            icon.setAttribute("class","fa fa-times");
            var element = document.getElementById("elements-node");
            var td = element.children[0].children[1];
            var name_field=document.getElementById('agencyname');
            td.removeChild(name_field);
            td.innerHTML=name;
            var td1=element.children[1].children[1];
            var email_field=document.getElementById('agentname');
            td1.removeChild(email_field);
            td1.innerHTML=agent_name;
            var td3=element.children[2].children[1];
            var city_field=document.getElementById('address');
            td3.removeChild(city_field);
            td3.innerHTML=address;
            var td4=element.children[3].children[1];
            var num_field=document.getElementById('mobile-number');
            td4.removeChild(num_field);
            td4.innerHTML=mobile;
            var td5=element.children[4].children[1];
            var tag_field=document.getElementById('meta_form');
            td5.removeChild(tag_field);
            td5.innerHTML=meta;
        }

    }
}
function view_gallery() {
    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var folder = 'gallery_images';
    var data = "cid=" +cid + "&folder=" + folder;
    var check_gallery = new XMLHttpRequest();
    check_gallery.open("POST", "panel_controls/gallery.php", true);
    check_gallery.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    check_gallery.send(data);
    check_gallery.onreadystatechange = function () {
        if (check_gallery.readyState == 4 && check_gallery.status == 200) {
            var data = JSON.parse(check_gallery.responseText);
            if (data.length == 0) {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">No-image</div>';
                form += '<div id="egallery" class="panel-body">';
                form += "<form id=\"rest_image\" onsubmit=\"return upload_handler('"+cid+"')\" enctype=\"multipart/form-data\"/>";
                form += '<input type="file" id="eventmanager_gallery" name="files[]" accept="image/*" multiple="multiple"/>';
                form += '<input type="submit" id="event_gallery" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
            else {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">Gallery-Image</div>';
                form += '<div id="egallery" class="panel-body">';
                for (var i = 0; i < data.length; i++) {
                    form += '<div class="box">';
                    form += '<img src="event_manager/manager_'+expr+ '/gallery_images/' + data[i].filename + '" width="200" height="200"/>';
                    form += "<span class=\"cross\" onclick=\"edelete_image('" + data[i].filename + "','event_manager','" + expr + "')\">[x]</span>";
                    form += '</div>';
                }
                form += "<form id=\"rest_image\" onsubmit=\"return upload_handler('"+cid+"')\" enctype=\"multipart/form-data\"/>";
                form += '<input type="file" id="eventmanager_gallery" name="files[]" accept="image/*" multiple="multiple"/>';
                form += '<input type="submit" id="event_gallery" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
        }
    }
}

function upload_handler() {
    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var data = new FormData();
    var file_input = document.getElementById('eventmanager_gallery');
    for (var i = 0; i < file_input.files.length; i++) {
        data.append("files[]", file_input.files[i]);
    }
    data.append('cid', cid);
    data.append('folder', 'gallery_images');
    var send_image = new XMLHttpRequest();
    send_image.open("POST", "panel_controls/egallery_pic.php", true);
    send_image.setRequestHeader('Cache-Control', 'no-cache');
    send_image.send(data);
    send_image.onreadystatechange = function () {
        if (send_image.readyState == 4 && send_image.status == 200) {
            var data = JSON.parse(send_image.responseText);
            var event_gallery = document.getElementById('egallery');
            var rest_image = document.getElementById('rest_image');
            for (var i = 0; i < data.length; i++) {
                var div = document.createElement('div');
                div.setAttribute("class", "box");
                var image = document.createElement('img');
                var path = 'event_manager/manager_'+expr+ '/gallery_images/' + data[i].image;
                image.setAttribute("src", path);
                image.setAttribute("width", 200);
                image.setAttribute("height", 200);
                div.appendChild(image);
                var span = document.createElement('span');
                span.setAttribute("class", "cross");
                span.setAttribute("onclick", "edelete_image('" + data[i].image + "','event_manager','" + expr+ "')");
                var text = document.createTextNode("[x]");
                span.appendChild(text);
                div.appendChild(span);
                event_gallery.insertBefore(div, rest_image);
                rest_image.reset();
            }
        }

    }
    return false;
}
function edelete_image()
{
    var image=arguments[0];
    var base_dir=arguments[1];
    var id=arguments[2];
    var path="id="+id+"&folder="+base_dir+"&image="+image;
    var file_delete=new XMLHttpRequest();
    file_delete.open("POST","panel_controls/edelete_image.php",true);
    file_delete.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    file_delete.send(path);
    file_delete.onreadystatechange=function()
    {
        if(file_delete.status==200 && file_delete.readyState==4)
        {
         var element=document.getElementById('egallery');
            for(var i=0;i<=element.children.length;i++)
            {
                var box=element.children[i];
                var img=box.children[0];
                var attribute=img.getAttribute("src");
                var arr=attribute.split("/");
                var imgSrc=arr[3];
                if(imgSrc==file_delete.responseText)
                {
                    element.removeChild(box);
                }
            }
        }
    }
}
function view_deals() {
    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var folder = 'deals';
    var data = "cid=" +cid + "&folder=" + folder;
    var check_gallery = new XMLHttpRequest();
    check_gallery.open("POST", "panel_controls/gallery.php", true);
    check_gallery.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    check_gallery.send(data);
    check_gallery.onreadystatechange = function () {
        if (check_gallery.readyState == 4 && check_gallery.status == 200) {
            var data = JSON.parse(check_gallery.responseText);
            if (data.length == 0) {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">No-image</div>';
                form += '<div id="edeals" class="panel-body">';
                form += "<form id=\"rest_image\" onsubmit=\"return deal_upload_handler('"+cid+"')\" enctype=\"multipart/form-data\"/>";
                form += '<input type="file" id="eventmanager_deals" name="files[]" accept="image/*" multiple="multiple"/>';
                form += '<input type="submit" id="deals_gallery" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
            else {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">Deals-Image</div>';
                form += '<div id="edeals" class="panel-body">';
                for (var i = 0; i < data.length; i++) {
                    form += '<div class="box">';
                    form += '<img src="event_manager/manager_'+expr+ '/deals/' + data[i].filename + '" width="200" height="200"/>';
                    form += "<span class=\"cross\" onclick=\"edelete_deals('" + data[i].filename + "','event_manager','" + expr + "')\">[x]</span>";
                    form += '</div>';
                }
                form += "<form id=\"rest_image\" onsubmit=\"return deal_upload_handler('"+cid+"')\" enctype=\"multipart/form-data\"/>";
                form += '<input type="file" id="eventmanager_deals" name="files[]" accept="image/*" multiple="multiple"/>';
                form += '<input type="submit" id="deals_gallery" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
        }
    }
}

function deal_upload_handler() {
    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var data = new FormData();
    var file_input = document.getElementById('eventmanager_deals');
    for (var i = 0; i < file_input.files.length; i++) {
        data.append("files[]", file_input.files[i]);
    }
    data.append('cid', cid);
    data.append('folder', 'deals');
    var send_image = new XMLHttpRequest();
    send_image.open("POST", "panel_controls/egallery_pic.php", true);
    send_image.setRequestHeader('Cache-Control', 'no-cache');
    send_image.send(data);
    send_image.onreadystatechange = function () {
        if (send_image.readyState == 4 && send_image.status == 200) {
            var data = JSON.parse(send_image.responseText);
            var event_gallery = document.getElementById('edeals');
            var rest_image = document.getElementById('rest_image');
            for (var i = 0; i < data.length; i++) {
                var div = document.createElement('div');
                div.setAttribute("class", "box");
                var image = document.createElement('img');
                var path = 'event_manager/manager_'+expr+ '/deals/' + data[i].image;
                image.setAttribute("src", path);
                image.setAttribute("width", 200);
                image.setAttribute("height", 200);
                div.appendChild(image);
                var span = document.createElement('span');
                span.setAttribute("class", "cross");
                span.setAttribute("onclick", "edelete_deals('" + data[i].image + "','event_manager','" + expr+ "')");
                var text = document.createTextNode("[x]");
                span.appendChild(text);
                div.appendChild(span);
                event_gallery.insertBefore(div, rest_image);
                rest_image.reset();
            }
        }

    }
    return false;
}
function edelete_deals()
{
    var image=arguments[0];
    var base_dir=arguments[1];
    var id=arguments[2];
    var path="id="+id+"&folder="+base_dir+"&image="+image;
    var file_delete=new XMLHttpRequest();
    file_delete.open("POST","panel_controls/edeals_delete_image.php",true);
    file_delete.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    file_delete.send(path);
    file_delete.onreadystatechange=function()
    {
        if(file_delete.status==200 && file_delete.readyState==4)
        {
            var element=document.getElementById('edeals');
            for(var i=0;i<=element.children.length;i++)
            {
                var box=element.children[i];
                var img=box.children[0];
                var attribute=img.getAttribute("src");
                var arr=attribute.split("/");
                var imgSrc=arr[3];
                if(imgSrc==file_delete.responseText)
                {
                    element.removeChild(box);
                }
            }
        }
    }
}
function mevent_reg()
{

    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var event_name=document.getElementById('event0').value;
    var event_desc=document.getElementById('event1').value;
    var start_date=document.getElementById('start-day-picker').value;
    var end_date=document.getElementById('end-day-picker').value;
    var start_time=document.getElementById('start-time-picker').value;
    var end_time=document.getElementById('End-time-picker').value;
    var event_capacity=document.getElementById('e_capacity').value;
    var e_exp=document.getElementById('e_exp').value;
    var e_fee=document.getElementById('e_fee').value;
    var event_name_ptrn=/^[0-9a-zA-Z\-_\s]+/;
    var flag=0;
    var name_error=0;
    var event_create=new XMLHttpRequest();
    var form=new FormData();
    form.append("event_name",event_name);
    form.append("event_desc",event_desc);
    form.append("start_date",start_date);
    form.append("host_id",expr);
    form.append("end_date",end_date);
    form.append("start_time",start_time);
    form.append("end_time",end_time);
    form.append("event_capacity",event_capacity);
    form.append("e_exp",e_exp);
    form.append("e_fee",e_fee);
    form.append("file",document.getElementById("e_image").files[0]);
    event_create.open("POST","panel_controls/eevent.php",true);
    event_create.send(form);
    event_create.onreadystatechange=function()
    {
        if(event_create.status==200 && event_create.readyState==4)
        {
            var data=JSON.parse(event_create.responseText);
            datas(data.event_id);
            event_loc(data.event_id);

        }
    }
    return false;
}
function datas()
{
    var eid=arguments[0];
    var obj=[];
    var elem=[];
    for(var i=1;i<add_more_count;i++)
    {
        var min=document.getElementById("elem"+i+0).value;
        var max=document.getElementById("elem"+i+1).value;
        var rate=document.getElementById("elem"+i+2).value;
        var data = "min=" + min + "&max=" + max + "&price=" + rate+"&eid="+eid;
        var multiple_req = new XMLHttpRequest();
        multiple_req.open("POST", "panel_controls/test.php", true);
        multiple_req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        multiple_req.send(data);
    }
}
function event_loc()
{
    var args=arguments[0];
    var base=document.getElementById("details");
    var first_child=base.children[1];
    sendData(28.471906, 77.512840);
    document.getElementById("modification").style.height="500px";
    var button_location=document.createElement("button");
    button_location.setAttribute("type","button");
    button_location.setAttribute("class","btn btn-default");
    button_location.setAttribute("onclick","tracemylocation()");
    button_location.setAttribute("value","Trace My Location");
    button_location.innerHTML="Trace My Location";
    var parent=document.getElementById("outer_area");
    parent.insertBefore(button_location,document.getElementById("modification"));
    var button_submit=document.createElement("button");
    button_submit.setAttribute("type","button");
    button_submit.setAttribute("class","btn btn-default");
    button_submit.setAttribute("onclick","setlocation('"+args+"')");
    button_submit.style.float="right";
    button_submit.style.marginBottom="2%";
    button_submit.innerHTML="send Location";
    parent.appendChild(button_submit);

}
function tracemylocation()
{

    if(navigator.geolocation)
    {
        navigator.geolocation.getCurrentPosition(showPos);
    }
    else
    {
        alert("GeoLocation not supported");
    }
}
function showPos(position)
{
    var lat=position.coords.latitude;
    var lon=position.coords.longitude;
    var data=sendData(lat,lon);
}
function setlocation(b)
{
    var a=b;
    var lat=arr2;
    var lng=arr3;
    var values='lat='+lat+'&lngt='+lng+'&eid='+a+'&request1=locations';
    var req=new XMLHttpRequest();
    req.open("POST","controller/alchol.php",true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(values);
    req.onreadystatechange=function()
    {
        if(req.status==200 && req.readyState==4)
        {
            alert('Event-successfully Added');
        }
    }
}
function eview_docs()
{
    var cid=arguments[0];
    var base=document.getElementById("details");
    base.innerHTML="";
    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var folder = 'documents';
    var data = "cid=" +cid + "&folder=" + folder;
    var check_gallery = new XMLHttpRequest();
    check_gallery.open("POST", "panel_controls/gallery.php", true);
    check_gallery.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    check_gallery.send(data);
    check_gallery.onreadystatechange = function () {
        if (check_gallery.readyState == 4 && check_gallery.status == 200) {
            var data = JSON.parse(check_gallery.responseText);
            if (data.length == 0) {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">No-image</div>';
                form += '<div id="egallery" class="panel-body">';
                form += "<form id=\"rest_image\" onsubmit=\"return document_handler('"+cid+"')\" enctype=\"multipart/form-data\"/>";
                form += '<input type="file" id="mdocs" name="files[]" accept="image/*" multiple="multiple"/>';
                form += '<input type="submit" id="m_docs" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
            else {
                var base = document.getElementById('details');
                base.innerHTML = "";
                var form = '';
                form += '<div id="outer_area" class="col-md-6 modify">';
                form += '<div id="modification" class="panel panel-default">';
                form += '<div class="panel-title">Gallery-Image</div>';
                form += '<div id="egallery" class="panel-body">';
                form +='<ul>';
                form += '<div class="box">';
                for (var i = 0; i < data.length; i++) {

                    form +="<a href=\"event_manager/manager_"+expr+"/documents/"+data[i].filename+"\"><li onclick=\"edelete_image('"+ data[i].filename +"','event_manager','"+ expr +"')\" >" +data[i].filename+ "</li></a><span class='obj' onclick=\"delete_docs('"+expr+"','"+data[i].filename+"')\">[x]</span>";
                }
                form +='</ul>';
                form += '</div>';
                form += "<form id=\"rest_image\" onsubmit=\"return document_handler('"+cid+"')\" enctype=\"multipart/form-data\">";
                form += '<input type="file" id="eventmanager_gallery" name="files[]" accept="image/*" multiple="multiple"/>';
                form += '<input type="submit" id="event_gallery" value="upload"/> </form>';
                form += '</div></div></div>';
                base.innerHTML = form;
            }
        }
    }
}
function document_handler()
{
    var cid = arguments[0];
    var id_expr=/^[c]/;
    var expr=cid.replace(id_expr,'');
    var data = new FormData();
    var file_input = document.getElementById('eventmanager_gallery');
    for (var i = 0; i < file_input.files.length; i++) {
        data.append("files[]", file_input.files[i]);
    }
    data.append('cid', cid);
    data.append('folder', 'documents');
    var send_image = new XMLHttpRequest();
    send_image.open("POST", "panel_controls/documents.php", true);
    send_image.setRequestHeader('Cache-Control', 'no-cache');
    send_image.send(data);
    send_image.onreadystatechange=function()
    {
        if(send_image.readyState==4 && send_image.status==200)
        {
            alert('Document sucessfully Uploaded');
        }
    }
    return false;
}

function imagePanel(event)
{
    window.addEventListener("keydown",function(eve)
    {
        var body=document.getElementsByTagName("body")[0];
        var child1=body.children[0];
        if(child1.getAttribute("class")!=="loading") {
            if (eve.key == 'Escape' || eve.keyCode == 27) {
                body.removeChild(child1);
            }
        }
    });
    var body=document.getElementsByTagName("body")[0];
     var child1=body.children[0];
    var attr=child1.getAttribute("class");
    if(attr=="loading") {
        var baseframe = document.createElement('div');
        baseframe.setAttribute("class", "_10 uiLayer _4-hy _3qw");
        baseframe.style.top=window.pageYOffset+'px';
        var frame = '';
        frame += '<div class="_59s7">';
        frame += '<div class="_4-hz">';
        frame += '<div style="opacity: 1; width: 100%;">';
        frame += '<div>';
        frame += '<div id="u_1_0" class="_4-i0">';
        frame += '<div class="clearfix">';
        frame += '<div class="lfloat _ohe">';
        frame += '<h3 class="_52c9">'+arguments[1]+'</h3>';
        frame += '</div>';
        frame += '<div class="_51-u rfloat _ohf">';
        frame += '<a onclick="remove_frame();" class="_42ft _5upp _50zy layerCancel _51-t _50-0 _50z-">[X]</a>';
        frame += '</div>';
        frame += '</div>';
        frame += '</div>';
        frame +='<div id="u_1_1" class="_4-i2 _50f4">';
        frame +='<div class="_5h2b _4w61">';
        frame +='<i class="fa  fa-plus"></i>';
        frame +='<span class="_17w8 _c24 _50f5 _50f7">Upload Document</span>';
        frame +='<div id="u_1_2" class="_6a _5u5j _m autofocus _5uar">';
        frame +='<a id="u_1_3" class="_3cia"><div class="_3jk"><form id="profile-pic" enctype="multipart/form-data"><input id="js_3" type="file" accept="application/pdf"  name="uploadPhoto" class="_n _5f0v"/><input type="hidden" name="MAX_FILE_SIZE" value=50000 /></form></div>';
        frame +='</div></div>';
        frame += '</div><button type="submit" id="submit-photo">Send</button></form> </div>';
        frame += '</div></div>';
        baseframe.innerHTML = frame;
        body.insertBefore(baseframe, child1);
        formEvent();
    }
}
function remove_frame()
{
    var body=document.getElementsByTagName("body")[0];
    var child1=body.children[0];
    if(child1.getAttribute("class")!=="loading") {
        var child1 = body.children[0];
        body.removeChild(child1);
    }
}