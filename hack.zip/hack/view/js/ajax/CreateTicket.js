/**
 * Created by niteshkumar on 13/01/16.
 */
function CreateTicket(parent,Text)
{
    this.parent=parent;
    this.title=Text;
}
CreateTicket.prototype={
    createPanel : function(callback)
    {
    var top=document.createElement("div");
        top.setAttribute("class","col-md-6 modify");
        var modification=document.createElement("div");
        modification.setAttribute("class","panel panel-default");
        modification.setAttribute("id","modification");
        var title=document.createElement("div");
        modification.appendChild(title);
        top.appendChild(modification);
        var panelBody=document.createElement("div");
        panelBody.setAttribute("class","panel-body");
        var fieldset=document.createElement("fieldset");
        var legend=document.createElement("legend");
        legend.innerHTML= this.title;
        panelBody.appendChild(fieldset);
        fieldset.appendChild(legend);
        var form=document.createElement("form");
        form.setAttribute("class","fieldset-form");
        form.setAttribute("enctype","multipart/form-data");
        var formGroup=document.createElement("div");
        formGroup.setAttribute("class","form-group");
        var label=document.createElement("label");
        label.setAttribute("class","form-label");
        formGroup.appendChild(label);
        var input=document.createElement("input");
        input.setAttribute("type","text");
        input.setAttribute("class","form-control");
        input.setAttribute("id","Ticket");
        formGroup.appendChild(input);
        form.appendChild(formGroup);
        title.appendChild(panelBody);
        fieldset.appendChild(form);
        callback(label,input);
        this.parent.appendChild(top);
    }
};