/**
 * Created by niteshkumar on 20/12/15.
 */
function CouponType(name,switcher)
{
    this.name=name;
    this.state=switcher;
}
CouponType.prototype={
    constructor : CouponType,
    createSelector : function(result)
    {
    if(this.name.lastElementChild.nodeName!="UL") {
        var ul = document.createElement("ul");
        ul.setAttribute("id", "mtdSelector");
        ul.setAttribute("class", "dropdown-menu dropdown-menu-list");
        ul.style.display = "block";
        var li = document.createElement("li");
        var a = document.createElement("a");
        var i = document.createElement("i");
        if(this.state=="percent") {
            i.setAttribute("class", "fa fa-rupee");
        }
        else
        {
            i.setAttribute("class", "fa fa-percent");
        }
        a.appendChild(i);
        li.appendChild(a);
        ul.appendChild(li);
        this.name.appendChild(ul);
        result(a);
    }
    },
    change :function(result)
    {
        var selectors = this.name;
        var dropdown=document.querySelector("#mtdSelector i");
        if(this.state=="amount")
        {
            selectors.firstElementChild.setAttribute("class","fa fa-percent");
                dropdown.setAttribute("class","fa fa-rupee");
                this.state="percent";
                result(this.state);
        }
        else if(this.state=="percent")
        {
            selectors.firstElementChild.setAttribute("class","fa fa-rupee");
            dropdown.setAttribute("class","fa fa-percent");
            this.state="amount";
            result(this.state);
        }
    },
    close:function()
    {
        if(this.name.lastElementChild.nodeName=="UL")
        this.name.removeChild(this.name.lastElementChild);
    }
};