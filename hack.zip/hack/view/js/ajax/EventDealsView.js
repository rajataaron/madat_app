/**
 * Created by niteshkumar on 28/11/15.
 */
function EventDealsView(Type)
{
    EventsDeals.call(this,Type,"base");
}
EventDealsView.prototype=new EventsDeals();
EventDealsView.prototype={
  constructor : EventDealsView,
    createTable:function(id,result)
    {
        var table=document.createElement("table");
        table.setAttribute("id",id);
        table.setAttribute("class","table display");
        table.style.textAlign="center";
        table.style.background="#fff";
        result(table);
    },
    createHead : function()
    {
        var thead=document.createElement("thead");
        var tr=document.createElement("tr");
        for(var i=0;i<arguments.length;i++)
        {
            var th = document.createElement("th");
            th.style.textAlign="center";
            th.innerHTML=arguments[i];
            tr.appendChild(th);
        }
        thead.appendChild(tr);
        return thead;
    },
    createBody : function(name,area,expire,capacity,result,href,listener)
    {
        var tr=document.createElement("tr");
        for(var i=0;i<5;i++)
        {
            var th = document.createElement("td");
            th.style.textAlign="center";
            if(i==0)
            {
                var a=document.createElement("a");
                a.setAttribute("href", href);
                a.innerHTML=name;
                th.appendChild(a);
                listener(a);
            }
            else {
                th.innerHTML=arguments[i];
            }
            tr.appendChild(th);
        }
        return tr;
    }
};