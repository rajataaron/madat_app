/**
 * Created by niteshkumar on 12/01/16.
 */
function AddButton(div,start,title,attr,msg)
{
    Range.call(this,div,start,title,attr,msg);
}
AddButton.prototype=Object.create(Range.prototype,{constructor:{value:AddButton}});
AddButton.prototype.removeInput=function(e)
{
    var parent=document.querySelector("#adding-more-table");
    var row=e.target.parentElement.parentElement;
    this.min=Number(row.children[0].children[0].value)-1;
    parent.removeChild(row);
    this.count--;
    if(this.count==0)
    {
        this.div.removeChild(this.table);
        this.div.removeChild(document.querySelector("#adding-tabs button.btn-option3"));
        var checkBox=document.querySelector("#item");
        checkBox.checked =false;
        this.min=0;
    }
};