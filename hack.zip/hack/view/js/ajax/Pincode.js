/**
 * Created by niteshkumar on 24/12/15.
 */
function Pincode(name,btn,outputDiv,city)
{
this.btn=btn;
this.name=name;
this.outputDiv=outputDiv;
this.city=city;
this.listPin=[];
}
Pincode.prototype={
    constructor:Pincode,
    AddPin : function() {
    this.btn.addEventListener("click",function(e){
    try{
    this.pinPatternTest();
    this.cityTest();
    this.checkPincode();
    var box=document.createElement("div");
        box.setAttribute("class","kode-alert alert1 col-sm-3 seperator");
        box.setAttribute("data-type","pincode");
        var val=document.createTextNode(this.name.value);
        var a=document.createElement("a");
        a.setAttribute("href","#");
        a.addEventListener("click",function(e){
        e.preventDefault();
        this.removePincode(e);
        }.bind(this));
        a.setAttribute("class","closed");
        a.innerHTML="x";
        box.appendChild(a);
        box.appendChild(val);
        this.listPin.push(this.name.value);
       this.outputDiv.appendChild(box);
    }
    catch(e)
    {
        alert(e);
    }
    }.bind(this));
    },
    pinPatternTest : function()
    {
        if(!(/[0-9]{6}/.test(this.name.value)))
        {
            throw "Not a valid pincode";
        }
    },
    cityTest : function()
    {
        if(!(/[a-z]{3,}/.test(this.city.value)))
        {
            throw "Not a valid City";
        }
    },
    checkPincode : function()
    {
    this.listPin.forEach(function(v,i,a){
        if(v==this.name.value)
        {
        throw "Value already exist";
        }
    }.bind(this));
    },
    removePincode : function(e)
    {
        var current=e.target.parentElement;
        var currentVal=current.childNodes[1].nodeValue;
        var parent=document.querySelector("#Code-div .col-sm-10");
        parent.removeChild(current);
        this.listPin.forEach(function(v,a,i){
        var index=this.listPin.indexOf(currentVal);
        this.listPin.splice(index,1);
        }.bind(this));
    }

};