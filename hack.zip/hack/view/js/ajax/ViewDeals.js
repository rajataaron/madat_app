/**
 * Created by niteshkumar on 13/01/16.
 */
function ViewDeals(parent)
{
    this.parent=parent;
}
ViewDeals.prototype = Object.create(EventManager.prototype,{constructor:{value:ViewDeals}});
