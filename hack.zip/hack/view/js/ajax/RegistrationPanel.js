/**
 * Created by niteshkumar on 15/12/15.
 */
function RegistrationPanel(clas)
{
    this.name=clas;
    this.i=0;
}
RegistrationPanel.prototype= {
    metaBag: [],
    constructor: RegistrationPanel,
    formCreate: function () {
        return document.querySelector(this.name);
    },
    createField: function (result) {
        var div = document.createElement("div");
        div.setAttribute("class", "form-group");
        var label = document.createElement("label");
        label.setAttribute("class", "form-label");
        var input = document.createElement("input");
        input.setAttribute("class", "form-control");
        var textarea = document.createElement("textarea");
        textarea.setAttribute("class", "form-control");
        var select = document.createElement("select");
        result(div, label, input, textarea, select);
        return div;
    },
    createTab: function (result) {
        var div = document.createElement("div");
        div.setAttribute("class", "form-group");
        var skillAdder = document.createElement("div");
        skillAdder.setAttribute("class", "skill-adder");
        var label = document.createElement("label");
        skillAdder.appendChild(label);
        skillAdder.appendChild(document.createElement("br"));
        div.appendChild(skillAdder);
        var input = document.createElement("input");
        input.setAttribute("class", "form-control");
        skillAdder.appendChild(input);
        var a = document.createElement("a");
        a.setAttribute("class", "btn-primary");
        a.addEventListener("click", function (e) {
            e.preventDefault();
        });
        skillAdder.appendChild(a);
        var p = document.createElement("p");
        p.setAttribute("id", "skill-counter");
        skillAdder.appendChild(p);
        div.appendChild(skillAdder);
        var allSkillList = document.createElement("div");
        allSkillList.setAttribute("class", "all-skills-list");
        var ol = document.createElement("ol");
        ol.setAttribute("class", "skills-list");
        allSkillList.appendChild(ol);
        result(div, label, input, a, p, ol, skillAdder, allSkillList);
        return div;
    },
    createCheckBox: function (result) {
        var input = document.createElement("input");
        var label = document.createElement("label");
        result(input, label);
    },
    submitButton: function (result) {
        var submit = document.createElement("input");
        submit.addEventListener("click",function(e)
        {
        e.preventDefault();
        });
        result(submit);
        return submit;
    },
    metaTagsEntry: function (data, result) {
        try {
            this.TagExist(data);
            var div = document.createElement("div");
            div.setAttribute("class", "kode-alert alert1");
            var a = document.createElement("a");
            a.setAttribute("class", "closed");
            a.setAttribute("href", "#");
            a.innerHTML = "x";
            a.addEventListener("click", function (e) {
                e.preventDefault();
            });
            var text = document.createTextNode(data);
            div.appendChild(a);
            div.appendChild(text);
            result(div, a);
            this.metaBag.push(data);
            this.i++
        }
        catch (e) {
            this.Message(e);
        }
    },
    TagExist: function (data) {
        this.metaBag.forEach(function (v, a, k) {
            if (data == v) {
                throw "#tags : Already Exist";
            }
        });
        if (this.i > 4) {
            throw "#tags : Maximum number reached";
        }
        if(!/^[a-zA-Z]{3,}/.test(data))
        {
            throw "#tags : Cannot be Empty minimum 3 characters allowed";
        }
    },
    Message: function (msg) {
        var values = msg.split(':');
        var div = document.querySelector(values[0]);
        var TextMessage = values[1];
        var p = document.createElement("p");
        p.innerHTML = TextMessage;
        p.style.color = "red";
        div.appendChild(p);
        window.setTimeout(function () {
            div.removeChild(p);
        }, 4000)
    },
    removeTag : function(e)
    {
        var element=e.target;
        var parent=element.parentElement;
        var text=parent.childNodes[1].nodeValue;
        this.metaBag.forEach(function(v,a,i)
        {
        if(text==v)
        {
            var index=RegistrationPanel.prototype.metaBag.indexOf(text);
            RegistrationPanel.prototype.metaBag.splice(index,1);
        }
        });
        var top=document.querySelector(".skills-list");
        top.removeChild(parent);
        this.i--;
    },
    FileUploaderDiv : function(id)
    {
        var div = document.createElement("div");
        div.setAttribute("class", "form-group");
        div.setAttribute("id",id);
        return div;
    },
    addFileUploader : function(e,result)
    {
        var file=document.createElement("input");
        file.setAttribute("type","file");
        file.setAttribute("class","form-control");
        var label=document.createElement("label");
        label.setAttribute("class","form-label");
        var input=document.createElement("input");
        input.setAttribute("placeholder","ENTER DOCUMENT TYPE");
        input.style.marginBottom="2px";
        input.setAttribute("class","form-control");
        if(e.target.checked==true)
        {
              result('add', file, label,input);
        }
        else
        {
            result('remove',file,label,input);
        }
    },
    CustomMessage : function(msg,result)
    {
        var values = msg.split(':');
        var div = document.querySelector(values[0]);
        var TextMessage = values[1];
        var p = document.createElement("p");
        p.innerHTML = TextMessage;
        result(p);
        div.appendChild(p);
        window.setTimeout(function () {
            div.removeChild(p);
        }, 4000)
    },
    QueryLoader : function(div,result)
    {
        if(div.lastElementChild.nodeName!="IMG") {
            var image = document.createElement("img");
            image.style.marginTop = -3.2 + '%';
            image.setAttribute("class", "end-image");
            result(image);
        }
    },
    MessageDiv: function (msg) {
        var values = msg.split(':');
        var div = document.querySelector(values[1]);
        var TextMessage = values[0];
        var p = document.createElement("p");
        p.innerHTML = TextMessage;
        p.style.color = "red";
        div.appendChild(p);
        window.setTimeout(function () {
            div.removeChild(p);
        }, 4000)
    }
};