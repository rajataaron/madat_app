/**
 * Created by niteshkumar on 23/12/15.
 */
function Range(div,start,title,attr,msg)
{
    this.div=div;
    this.start=start;
    this.min=0;
    this.max=arguments[5];
    this.table=null;
    this.Type=title;
    this.enable=attr;
    this.message=msg;
    this.count=0;
}
Range.prototype={
    constructor : Range,
        createTable : function()
        {
            var table = document.createElement('table');
            table.setAttribute('id', 'adding-more-table');
            var tr = document.createElement('tr');
            for (var i = 0; i < this.Type.length; i++) {
            var td = document.createElement('td');
            td.style.textAlign = "center";
            td.innerHTML = this.Type[i].toLocaleUpperCase();
            tr.appendChild(td);
        }
        table.appendChild(tr);
        this.div.appendChild(table);
            var button = document.createElement("button");
            button.setAttribute("type","button");
            button.setAttribute("class","btn btn-option3 btn-xs");
            button.addEventListener("click",function(e){
            this.AddRow();
            }.bind(this));
            var fai=document.createElement("i");
            fai.setAttribute("class","fa fa-plus");
            var text=document.createTextNode("ADD-MORE");
            button.appendChild(fai);
            button.appendChild(text);
            this.div.appendChild(button);
             this.table=table;
        },
    AddRow : function() {
        try {
            if (this.count > 0) {
                this.checkInput();
            }
            var tr = document.createElement("tr");
            tr.setAttribute("class","out");
            for (var i = 0; i < this.Type.length; i++) {
                    var td = document.createElement('td');
                    td.style.textAlign = "center";
                    var input = document.createElement("input");
                    input.setAttribute("type", "number");
                    input.setAttribute("min",0);
                    if(this.min!=0 && i==0)
                    input.value=this.min;
                    td.appendChild(input);
                    tr.appendChild(td);
            }
            if (this.enable == true) {
                var priceTd = document.createElement("td");
                td.style.textAlign = "center";
                var PriceInput = document.createElement("input");
                PriceInput.setAttribute("type", "text");
                priceTd.appendChild(PriceInput);
                tr.appendChild(priceTd);
            }
            tr.appendChild(this.AddButton());
            this.table.appendChild(tr);
            this.count++;
        }
        catch(e)
        {
            alert (e);
        }
      },
    AddButton : function()
    {
        var td=document.createElement("td");
        var button = document.createElement("button");
        button.setAttribute("type","button");
        button.setAttribute("class","btn btn-option3 btn-xs");
        var i=document.createElement("i");
        i.setAttribute("class","fa fa-minus");
        var text=document.createTextNode(this.message);
        button.appendChild(i);
        button.appendChild(text);
        button.addEventListener("click",function(e){
        this.removeInput(e);
        }.bind(this));
        td.appendChild(button);
        return td;
    },
    checkInput : function()
    {
        if(!this.enable) {
            var table = document.querySelector("#adding-more-table");
            var lastRow = table.lastElementChild;
            var min = Number(lastRow.children[0].children[0].value);
            var max = Number(lastRow.children[1].children[0].value);
            this.min=max+1;
            if (min > max) {
                throw "min must be greater than max";
            }
        }
    },
    removeInput : function(e)
    {
    var parent=document.querySelector("#adding-more-table");
    var row=e.target.parentElement.parentElement;
    this.min=Number(row.children[0].children[0].value)-1;
    parent.removeChild(row);
    this.count--;
    if(this.count==0)
    {
     this.div.removeChild(this.table);
     this.div.removeChild(document.querySelector("#rangeOfAge .col-sm-10 button"));
     var checkBox=document.querySelector("#check-age");
     checkBox.checked =false;
     this.min=0;
    }
    }
};