/**
 * Created by Nitesh on 20-07-2015.
 */
var keyvalues=[8,48,49,50,51,52,53,54,55,56,57,65,66,67,68,69,70,71,72,73,74,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,32,96,97,98,99,100,101,102,103,104,105];
var navkeys=[37,38,39,40];
var document_array=['Aadhar-card','Shop-licence','Pan-card','CIN','Sales-Tax','Others'];
var storage=[];
var loc=location.search;
loc=loc.substr(4);
var tab=[];
var max;
function createXhr()
{
    try { return new XMLHttpRequest(); }catch(e){alert("unable to coneect");}
    try {return new ActiveXObject("Msxml2.XMLHTTP.6.0");}catch(e){alert("unable to coneect");}
    try { return new ActiveXObject("Msxml2.XMLHTTP.3.0");}catch (e){alert("unable to coneect");}
    try { return new ActiveXObject("Msxml2.XMLHTTP");}catch (e){alert("unable to coneect");}
    try {return new ActiveXObject("Microsoft.XMLHTTP");}catch(e){alert("unable to coneect");}
    return null;
}
function create_request()
{
    var count_arguments=arguments.length;
    var req=createXhr();
    var url;
    var query;
    var string='';
    for(var i=0;i<count_arguments;i++) {
        if(i==0) {
            url = arguments[i];
        }
        else if(i>0 && i<count_arguments-1)
        {
        string +='request'+i+'='+arguments[i]+'&';
        }
        else
        {
            string +='request'+i+'='+arguments[i]
        }
    }
    query=string;
    req.open("POST",url,true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(query);
    return req;
}
window.addEventListener("load",function(e)
{
    var location=window.location.pathname;
    var path=location.split("/");
    var last=path.length;
    if(path[last-1]=="approval.php") {
        var ele = document.getElementsByClassName("panel-body table-responsive")[0];
        var input = ele.children[0];
        input.addEventListener("keyup", function (e) {
            var flag = 0;
            for (var i = 0; i < keyvalues.length; i++) {
                if (e.keyCode == keyvalues[i]) {
                    flag = 1;
                }
            }
            if (flag) {
                search_ques(e);
            }
        });
        add_cities();
        subAdmin();
        Admin.CheckOptions();
    }
    if(path[last-1]=="restaurants.php")
    {
        var content=document.getElementsByClassName("content")[0];
        content.style.marginLeft="0px";
        description_restaurants(e);
        update_image(e);
        update_wallpic();
        restaurant.support();
        DateSelector.create();
    }
    if(path[last-1]=="index.php")
    {
        logout();
    }
    if(path[last-1]=="resturant_registration.php")
    {
        restaurantReg.register();
        restaurantReg.changer();
    }
    if(path[last-1]=="eventmanager_view.php")
    {
        displayPic();
        //tabs_clicked();
        EventManager.listeners();
        EventManager.LightBoxClose();
    }
    if(path[last-1]=="register.php")
    {
        createSubAdmin();
    }
    if(path[last-1]=="subadmin.php")
    {
      Manage();
    }
    if(path[last-1]=="cupon.php")
    {
        Coupon.Action();
    }
    if(path[last-1]=="deals.php")
    {
        removeDeals();
    }
    if(path[last-1]=="aboutDeals.php")
    {
        DealUpdate();
    }
    if(path[last-1]=="events.php")
    {
        EventPage();
    }
    if(path[last-1]=="aboutEvents.php")
    {
        EventUpdate();
        priceUpdate();
    }
    if(path[last-1]=="documentList.php")
    {
        documentList.lightBox();
    }
    if(path[last-1]=="eventmanager.php")
    {
        Admin.CheckOptions();
    }
});
function search_ques(e)
{
    var ele=document.getElementsByClassName("panel-body table-responsive")[0];
    var input=ele.children[0];
    var key="query="+ele.children[0].value;
    var req=createXhr();
    req.open("POST","panel_controls/search.php",true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(key);
    var ul=document.getElementById("search-value").children[0];
    var li;
    var loader=document.getElementById("loader");
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            loader.style.display="none";
        var data=JSON.parse(req.responseText);
            if(data.length!=0 && data.name!=0)
            {
                for(var i=0;i<data.length;i++)
                {
                    li=create_list(data[i].name,i);
                    ul.appendChild(li);
                }
            }
            listing();
        }
        req.onprogress=function()
        {
          loader.style.display="block";
            ul.innerHTML="";
        }
    }
    ul.innerHTML="";
}
function create_list(name,i)
{
var li=document.createElement("li");
    li.innerHTML=name;
    li.setAttribute("data-index",i);
    li.addEventListener("click",search_value);
    return li;
}
function listing()
{
    var elem=document.getElementById("searchkey");
    var search=document.getElementById("search-result");
    var res=search.children[0].children[0];
   // alert(res.nodeName);
    var len=res.children.length;
    var i=0;
    elem.addEventListener("keydown",function(event)
    {
    if( event.keyCode==40 || event.key=="ArrowDown") {
      if(i<len)
      {
          var li=res.children[i];
          if(li.previousElementSibling)
          {
              var old=res.children[i-1];
              old.removeAttribute("class");
          }
          li.setAttribute("class","active");
          elem.value=li.innerHTML;
          i++;
      }
    }
    },true);
    elem.addEventListener("keydown",function(event)
    {
if(event.keyCode==13 || event.key=="Enter")
{
   if(elem.value!="")
   {
       value_select();
   }
}});

}
function search_value()
{
    var elem=document.getElementById("searchkey");
    elem.value=this.innerHTML;
    value_select();
}
function extra_features()
{
    var ul=document.getElementsByClassName("panel quick-menu clearfix")[0];
    var more=ul.children[2];
    more.addEventListener("click",multiple_power);
}
function multiple_power() {
    var url = "controller/alchol.php";
    var flag = 0;
    var response = create_request(url, 'check', loc);
    response.onreadystatechange = function () {
        response.onload = function () {
            var data = JSON.parse(response.responseText);
            if (data.value == 1) {
                var parent = document.getElementById("details");
                parent.innerHTML = "";
                var option1 = document.createElement("label");
                option1.setAttribute("class", "option");
                option1.innerHTML = "Opt-For-Alcohol";
                var panel = create_box(1);
                parent.appendChild(panel);
                parent.appendChild(option1);
            }
            else{
                var parent = document.getElementById("details");
                parent.innerHTML = "";
                var option1 = document.createElement("label");
                option1.setAttribute("class", "option");
                option1.innerHTML = "Opt-For-Alcohol";
                var panel = create_box(0);
                parent.appendChild(panel);
                parent.appendChild(option1);
            }
        }
    }
}
function create_box(ag)
{
var outer=document.createElement("div");//outer starts
    outer.setAttribute("class","col-md-6 modify");
    var modification=document.createElement("div");//modification sarts
    modification.setAttribute("class","panel panel-default");
    var header=document.createElement("div");
    header.setAttribute("class","panel-title");
    header.innerHTML="More";
    modification.appendChild(header);
    var checkbox=check_box(ag);
    modification.appendChild(checkbox);
    if(ag==1) {
        var btn = create_upload_btn("fa fa-cloud", "upload");
        modification.appendChild(btn);
    }
    outer.appendChild(modification);
    return outer;
}
function check_box(req)
{

        var div = document.createElement("div"); //toggle button start
    if(req==1) {
        div.setAttribute("class", "toggle btn btn-danger");
          }
     else{
    div.setAttribute("class","toggle btn btn-light off");
         }
        div.setAttribute("data-toggle", "toggle");
        div.style.width = "87px";
        div.style.height = "36px";
        var input = document.createElement("input"); //input type checkbox starts
        input.setAttribute("type", "checkbox");
        input.setAttribute("data-onstyle", "danger");
        input.setAttribute("data-toggle", "toggle");
        input.setAttribute("checked", "");
        div.appendChild(input);
        var toggle_group = document.createElement("div");//toggle-group start
        toggle_group.setAttribute("class", "toggle-group");
        var label = document.createElement("label"); //label start
        label.setAttribute("class", "btn btn-danger toggle-on");
        label.innerHTML = "NO";
        toggle_group.appendChild(label);
        label.addEventListener("click", change_sate);
        var labelb = document.createElement("label");//labelb start
        labelb.setAttribute("class", "btn btn-success active toggle-off");
        labelb.innerHTML = "Yes";
        labelb.addEventListener("click", change_sate);
        toggle_group.appendChild(labelb);
        var span = document.createElement("span");
        span.setAttribute("class", "toggle-handle btn btn-toggle");
        toggle_group.appendChild(span);
        div.appendChild(toggle_group);
        return div;

}
function change_sate(e)
{
    var top=this.parentElement.parentElement;
    var parent=top.parentElement;
    if(top.getAttribute("class")=="toggle btn btn-light off")
    {
        var url="controller/alchol.php";
        create_request(url,'add',loc);
        top.setAttribute("class","toggle btn btn-danger");
        var btn = create_upload_btn("fa fa-cloud", "upload");
        parent.appendChild(btn);
    }
    else
    {
        var url="controller/alchol.php";
        create_request(url,'remove',loc);
        top.setAttribute("class","toggle btn btn-light off");
        var last_child=parent.lastElementChild;
        parent.removeChild(last_child);

    }
}
function formEvent()
{
    var form=document.getElementById("profile-pic");
    var btn=document.getElementById("submit-photo");
    form.addEventListener("submit",function(e)
    {
        e.preventDefault();
        e.stopPropagation();
    });
    btn.addEventListener("click",function(e)
    {
        var parent=this.parentElement.parentElement;
        var top=this.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement;
        var div;
       var req=createXhr();
        var formData=new FormData();
        var image=document.getElementById('js_3');
        formData.append("image",image.files[0]);
        formData.append("request1","upload");
        formData.append("request2",loc);
        req.open("POST","controller/alchol.php",true);
        req.send(formData);
        req.onreadystatechange=function()
        {
            req.onload=function()
            {
                var data=JSON.parse(req.responseText);
               if(data.image=="upload Error")
               {
                   error_message(data.image,"fa fa-lock");
               }
                else
               {
                   success_msg("documents sucessfully Uploaded","fa fa-check");
               }
            }
        }
    });
}
function create_upload_btn(fav_icon,msg)
{
    var btn=document.createElement("button");
    btn.setAttribute("class","btn btn-success btn-sm right-flow");
    btn.setAttribute("type","button");
    btn.addEventListener("click",function(e)
    {
        $msg="Upload Documents";
        imagePanel(e,$msg);
    });
    var icon=document.createElement("i");
    icon.setAttribute("class",fav_icon);
    btn.appendChild(icon);
    var text=msg;
    var text_msg=document.createTextNode(text);
    btn.appendChild(text_msg);
    return btn;
}
function error_message(msg,fav_icon)
{
    var body=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
var div =document.createElement("div");
    div.setAttribute("class","kode-alert kode-alert-icon alert6 mcd");
    var i=document.createElement("i");
    i.setAttribute("class",fav_icon);
    div.appendChild(i);
    var a=document.createElement("a");
    a.addEventListener("click",close_error_msg);
    a.setAttribute("class","closed");
    a.innerHTML='x';
    div.appendChild(a);
    var text=document.createTextNode(msg);
    div.appendChild(text);
    body.appendChild(div);
   window.setTimeout(function() {
   var alert_box=body.children[1];
       body.removeChild(alert_box);
   },3000);
}
function close_error_msg()
{
var parent=this.parentElement;
    var top=parent.parentElement;
    top.removeChild(parent);
}
function success_msg(msg,fav_icon)
{
    var body=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
    var div =document.createElement("div");
    div.setAttribute("class","kode-alert kode-alert-icon alert3 mcd");
    var i=document.createElement("i");
    i.setAttribute("class",fav_icon);
    div.appendChild(i);
    var a=document.createElement("a");
    a.addEventListener("click",close_error_msg);
    a.setAttribute("class","closed");
    a.innerHTML='x';
    div.appendChild(a);
    var text=document.createTextNode(msg);
    div.appendChild(text);
    body.appendChild(div);
    window.setTimeout(function() {
        var alert_box=body.children[1];
        body.removeChild(alert_box);
    },3000);
}
function description_restaurants(e)
{
    var form=document.getElementsByClassName("description-form")[0];
    form.addEventListener("submit",function(e)
    {
        e.preventDefault();
        e.stopPropagation();
    });
    var note_editor=form.lastElementChild.lastElementChild;
    var url="controller/alchol.php";
    var req=create_request(url,"view_desc",loc);
    var button=form.nextElementSibling;
    button.addEventListener("click",description_send);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var data=JSON.parse(req.responseText);
            note_editor.innerHTML=data.description;
        }
    }
}
function description_send()
{
    var form=this.previousElementSibling;
    var text_editor=form.getElementsByClassName("note-editor")[0];
    var editable_div=text_editor.lastElementChild;
    var text =editable_div.innerHTML;
    var url="controller/alchol.php";
    var req=create_request(url,"update_desc",text,loc);
}
function update_image(e)
{
    var element=document.getElementById("control_gen_3");
    element.addEventListener("mouseover",function(e)
    {
    element.style.opacity=1;
    });
    element.addEventListener("mouseout",function(e)
    {
        element.style.opacity=0;
    });
    element.addEventListener("click",function(e)
    {
        $msg="Upload image";
        imagePanel(e,$msg);
        var progress=progressBar();
        var elem=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
        elem.appendChild(progress);
        var item=document.getElementsByClassName("_3cia")[1];
        var btn=item.children[0];
        var new_btn=btn.cloneNode(true);
        new_btn.setAttribute("id","submit");
        new_btn.setAttribute("class","btn-submit");
        new_btn.addEventListener("click",update_profileImage);
        item.appendChild(new_btn);
        item.removeChild(btn);
        var element=document.getElementsByClassName("_3jk")[0];
        var form=element.children[0];
        var old_input=form.children[0];
        var new_input=old_input.cloneNode(true);
        new_input.setAttribute("accept","image/*");
        form.removeChild(old_input);
        form.appendChild(new_input);
    });

}
function update_profileImage(e)
{
var elem=this;
    var parent=elem.parentElement;
    var form=parent.previousElementSibling.children[0].lastElementChild.children[0].children[0].children[0];
    var image=document.getElementById('js_3');
    var formData=new FormData();
    formData.append("image",image.files[0]);
    formData.append("request1","uploadHandler");
    formData.append("request2",loc);
    var req=createXhr();
    req.open("POST","controller/alchol.php",true);
    req.send(formData);
        req.upload.addEventListener("progress",function(e)
        {
         if(e.lengthComputable)
         {
          var percent=Math.round((e.loaded/ e.total)*100);
             var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
             var progress=element.lastElementChild.children[0];
             progress.style.width=percent+'%';
         }
        });
        req.upload.addEventListener("load",function(e)
        {
            var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
            var progress=element.lastElementChild;
            success_msg("Image Uploaded Sucessfully","fa fa-check");
        });
        req.upload.addEventListener("error",function(e)
        {
            error_message("Error in Upload","fa fa-lock");
        });
    req.onreadystatechange=function()
    {
        if(req.status==200 && req.readyState==4)
        {
            var data=JSON.parse(req.responseText);
            if(data.state==1)
            {
            var img=document.getElementsByClassName("col-lg-8 col-md-6 titles")[0];
            var span=img.firstElementChild.children[0];
            var image_detail=span.src.split('/');
            var source=image_detail[5];
            span.src="profiles/"+source+"/wall_pic/"+data.message;
        }
    }}
}
function progressBar()
{
    var progress=document.createElement("div");
    progress.setAttribute("class","progress progress-striped active");
    var progressBar=document.createElement("div");
    progressBar.setAttribute("class","progress-bar progress-bar-success");
    progressBar.setAttribute("role","progressbar");
    progressBar.setAttribute("aria-valuenow","60");
    progressBar.setAttribute("aria-valuemin","0");
    progressBar.setAttribute("aria-valuemax","100");
    progressBar.style.width=0+'%';
    var span=document.createElement("span");
    span.setAttribute("class","sr-only");
    span.innerHTML=60+"%completed";
    progressBar.appendChild(span);
    progress.appendChild(progressBar);
    return progress;
}
function update_wallpic()
{
    var action_div=document.getElementsByClassName("row presentation")[0];
    var plb=document.getElementsByClassName("col-lg-8 col-md-6 titles")[0];
    action_div.addEventListener("click",function(e)
    {
        if(e.target==action_div || e.target==plb)
        {
           change_dp(e);
        }
    });
}
function change_dp(e)
{
    var msg="Upload Wallpic";
    var panel=imagePanel(e,msg);
    var progress=progressBar();
    var elem=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
    elem.appendChild(progress);
    var item=document.getElementsByClassName("_3cia")[1];
    var btn=item.children[0];
    var new_btn=btn.cloneNode(true);
    new_btn.setAttribute("id","submit");
    new_btn.setAttribute("class","btn-submit");
    new_btn.addEventListener("click",update_wallphoto);
    item.appendChild(new_btn);
    item.removeChild(btn);
    var element=document.getElementsByClassName("_3jk")[0];
    var form=element.children[0];
    var old_input=form.children[0];
    var new_input=old_input.cloneNode(true);
    new_input.setAttribute("accept","image/*");
    form.removeChild(old_input);
    form.appendChild(new_input);
}
function update_wallphoto()
{
    var elem=this;
    var parent=elem.parentElement;
    var form=parent.previousElementSibling.children[0].lastElementChild.children[0].children[0].children[0];
    var image=document.getElementById('js_3');
    var formData=new FormData();
    formData.append("image",image.files[0]);
    formData.append("request1","picHandler");
    formData.append("request2",loc);
    var req=createXhr();
    req.open("POST","controller/alchol.php",true);
    req.send(formData);
    req.upload.addEventListener("progress",function(e)
    {
        if(e.lengthComputable)
        {
            var percent=Math.round((e.loaded/ e.total)*100);
            var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
            var progress=element.lastElementChild.children[0];
            progress.style.width=percent+'%';
        }
    });
    req.upload.addEventListener("load",function(e)
    {
        var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
        var progress=element.lastElementChild;
        success_msg("Image Uploaded Sucessfully","fa fa-check");
    });
    req.upload.addEventListener("error",function(e)
    {
        error_message("Error in Upload","fa fa-lock");
    });
    req.onreadystatechange=function()
    {
        if(req.status==200 && req.readyState==4)
        {
            var data=JSON.parse(req.responseText);
            if(data.state==1)
            {
                var img=document.getElementsByClassName("row presentation")[0];
                var image=img.style.backgroundImage;
                var src=image.split("/");
                var source=src[1];
                img.style.backgroundImage="profiles/"+source+"/display_pic/"+data.message;

            }
        }}
}
function add_cities(e)
{
    var element=document.getElementsByClassName("top-right")[0];
    var first_child=element.children[0];
    first_child.addEventListener("click",function(e) {
            var ul = element.children[0].lastElementChild;
            ul.children[0].addEventListener("click", states);
            ul.children[1].addEventListener("click", cities);
    });
}
function states()
{
    var body=document.getElementsByTagName("body")[0];
    var first_child=body.children[0];
    var lightbox_back=create_lightboxBackground();
    var loader=createLoader();
    lightbox_back.appendChild(loader);
    var bone=light_box_head("Add-States");
    var dialog_content=light_box_content_input("Add-States");
    var button=buttons("Add-states");
    button.addEventListener("click",function(e){
    add_states(e);
    });
    var city_button=buttons("Add-city");
    city_button.addEventListener("click",function(e)
    {
        close_panel();
        cities();
    });
    dialog_content.appendChild(button);
    dialog_content.appendChild(city_button);
    bone.appendChild(dialog_content);
    lightbox_back.appendChild(bone);
    body.insertBefore(lightbox_back,first_child);
}
function cities()
{
    var url="controller/alchol.php";
    var req=create_request(url,'state_list');
    req.onreadystatechange=function() {
        req.onload = function () {
            var data=JSON.parse(req.responseText);
    var body=document.getElementsByTagName("body")[0];
    var first_child=body.children[0];
    var lightbox_back=create_lightboxBackground();
    var loader=createLoader();
            loader.style.display="none";
    lightbox_back.appendChild(loader);
    var bone=light_box_head("Add-Cities");
    var dialog_content=light_box_content_city("Add-City",data);
    var button=buttons("Add-states");
    button.addEventListener("click",function(e)
    {
        close_panel();
        states();
    });
    var city_button=buttons("Add-city");
            city_button.addEventListener("click",add_city);
    dialog_content.appendChild(button);
    dialog_content.appendChild(city_button);
    bone.appendChild(dialog_content);
    lightbox_back.appendChild(bone);
    body.insertBefore(lightbox_back,first_child);
    }
        req.addEventListener("progress",function(e)
        {
        });
    }
}
function create_lightboxBackground()
{
    var dialogscreen=document.createElement("div");
    dialogscreen.setAttribute("class","dialog-screen");
    dialogscreen.addEventListener("click",function(e)
    {
     close(e);
    });
    return dialogscreen;
}
function createLoader()
{
    var body=document.getElementsByTagName("body")[0]
    var loader=document.createElement("div");
    loader.style.display="none";
    loader.setAttribute("class","dialog-screen-busy");
    var loader_image=document.createElement("div");
    loader_image.setAttribute("class","dialog-screen-busy-img");
    loader.appendChild(loader_image);
    return loader;
}
function light_box_head(msg)
{
    var div=document.createElement("div");
    div.setAttribute("class","dialog-container");
    if(screen.availHeight>window.pageYOffset) {
        div.style.top = (screen.availHeight - window.pageYOffset) / 3 + "px";
    }
    else
    {
        div.style.top =screen.availHeight/3+"px";
    }
    div.style.display=" block";
    div.style.width= "330px";
    div.style.visibility= "visible";
    div.style.height="auto";
    div.style.left="475px";
    var div_head=document.createElement("div");//header starts
    div_head.setAttribute("class","dialog-head-container clearfix");
    var dialog_close=document.createElement("div");
    dialog_close.setAttribute("class","dialog-close");
    dialog_close.addEventListener("click",close_panel);
    var class_cross=document.createElement("div");
    class_cross.setAttribute("data-icon","x");
    dialog_close.appendChild(class_cross);
    div_head.appendChild(dialog_close);
    var msg_box=document.createElement("div");
    msg_box.setAttribute("class","dialog-head");
    msg_box.style.width="240px";
    var span=document.createElement("span");
    span.setAttribute("class","dialog-head-text");
    span.innerHTML=msg;
    msg_box.appendChild(span);
    div_head.appendChild(msg_box);
    var clear=document.createElement("div");
    clear.setAttribute("class","clear");
    div_head.appendChild(clear);
    div.appendChild(div_head);//header end
    return div;
}
function close_panel()
{
    var body=document.getElementsByTagName("body")[0];
    if(body.firstElementChild.getAttribute("class")=="dialog-screen")
    {
        body.removeChild(body.firstElementChild);
    }
}
function close(e)
{
    var elem=document.getElementsByClassName("dialog-screen")[0];
    if(e.target==elem)
    {
        var body=document.getElementsByTagName("body")[0];
        if(body.firstElementChild.getAttribute("class")=="dialog-screen")
        {
            body.removeChild(body.firstElementChild);
        }
    }
}
window.addEventListener("keypress",function(e)
{
if(e.keyCode==27)
{
    var body=document.getElementsByTagName("body")[0];
    if(body.firstElementChild.getAttribute("class")=="dialog-screen")
    {
        body.removeChild(body.firstElementChild);
    }
}
});
function light_box_content_input(msg)
{
    var dialog_body=document.createElement("div");
    dialog_body.setAttribute("class","dialog-body");
    dialog_body.style.width= "auto";
    dialog_body.display="block";
    var grid_a=document.createElement("div");
    grid_a.setAttribute("class","grid_5 column clearfix");
    var form_group=document.createElement("div");
    form_group.setAttribute("class","form-group");
    var label=document.createElement("label");
    label.setAttribute("class","col-sm-2 control-label form-label");
    label.innerHTML=msg;
    form_group.appendChild(label);
    var div=document.createElement("div");
    div.setAttribute("class","col-sm-10");
    var input=document.createElement("input");
    input.setAttribute("id","input-state");
    input.setAttribute("class","form-control freez");
    input.setAttribute("type","text");
    div.appendChild(input);
    form_group.appendChild(div);
    grid_a.appendChild(form_group);
    dialog_body.appendChild(grid_a);
    return dialog_body;
}
function buttons(msg)
{

    var button=document.createElement("button");
    button.setAttribute("class","btn btn-success");
    button.setAttribute("type","button");
    button.innerHTML=msg;
    if(msg=="Add-city")
    {
        button.style.float="right";
    }
    return button;
}
function light_box_content_city(msg,data)
{

            var dialog_body = document.createElement("div");
            dialog_body.setAttribute("class", "dialog-body");
            dialog_body.style.width = "auto";
            dialog_body.display = "block";
            var grid_a = document.createElement("div");
            grid_a.setAttribute("class", "grid_5 column clearfix");
            var select = document.createElement("select");
            select.setAttribute("class", "form-control input-sm");
            var option = document.createElement("option");
            option.value = "Select State";
            option.innerHTML = "Select State";
            select.appendChild(option);
            for (var i = 0; i < data.length; i++) {
                var state_opt = document.createElement("option");
                state_opt.value = data[i].id;
                state_opt.innerHTML = data[i].name;
                select.appendChild(state_opt);
            }
            grid_a.appendChild(select);
            var form_group = document.createElement("div");
            form_group.setAttribute("class", "form-group");
            var label = document.createElement("label");
            label.setAttribute("class", "col-sm-2 control-label form-label");
            label.innerHTML = msg;
            form_group.appendChild(label);
            var div = document.createElement("div");
            div.setAttribute("class", "col-sm-10");
            var input = document.createElement("input");
            input.setAttribute("id", "input-state");
            input.setAttribute("class", "form-control freez");
            input.setAttribute("type", "text");
            div.appendChild(input);
            form_group.appendChild(div);
            grid_a.appendChild(form_group);
            dialog_body.appendChild(grid_a);
            return dialog_body;
}
function add_states(e)
{
    var data=document.getElementsByClassName("col-sm-10")[0];
   var url="controller/alchol.php";
    var req=create_request(url,'add_state',data.children[0].value);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var message=JSON.parse(req.responseText);
            if(message!="Error in Addition")
            {
                successMessage('dialog-screen',message.message);
            }
            else
            {
                errorMessage('dialog-screen',message.message);
            }
        }
    }
}
function successMessage(template,msg)
{
    var elem=document.getElementsByClassName(template)[0];
    var body=elem.children[1];
    var a=document.createElement("a");
    a.style.marginLeft=36+'%';
    a.setAttribute("class","btn btn-success");
    var i=document.createElement("i");
    i.setAttribute("class","fa fa-check");
    i.innerHTML=msg;
    a.appendChild(i);
    body.appendChild(a);
   window.setTimeout(function()
    {
    body.removeChild(body.lastElementChild);
    },5000);
}
function errorMessage(template,msg)
{
    var elem=document.getElementsByClassName(template)[0];
    var body=elem.children[1];
    var a=document.createElement("a");
    a.setAttribute("class","btn btn-warning");
    var i=document.createElement("i");
    i.setAttribute("class","fa fa-warning");
    i.innerHTML=msg;
    a.appendChild(i);
    body.appendChild(a);
    window.setTimeout(function()
    {
        body.removeChild(body.lastElementChild);
    },5000);
}
function add_city()
{
    var state=document.getElementsByClassName("form-control input-sm")[0].value;
    var city=document.getElementById("input-state").value;
    var url="controller/alchol.php";
    var req=create_request(url,'addCity',state,city);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var data=JSON.parse(req.responseText);
            if(data.message =="city added successfully in the state") {
                successMessage('dialog-screen',data.message);
            }
            else
            {
            error_message('dialog-screen',data.message);
            }
        }
    }
}
function register()
{
    var select_state=document.getElementById("city_name");
    select_state.addEventListener("change",function(e)
    {
    city_selection(e);
    });
}
function city_selection(e)
{
    var state_id=e.target.value;
    var url="controller/alchol.php";
    var req=create_request(url,'cityList',state_id);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var data=JSON.parse(req.responseText);
            var state=document.getElementById("states");
            var select=document.createElement("option");
            select.value=0;
            select.innerHTML="Select City";
            state.appendChild(select);
            for(var i=0;i<data.length;i++)
            {
                var option=document.createElement("option");
                option.value=data[i].city;
                option.innerHTML=data[i].city;
                state.appendChild(option);
            }
        }
        req.onprogress=function()
        {
            var state=document.getElementById("states");
            state.innerHTML="";
        }
    }
}
function validation()
{
    var resturant_name=document.getElementById("example10");
    var restaurant_email=document.getElementById("example11");
    var address=document.getElementById("address");
    var address1 = document.getElementById("address2");
    var state=document.getElementById("city_name");
    var city=document.getElementById("states");
    var mobile=document.getElementById("tel-number");
    var docs=document.getElementById("docs");
    var username=document.getElementById("username");
    var password=document.getElementById("password");
    var alcohol=document.getElementById("Alcohol");
    window.localStorage.count=0;
    window.localStorage.fileUploader=0;
    resturant_name.addEventListener("blur",function(e)
    {
        var name=resturant_name.value;
        var pattern=/^[a-zA-Z][a-zA-Z0-9\s]+$/;
        isValid(pattern,e,name);
    },false);
    resturant_name.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
    });
    restaurant_email.addEventListener("blur",function(e)
    {
        var email=restaurant_email.value;
        var pattern=/^[a-zA-Z0-9\-\_.]+@[a-zA-Z0-9]+/;
        isValid(pattern,e,email);
        email_exists(e);
    },false);
    restaurant_email.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        if(e.target.parentElement.lastElementChild.nodeName=="IMG") {
            remove_image('email_div');
        }
    });
    address.addEventListener("blur",function(e)
    {
    var address_val=address.value;
        var pattern=/[a-zA-Z0-9\s#]+/;
        isValid(pattern,e,address_val);
    });
    address.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
    },true);
    state.addEventListener("blur",function(e)
    {
    valid_selection(e)
    });
    state.addEventListener("focus",function(e)
    {
        e.target.removeAttribute("style");
    });
    city.addEventListener("blur",function(e)
    {
        valid_selection(e)
    });
    city.addEventListener("focus",function(e)
    {
        e.target.removeAttribute("style");
    });
    mobile.addEventListener("blur",function(e)
    {
    var mobile_number=mobile.value;
        var pattern=/[0-9]{10}/;
        isValid(pattern,e,mobile_number);
    });
    mobile.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
    },true);
    docs.addEventListener("change",function(e)
    {
        uploadManager(e);
    });
    username.addEventListener("blur",function(e)
    {
    var user=username.value;
        var pattern=/[a-zA-Z0-9_\-\.]{6,}/;
        var bod=isValidWithMessage(pattern,e,user,'Must be atleast 6 characters','70%',"86.9%");
        if(bod) {
            username.parentElement.appendChild(bod);
        }
        user_exist(e);
    });
    username.addEventListener("focus", function (e) {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        if(e.target.parentElement.lastElementChild.nodeName=="IMG") {
            remove_image('user_div');
        }
        remove_warning(e);
    },true);
    password.addEventListener("blur",function(e)
    {
    var pwd=password.value;
        var pattern=/[a-zA-Z0-9~`!@#\$%\^&\*\(\)\+={}\[\]\{\,\}]{8,}/;
        var bod=isValidWithMessage(pattern,e,pwd,'Must be atleast 8 characters','70%',"93.7%");
        if(bod) {
            password.parentElement.appendChild(bod);
        }
    });
    password.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        remove_warning(e);
    });
    alcohol.addEventListener("change",function(e)
    {
        doc_uploader(e);
    });
}
function isValid(pattern,e,data)
{
    if(data=="" || !(pattern.test(data)))
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group has-warning");
        storage.push(e.target.getAttribute("id"));
    }
}
function isValidWithMessage(pattern,e,data,message,left,top)
{
    if(data=="" || !(pattern.test(data)))
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group has-warning");
        storage.push(e.target.getAttribute("id"));
        var div=document.createElement("div");
        div.style.position="absolute";
        div.style.zIndex=8000;
        div.style.paddingBottom="12px";
        div.style.left= left;
        div.style.top=top;
        div.style.display= "block";
        div.style.opacity= 1;
        div.style.transform="rotate(180deg)";
        div.setAttribute("class","jBox-wrapper jBox-Tooltip jBox-TooltipBorder jBox-closeButton-box jBox-pointerPosition-bottom");
        var container_div=document.createElement("div");
        container_div.setAttribute("class","jBox-container");
        var jbox_contain=document.createElement("div");
        jbox_contain.setAttribute("class","jBox-content");
        jbox_contain.style.width="218px";
        jbox_contain.style.height="auto";
        jbox_contain.style.transform="rotate(180deg)";
        jbox_contain.innerHTML=message;
        container_div.appendChild(jbox_contain);
        var jbox_close=document.createElement("div");
        jbox_close.setAttribute("class","jBox-closeButton jBox-noDrag");
        var svg=document.createElement("svg");
        svg.setAttribute("veiwbox","0 0 24 24");
        var path=document.createElement("path");
        path.innerHTML='x';
        svg.appendChild(path);
        jbox_close.appendChild(svg);
        container_div.appendChild(jbox_close);
        var jbpointer=document.createElement("div");
        jbpointer.setAttribute("class","jBox-pointer jBox-pointer-bottom");
        jbpointer.style.left="0px";
        jbpointer.style.marginLeft= "20px";
        jbpointer.style.height="14px";
        div.appendChild(container_div);
        div.appendChild(jbpointer);
        return div;
    }
}
function email_exists(e)
{
var email= e.target.value;
    var email_id= e.target.parentElement.setAttribute("id","email_div");
    if(email!="") {
        var url = "controller/alchol.php";
        var req = create_request(url, 'emailCheck', email);
        req.onreadystatechange = function () {
            req.onload = function () {
                var data = JSON.parse(req.responseText);
                if (data.status == "exist") {
                    mark_field('email_div', 'notification_error.png');
                    window.localStorage.email_exist=1;
                }
                else {
                    mark_field('email_div', 'notification_done.png');
                    window.localStorage.email_exist=0;
                }
            }
        }
    }

}
function mark_field(email_div,src)
{
    var email_id=document.getElementById(email_div);
    var image=document.createElement("img");
    image.style.marginTop=-3.2+'%';
    image.setAttribute("class","end-image");
    image.setAttribute("src","img/"+src);
    email_id.appendChild(image);
}
function remove_image(id)
{
    var email_id=document.getElementById(id);
    if(email_id.lastElementChild.nodeName=="IMG") {
        var img_id = email_id.getElementsByClassName("end-image")[0];
        email_id.removeChild(img_id);
    }
}
function valid_selection(e)
{
    var element= e.target;
    if(element.value==0)
    {
        e.target.style.borderWidth="1px";
        e.target.style.borderStyle="solid";
        e.target.style.borderColor="red";
    }
}
function uploadManager(e)
{
var selection= e.target.value;
    var parent= e.target.parentElement;
    var current= e.target;
    var y=current.selectedIndex;
    var elem=current[y].innerHTML;
    if(selection!=0 && elem!="Others")
    {
        window.localStorage.fileUploader=Number(window.localStorage.fileUploader)+1;
        var x=current.selectedIndex;
        document_array.splice(document_array.indexOf(current[x].innerHTML),1);
        current.disabled=true;
        var image = document.createElement("input");
        image.setAttribute("type", "file");
        image.setAttribute("id", "docs"+current[x].innerHTML);
        image.setAttribute("data-id",current[x].innerHTML);
        image.setAttribute("class", "form-control");
        image.setAttribute("accept", "application/pdf");
        var button=addMoreButton();
        parent.appendChild(image);
        parent.appendChild(button);

    }
    else if(elem=="Others")
    {
        current.disabled = true;
        var input=document.createElement("input");
        input.setAttribute("id","others");
        input.type="text";
        input.setAttribute("class","form-control");
        input.setAttribute("placeholder","Name Of Document");
        parent.appendChild(input);
        var image = document.createElement("input");
        image.setAttribute("type", "file");
        image.setAttribute("id", "docs");
        image.setAttribute("data-id","docs");
        image.setAttribute("class", "form-control");
        image.setAttribute("accept", "application/pdf");
        parent.appendChild(image);
    }

}
function addMoreButton()
{
    var button=document.createElement("button");
    button.addEventListener("click",addUploadManager,true);
    button.setAttribute("type","button");
    button.setAttribute("class","btn btn-option3 btn-xs");
    var i=document.createElement("i");
    i.setAttribute("class","fa fa-plus");
    button.appendChild(i);
    var text=document.createTextNode("Add-More");
    button.appendChild(text);
    return button;
}
function addUploadManager()
{
    var elem=this;
    var parent=elem.parentElement;
    var select=document.createElement("select");
    select.addEventListener("change",function(e)
    {
        uploadHandle(e);
    });
    var opt=document.createElement("option");
    opt.value=0;
    opt.innerHTML="Select Value";
    select.appendChild(opt);
    for(var i=0;i<document_array.length;i++)
    {
            var option=document.createElement("option");
            option.value=i+1;
            option.innerHTML=document_array[i];
            select.appendChild(option);
    }
    parent.insertBefore(select,elem);
    parent.removeChild(parent.lastElementChild);
}
function uploadHandle(e)
{
    var selection= e.target.value;
    var parent= e.target.parentElement;
    var current= e.target;
    var y=current.selectedIndex;
    var elem=current[y].innerHTML;
    if(selection!=0 && elem!="Others") {
        window.localStorage.fileUploader = Number(window.localStorage.fileUploader) + 1;
        var x = current.selectedIndex;
        document_array.splice(document_array.indexOf(current[x].innerHTML), 1);
        current.disabled = true;
        var image = document.createElement("input");
        image.setAttribute("type", "file");
        image.setAttribute("id", "docs"+current[x].innerHTML);
        image.setAttribute("data-id", current[x].innerHTML);
        image.setAttribute("class", "form-control");
        image.setAttribute("accept", "application/pdf");
        var button = addMoreButton();
        parent.appendChild(image);
        parent.appendChild(button);
    }
    else if(elem=="Others")
    {
        current.disabled = true;
        var input=document.createElement("input");
        input.setAttribute("id","others");
        input.type="text";
        input.setAttribute("class","form-control");
        input.setAttribute("placeholder","Name Of Document");
        parent.appendChild(input);
        var image = document.createElement("input");
        image.setAttribute("type", "file");
        image.setAttribute("id", "docs");
        image.setAttribute("data-id","docs");
        image.setAttribute("class", "form-control");
        image.setAttribute("accept", "application/pdf");
        parent.appendChild(image);
    }
}
function remove_warning(e)
{
    var element= e.target;
    var parent= e.target.parentElement;
    if(parent.children.length>2) {
        var error_box = parent.getElementsByClassName("jBox-wrapper jBox-Tooltip jBox-TooltipBorder jBox-closeButton-box jBox-pointerPosition-bottom")[0];
        parent.removeChild(error_box);

    }
}
function user_exist(e) {
    var userName = e.target.value;
    var userId= e.target.parentElement.setAttribute("id","user_div");
    if(userName!="") {
        var url = "controller/alchol.php";
        var req = create_request(url, 'checkUser', userName);
        req.onreadystatechange = function () {
            req.onload = function () {
                var data = JSON.parse(req.responseText);
                if (data.status == "exist") {
                    mark_user('user_div', 'notification_error.png');
                    window.localStorage.user_exist=1;
                }
                else {
                    mark_user('user_div', 'notification_done.png');
                    window.localStorage.user_exist=0;
                }
            }
        }
    }
}
function mark_user(email_div,src)
{
    var email_id=document.getElementById(email_div);
    var image=document.createElement("img");
    image.style.marginTop=-3.2+'%';
    image.setAttribute("class","end-image");
    image.setAttribute("src","img/"+src);
    email_id.appendChild(image);
}
function submit_form()
{
    var form=document.getElementById("forms");
    var button=document.getElementById("button11");
    form.addEventListener("submit",function(e)
    {
        e.preventDefault();
    });
    button.addEventListener("click",function(e)
    {
        var selector=document.getElementById("register-changer");
        var x=selector.selectedIndex;
        if(selector[x].innerHTML=="Restaurants") {
            if (check_fields() == true && check_exist()==true ) {
                send_form(e);
            }
        }
    });
}
function doc_uploader(e)
{
    var element= e.target.parentElement;
    if(e.target.value==1)
    {
        var image = document.createElement("input");
        image.setAttribute("type", "file");
        image.setAttribute("id", "docs"+ e.target.value);
        image.setAttribute("data-id", e.target.value);
        image.setAttribute("class", "form-control");
        image.setAttribute("accept", "application/pdf");
        element.appendChild(image);
    }
    else
    {
        if(element.lastElementChild.nodeName=="INPUT")
        {
            element.removeChild(element.lastElementChild);
        }
    }
}
function send_form(e)
{
    var tags='';
    for(x in elementcount)
    {
        tags +=','+elementcount[x];
    }
    var formdata=new FormData();
    var resturant_name=document.getElementById("example10");
    formdata.append("restaurant_name",resturant_name.value);
    var restaurant_email=document.getElementById("example11");
    formdata.append("email",restaurant_email.value);
    var address=document.getElementById("address").value;
    var address1 = document.getElementById("address2").value;
    formdata.append("address",address+" "+address1);
    var state=document.getElementById("city_name");
    var x = state.selectedIndex;
    formdata.append("state",state[x].innerHTML);
    var city=document.getElementById("states");
    formdata.append("city",city.value);
    var mobile=document.getElementById("tel-number");
    formdata.append("mobile",mobile.value);
    var website=document.getElementById("website");
    formdata.append("web",website.value);
    var area=document.getElementById("area");
    formdata.append("area",area.value);
    var docs=document.getElementById("docs");
    var username=document.getElementById("username");
    formdata.append("username",username.value);
    var password=document.getElementById("password");
    formdata.append("password",password.value);
    var pincode=document.getElementById("pinCode");
    formdata.append("pincode",pincode.value);
    if(document.getElementById("others"))
    {
        formdata.append("docType",document.getElementById("others").value);
    }
    var docs_div=docs.parentElement;
    for(var i=0;i<docs_div.children.length;i++)
    {
        if(docs_div.children[i].nodeName=="INPUT" && docs_div.children[i].getAttribute("type")=="file")
        {
           var data= docs_div.children[i].getAttribute("data-id");
            if(data !="docs") {
                formdata.append(data, docs_div.children[i].files[0]);
            }
            else
            {
                formdata.append(document.getElementById("others").value, docs_div.children[i].files[0]);
            }
        }
    }
    var alcohol=document.getElementById("Alcohol");
    if(alcohol.value==0)
    {
    formdata.append("alcohol",0);
    }
    else if(alcohol.value==1)
    {
        var parent=alcohol.parentElement;
        var doc=document.getElementById("docs1");
        formdata.append("alcohol",1);
        formdata.append("docs_alchol",doc.files[0]);
    }
    formdata.append("tags",tags.slice(1,tags.length));
    formdata.append("request1","restaurant_upload");
    var req=createXhr();
    req.open("POST","controller/alchol.php",true);
    req.send(formdata);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            loadmap(req.responseText);
        }
    }
}
function check_fields()
{
    var form=document.getElementById("forms");
    var flag=0;
    for(var i=0;i<form.children.length;i++)
    {
        if(form.children[i].nodeName=="DIV")
        {
            if(form.children[i].children[1].nodeName=="INPUT")
            {
                if(form.children[i].children[1].value=="")
                {
                    form.children[i].children[1].focus();
                    flag++;
                }
            }
            else if(form.children[i].children[1].nodeName=="DIV")
            {
            var length=form.children[i].children[1].children[0].children.length;
                if(length==0)
                {
                    document.getElementById("meta").focus();
                    flag++;
                }
            }
        }
    }
    if(flag>0)
    {
        return false;
    }
    else{
        return true;
    }
}
function check_exist()
{
    if(window.localStorage.email_exist==1 || window.localStorage.user_exist==1)
    {
        return false;
    }
    else
    {
        return true;
    }
}
function transform()
{
    var transformer=document.getElementById("register-changer");
    transformer.addEventListener("change",function(e)
    {
    if(e.target.value=="eventManager")
    {
        e.target.disabled=true;
        update_Fields();
    }
    });
}
function update_Fields(node)
{
var form=document.getElementById("forms");
    var div_Agency=document.getElementsByClassName("form-group")[0];
    div_Agency.children[0].innerHTML="Agency-Name";
    div_Agency.removeChild(div_Agency.lastElementChild);
    var input_agency=document.createElement("input");
    input_agency.setAttribute("type","text");
    input_agency.setAttribute("required","");
    input_agency.setAttribute("id","agency_name");
    input_agency.setAttribute("class","form-control");
    div_Agency.appendChild(input_agency);
    var div_agent_name=document.createElement("div");
    div_agent_name.setAttribute("class","form-group");
    var label=document.createElement("label");
    label.setAttribute("class","form-label");
    label.setAttribute("for","Agent");
    label.innerHTML="Agent-Name";
    div_agent_name.appendChild(label);
    var input_agent=document.createElement("input");
    input_agent.setAttribute("type","text");
    input_agent.setAttribute("id","agent_name");
    input_agent.setAttribute("class","form-control");
    input_agent.setAttribute("required","");
    div_agent_name.appendChild(input_agent);
    var reference_div=document.getElementsByClassName("form-group")[1];
    var new_reference_div=reference_div.cloneNode(true);
    form.insertBefore(div_agent_name,reference_div);
    form.removeChild(reference_div);
    var reference_email=document.getElementsByClassName("form-group")[2];
    form.insertBefore(new_reference_div,reference_email);
    var username=document.getElementById("username");
    var user_div=username.parentElement;
    form.removeChild(user_div);
    var password=document.getElementById("password");
    var password_div=password.parentElement;
    form.removeChild(password_div);
    form.removeAttribute("id");
    form.setAttribute("id","event_manager");
    var button=document.getElementById("button11");
    button.removeAttribute("id");
    button.setAttribute("id","submit")
}
function manager_submit()
{
    var manager=document.getElementById("event_manager");
    form_validation();
    manager.addEventListener("submit",function(e)
    {
        e.preventDefault();
        parse_form();

    });
}
function parse_form()
{
    var flag=0;
    var form=document.getElementById("event_manager");
    for(var i=0;i<form.children.length-1;i++)
    {
        var element=form.children[i];
        if(element.children[1].nodeName=="INPUT")
        {
            if(element.children[1].getAttribute("type")=="text")
            {
                var text=element.children[1].value;
                if(text.value=="")
                {
                    flag++;
                    element.children[1].focus();
                }
            }
        }
        else if(element.children[1].nodeName=="DIV")
        {
            if(element.children[1].children[0].children.length==0)
            {
                flag++;
                document.getElementById("meta").focus();
            }
        }
    }
    if(flag==0 && storage.length==0 &&localStorage.Manager==0)
    {
        Manager_form_send();
    }
}
function form_validation()
{
    var agency_name=document.getElementById("agency_name");
    var agent_name=document.getElementById("agent_name");
    var email=document.getElementById("example11");
    var address=document.getElementById("address");
    var address1=document.getElementById("address2");
    var state=document.getElementById("city_name");
    var mobile=document.getElementById("tel-number");
    var city=document.getElementById("states");
    var docs=document.getElementById("docs");
    var area=document.getElementById("area");
    var pincode=document.getElementById("pinCode");
    var meta=document.getElementById("meta");
    var alcohol=document.getElementById("Alcohol");
    agency_name.addEventListener("blur",function(e)
    {
        var name=agency_name.value;
        var pattern=/^[a-zA-Z][a-zA-Z0-9\s]+$/;
        isValid(pattern,e,name);
    },false);
    agency_name.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    agent_name.addEventListener("blur",function(e)
    {
        var name=agent_name.value;
        var pattern=/^[a-zA-Z][a-zA-Z0-9\s]+$/;
        isValid(pattern,e,name);
    },false);
    agent_name.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    email.addEventListener("blur",function(e)
    {
        var email_id=email.value;
        var pattern=/^[a-zA-Z0-9\-\_.]+@[a-zA-Z0-9]+/;
        isValid(pattern,e,email_id);
        mangerMail_exists(e);
    },false);
    email.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        remove_image('email_div');
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    address.addEventListener("blur",function(e)
    {
        var address_val=address.value;
        var pattern=/[a-zA-Z0-9\s#]+/;
        isValid(pattern,e,address_val);
    });
    address.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    state.addEventListener("blur",function(e)
    {
        valid_selection(e)
    });
    state.addEventListener("focus",function(e)
    {
        e.target.removeAttribute("style");
    });
    city.addEventListener("blur",function(e)
    {
        valid_selection(e)
    });
    city.addEventListener("focus",function(e)
    {
        e.target.removeAttribute("style");
    });
    mobile.addEventListener("blur",function(e)
    {
        var mobile_number=mobile.value;
        var pattern=/[0-9]{10}/;
        isValid(pattern,e,mobile_number);
    });
    mobile.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    },true);
    area.addEventListener("blur",function(e)
    {
    var area_name=area.value;
        var pattern=/[a-zA-Z]/;
        isValid(pattern,e,area_name);
    },true);
    area.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    pincode.addEventListener("blur",function(e)
    {
    var pin=pincode.value;
        var pattern=/[0-9]{6}/;
        isValid(pattern,e,pin);
    });
    pincode.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    alcohol.addEventListener("blur",function(e)
    {
    var element= e.target;
        var x=element.selectedIndex;
        var selected_item=element[x];
    });
}
function mangerMail_exists(e)
{
    var top_div= e.target.parentElement;
    top_div.setAttribute("id","email_div");
    var url="controller/alchol.php";
    var req=create_request(url,"managerMail", e.target.value);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var data=JSON.parse(req.responseText);
            if(data.Email=="Email Exist")
            {
                mark_field("email_div",'notification_error.png');
                localStorage.Manager=1;
            }
            else
            {
                mark_field("email_div",'notification_done.png');
                localStorage.Manager=0;
            }
        }
    }
}
function Manager_form_send()
{
    var tags='';
    for(x in elementcount)
    {
        tags +=','+elementcount[x];
    }
    var formdata=new FormData();
    var agency_name=document.getElementById("agency_name");
    formdata.append("agency_name",agency_name.value);
    var agent_name=document.getElementById("agent_name");
    formdata.append("agent_name",agent_name.value);
    var email=document.getElementById("example11");
    formdata.append("email",email.value);
    var address=document.getElementById("address");
    var address1=document.getElementById("address2");
    formdata.append("address",address.value +''+address1.value);
    var state=document.getElementById("city_name");
    var j=state.selectedIndex;
    formdata.append("state",state[j].innerHTML);
    var mobile=document.getElementById("tel-number");
    formdata.append("mobile",mobile.value);
    var city=document.getElementById("states");
    formdata.append("city",city.value);
    var docs=document.getElementById("docs");
    var area=document.getElementById("area");
    formdata.append("area",area.value);
    var pincode=document.getElementById("pinCode");
    formdata.append("pincode",pincode.value);
    formdata.append("tags",tags.slice(1,tags.length));
    var website=document.getElementById("website");
    formdata.append("website",website.value);
    var doc_div=docs.parentElement;
    if(document.getElementById("others"))
    {
        formdata.append("docType",document.getElementById("others").value);
    }
    var docs_div=docs.parentElement;
    for(var i=0;i<docs_div.children.length;i++)
    {
        if(docs_div.children[i].nodeName=="INPUT" && docs_div.children[i].getAttribute("type")=="file")
        {
            var data= docs_div.children[i].getAttribute("data-id");
            if(data !="docs") {
                formdata.append(data, docs_div.children[i].files[0]);
            }
            else
            {
                formdata.append(document.getElementById("others").value, docs_div.children[i].files[0]);
            }
        }
    }
    var alcohol=document.getElementById("Alcohol");
    if(alcohol.value==0)
    {
        formdata.append("alcohol",0);
    }
    else if(alcohol.value==1)
    {
        var parent=alcohol.parentElement;
        var doc=document.getElementById("docs1");
        formdata.append("alcohol",1);
        formdata.append("docs_alchol",doc.files[0]);
    }
    formdata.append("request1","managerRegister")
    var url="controller/alchol.php";
    var req=createXhr();
    req.open("POST",url,true);
    req.send(formdata);
    req.upload.addEventListener('loadstart', function(e) {
        // When the request starts.
    });
    req.upload.addEventListener('progress', function(e) {
        // While sending and loading data.
    });
    req.upload.addEventListener('load', function(e) {
        // When the request has *successfully* completed.
        // Even if the server hasn't responded that it finished.
    });
    req.upload.addEventListener('loadend', function(e) {
        // When the request has completed (either in success or failure).
        // Just like 'load', even if the server hasn't
        // responded that it finished processing the request.
    });
    req.upload.addEventListener('error', function(e) {
        // When the request has failed.
    });
    req.upload.addEventListener('abort', function(e) {
        // When the request has been aborted.
        // For instance, by invoking the abort() method.
    });
    req.upload.addEventListener('timeout', function(e) {
        // When the author specified timeout has passed
        // before the request could complete.
    });
    req.onreadystatechange=function()
    {
        req.onload=function(e)
        {
            var data=JSON.parse(req.responseText);
            if(data.state==1)
            {
                alert("Thanks For registration");
                document.getElementById("event_manager").reset();
            }
            else
            {
                alert("Not Registered");
            }
        }
    }
}
/*** Event-coOrdinator***/
function displayPic()
{
    var top=document.getElementById("top");
    var nextNode=top.nextElementSibling.nextElementSibling;
    var row=nextNode.children[1];
    var col=row.children[0];
    var col1=col.children[0];
    var button=col1.children[0];
    var button1=col1.children[1];
    button.addEventListener("mouseover",changeopacity);
    button.addEventListener("mouseout",updateOpacity);
    button1.addEventListener("mouseover",changeopacity);
    button1.addEventListener("mouseout",updateOpacity);
}
function changeopacity(event)
{
    var top=document.getElementById("top");
    var nextNode=top.nextElementSibling.nextElementSibling;
    var row=nextNode.children[1];
    var col=row.children[0];
    var col1=col.children[0];
    var button=col1.children[1];
    button.style.opacity="1";
    button.addEventListener("click",function(e)
    {   if(!document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0]) {
        var lightBox = new LightBoxPanel("upload-Image", "file", "image/*");
        var base = document.getElementsByTagName("body")[0];
        var neighbour = base.firstElementChild;
        base.insertBefore(lightBox.createBody(), neighbour);
    }
    });
}
function updateOpacity()
{
    var top=document.getElementById("top");
    var nextNode=top.nextElementSibling.nextElementSibling;
    var row=nextNode.children[1];
    var col=row.children[0];
    var col1=col.children[0];
    var button=col1.children[1];
    button.style.opacity="0";
}
function change_type() {
    var frame = document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
    var file_uploader = document.getElementById("profile-pic");
    var input = file_uploader.children[0];
    input.setAttribute("accept", "image/*");
    if (document.getElementById("submit-photo")) {
        var button = document.getElementById("submit-photo");
        var button_container = button.parentElement;
        var new_button = button.cloneNode(true);
        button_container.removeChild(button);
        new_button.setAttribute("id", "display_pic");
        new_button.setAttribute("class", "btn-submit");
        button_container.appendChild(new_button);
        new_button.addEventListener("click", function (e) {
            var progress=progressBar();
            var elem=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
            elem.appendChild(progress);
           var profile = document.getElementById("profile-pic");
            var formdata = new FormData();
            formdata.append("request1", "ProfileImg");
            formdata.append("request2", loc);
            formdata.append("profile_pic", profile.children[0].files[0]);
            var req = createXhr();
            req.open("POST", "controller/alchol.php", true);
            req.send(formdata);
                req.upload.addEventListener("progress",function(e)
                {
                    if(e.lengthComputable)
                    {
                        var percent=Math.round((e.loaded/ e.total)*100);
                        var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
                        var progress=element.lastElementChild.children[0];
                        progress.style.width=percent+'%';
                    }
                });
                req.upload.addEventListener("load",function(e)
                {
                    var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
                    var progress=element.lastElementChild;
                    success_msg("Image Uploaded Sucessfully","fa fa-check");
                });
                req.upload.addEventListener("error",function(e)
                {
                    error_message("Error in Upload","fa fa-lock");
                });
            req.onreadystatechange=function() {
                if (req.readyState == 4 && req.status == 200) {
                    var data = JSON.parse(req.responseText);
                    if (data.state == 3) {
                        var img = document.getElementsByClassName("col-lg-8 col-md-6 titles")[0];
                        var span = img.firstElementChild.children[0];
                        var image_detail = span.src.split('/');
                        var source = image_detail[5];
                       span.src = "event_manager/" + source + "/profile_pic/" + data.message;
                    }
                }
            }
        },true);
    }
}
function check_profile_pic()
{
    var url="controller/alchol.php";
    var req=create_request(url,'managerProfile',loc);
    req.onreadystatechange=function() {
        if(req.readyState==4 && req.status==200) {
            var data=JSON.parse(req.responseText);
            if(data.state==1)
            {
                var cid=data.id;
                var id=cid.substr(3,cid.length);
                var path=data.image;
                var real_path='event_manager/manager_id'+id+'/profile_pic/'+path;
                var button=document.getElementById("control_gen_3");
                var parent=button.parentElement;
                parent.children[0].setAttribute("src",real_path);
            }
        }
    }
}
function transformTime(time)
{
var split=time.split("-");
    var hour=split[0];
    var min=split[1];
    var sec=split[2];
    var res=hour+':'+min+':'+sec;
    return res;
}

function subAdmin()
{
    var sidebar=document.getElementsByClassName("sidebar clearfix")[0];
    var sideMenu=sidebar.children[0];
    var side=sideMenu.children[2];
    var sub_admin=sideMenu.children[3];
    side.addEventListener("click",function(e)
    {
        checkPrivilages();

    });
    sub_admin.addEventListener("click",function(e)
    {
        authorize();
    });
}
function checkPrivilages()
{
    var url="controller/alchol.php";
    var req=create_request(url,'checkPrivilage','admin');
    var flag=0;
    req.onreadystatechange=function()
    {
        if(req.status==200 && req.readyState==4)
        {
            var data=JSON.parse(req.responseText);
            if(data.status==1)
            {
                location.assign("register.php");
            }
            else
            {
                flag=0;
            }
        }
    };
}
function createSubAdmin()
{
   var form=document.getElementById("forms");
    var userName=form.children[1].children[0].children[0];
    var password=form.children[1].children[2].children[0];
    var email=form.children[1].children[1].children[0];
    var password1=form.children[1].children[3].children[0];
    form.addEventListener("submit",function(e)
    {
        e.preventDefault();
        e.stopPropagation();
        checkValue();
        if(storage.length==0 && localStorage.user_exist==0 && localStorage.mail_exist==0 && localStorage.empty==0)
        {
            var url="controller/alchol.php";
            var req=create_request(url,"SubAdmin",userName.value,password.value,email.value);
            req.onreadystatechange=function()
            {
                if(req.status==200 && req.readyState==4)
                {
                    var data=JSON.parse(req.responseText);
                    if(data.state==1) {
                        form.reset();
                    }
                    if(data.state==1)
                    {
                        alert("Sign-In to Continue");
                        form.reset();
                        location.assign("subadmin.php");
                    }
                    if(data.state==2)
                    {
                        alert("You donot have this privilage");
                        form.reset();
                    }
                    if(data.state==0)
                    {
                        alert("Error in creating sub-Admin");
                        form.reset();
                    }
                }
            }
        }
    });
    parseData();
}
function parseData()
{
    var form=document.getElementById("forms");
    var userName=form.children[1].children[0].children[0];
    var password=form.children[1].children[2].children[0];
    var email=form.children[1].children[1].children[0];
    var password1=form.children[1].children[3].children[0];
    userName.focus();
    userName.addEventListener("blur",function(e)
    {
    var data=userName.value;
        var pattern=/^[a-z]+[a-z0-9_\.]/;
        isValid(pattern,e,data);
        validUser(e);
    });
    userName.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
        updateWarning(e);
    });
    email.addEventListener("blur",function(e)
    {
        var data=email.value;
        var pattern=/^[a-z]+[a-z0-9_\.]+\@+[a-z0-9]+\.[a-z]+(\.)?([a-z]{2,9})/;
        isValid(pattern,e,data);
        validEmail(e);
    });
    email.addEventListener("focus",function(e)
    {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
        updateWarning(e)
    });
    password.addEventListener("blur", function (e) {
       var pattern=/^[a-zA-Z0-9!@#$%^&*]{6,}/;
        var data=password.value;
        isValid(pattern,e,data);
    });
    password.addEventListener("focus", function (e) {
        e.target.parentElement.removeAttribute("class");
        e.target.parentElement.setAttribute("class","group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    password1.addEventListener("blur",function(e)
    {
    var oldValue=password.value;
        if(oldValue !="") {
            if (oldValue != e.target.value) {
                e.target.style.background = "#FF0000";
                storage.push(e.target.getAttribute("id"));
            }
            else {
                e.target.style.background = "#00FF7F";
            }
        }
    });
    password1.addEventListener("focus", function (e) {
        e.target.style.background="#FFFFFF";
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
}
function validUser(e) {
    var userName = e.target.value;
    var userId= e.target.parentElement.setAttribute("id","user_div");
    if(userName!="") {
        var url = "controller/alchol.php";
        var req = create_request(url, 'adminCheck', userName);
        req.onreadystatechange = function () {
            req.onload = function () {
                var data = JSON.parse(req.responseText);
                if (data.status == "exist") {
                    mark('user_div', 'notification_error.png');
                    window.localStorage.user_exist=1;
                }
                else {
                    mark('user_div', 'notification_done.png');
                    window.localStorage.user_exist=0;
                }
            }
        }
    }
}
function updateWarning(e)
{
    var parent= e.target.parentElement;
    if(parent.lastElementChild.getAttribute("class")=="end-image")
    {
        parent.removeChild(parent.lastElementChild);
    }
}
function mark(email_div,src)
{
    var email_id=document.getElementById(email_div);
    var image=document.createElement("img");
    image.style.marginTop=-11.2+'%';
    image.setAttribute("class","end-image");
    image.setAttribute("src","img/"+src);
    email_id.appendChild(image);
}
function validEmail(e)
{
    var email = e.target.value;
    var userId= e.target.parentElement.setAttribute("id","email_div");
    if(email!="") {
        var url = "controller/alchol.php";
        var req = create_request(url, 'adminMailCheck', email);
        req.onreadystatechange = function () {
            req.onload = function () {
                var data = JSON.parse(req.responseText);
                if (data.status == "exist") {
                    mark('email_div', 'notification_error.png');
                    window.localStorage.mail_exist=1;
                }
                else {
                    mark('email_div', 'notification_done.png');
                    window.localStorage.mail_exist=0;
                }
            }
        }
    }
}
function checkValue()
{
    var form=document.getElementById("forms");
    var container=form.children[1];
    for(var i=0;i<container.children.length;i++)
    {
        if(container.children[i].getAttribute("class")=="group")
        {
            if(container.children[i].children[0].value=="")
            {
                container.children[i].children[0].focus();
                localStorage.empty=1;
                break;
            }
            else
            {
                localStorage.empty=0;
            }
        }
    }

}
function authorize()
{
    var url="controller/alchol.php";
    var req=create_request(url,'viewSubAdmin');
    req.onreadystatechange= function () {
        if(req.readyState==4 && req.status==200)
        {
        var data=JSON.parse(req.responseText);
            if(data.status==1)
            {
            location.assign("subadmin.php");
            }
            else
            {
                alert("Not Allowed");
            }
        }
    }
}
function Manage()
{
    var table=document.getElementById("example0");
    var tbody=table.children[1];
    for(var i=0;i<tbody.children.length;i++)
    {
        var tr=tbody.children[i];
        var name=tr.children[0].children[0];
        var AddPrivilege=tr.children[2];
        var button=AddPrivilege.children[0];
        button.addEventListener("click",function(e)
        {
            createTask(e);
        });

    }
}
function createTask()
{
    var lightbox_back=create_lightboxBackground();
    var body=document.getElementsByTagName("body")[0];
    var first_child=body.children[0];
    var bone=light_box_head('Sub-Admin');
    var timeline=timeLine(arguments[0]);
    bone.appendChild(timeline);
    lightbox_back.appendChild(bone);
    body.insertBefore(lightbox_back,first_child);
    var lightbox_container=document.getElementsByClassName("dialog-container")[0];
    lightbox_container.style.width=(screen.availWidth)/2+'px';
    lightbox_container.style.left=(screen.availWidth)/4+'px';
    toggle();


}
function timeLine()
{
    var section=document.createElement("section");
    section.setAttribute("id","cd-timeline");
    section.setAttribute("class","cd-container");
    var timeLineBlock=timeLineData(arguments[0]);
    var timelineBlock2=line();
    section.appendChild(timeLineBlock);
    section.appendChild(timelineBlock2);
    return section;
}
function checkBox(data)
{
    var labelData=['View','Modify','Transaction','Featured','Approval','subAdmin','Rating','userGenerate','checkWallet','checkTicket','GenerateCupon'];
    var checkBoxDiv=document.createElement("div");
    checkBoxDiv.style.width= 21+'%';
    checkBoxDiv.style.marginLeft= 64+'%';
    checkBoxDiv.style.marginTop= -7+'%';
    checkBoxDiv.style.float="left";
    checkBoxDiv.setAttribute("id","selection");
    if(data.state==1) {
        var view = datas(data.View, 'view');
        var modify = datas(data.Modify, 'Modify');
        var Transaction = datas(data.Transaction, 'Transaction');
        var Featured = datas(data.Featured, 'Featured');
        var Approval = datas(data.Approval, 'Approval');
        var subAdmin = datas(data.subAdmin, 'subAdmin');
        var Rating = datas(data.Rating, 'Rating');
        var userGenerate = datas(data.userGenerate, 'Generate-user');
        var checkWallet = datas(data.checkWallet, 'CheckWallet');
        var checkTicket = datas(data.checkTicket, 'CheckTicket');
        var GenerateCupon = datas(data.GenerateCupon, 'GenerateCupon');
        checkBoxDiv.appendChild(view);
        checkBoxDiv.appendChild(modify);
        checkBoxDiv.appendChild(Transaction);
        checkBoxDiv.appendChild(Featured);
        checkBoxDiv.appendChild(Approval);
        checkBoxDiv.appendChild(subAdmin);
        checkBoxDiv.appendChild(Rating);
        checkBoxDiv.appendChild(userGenerate);
        checkBoxDiv.appendChild(checkWallet);
        checkBoxDiv.appendChild(checkTicket);
        checkBoxDiv.appendChild(GenerateCupon);
        checkBoxDiv.appendChild(submitButton());
        return checkBoxDiv;
    }
    else
    {
        var view = datas(0, 'view');
        var modify = datas(0, 'Modify');
        var Transaction = datas(0, 'Transaction');
        var Featured = datas(0, 'Featured');
        var Approval = datas(0, 'Approval');
        var subAdmin = datas(0, 'subAdmin');
        var Rating = datas(0, 'Rating');
        var userGenerate = datas(0, 'Generate-user');
        var checkWallet = datas(0, 'CheckWallet');
        var checkTicket = datas(0, 'CheckTicket');
        var GenerateCupon = datas(0, 'GenerateCupon');
        checkBoxDiv.appendChild(view);
        checkBoxDiv.appendChild(modify);
        checkBoxDiv.appendChild(Transaction);
        checkBoxDiv.appendChild(Featured);
        checkBoxDiv.appendChild(Approval);
        checkBoxDiv.appendChild(subAdmin);
        checkBoxDiv.appendChild(Rating);
        checkBoxDiv.appendChild(userGenerate);
        checkBoxDiv.appendChild(checkWallet);
        checkBoxDiv.appendChild(checkTicket);
        checkBoxDiv.appendChild(GenerateCupon);
        checkBoxDiv.appendChild(submitButton());
        return checkBoxDiv;
    }
}
function timeLineData()
{
    var timeLineBlock=document.createElement("div");
    timeLineBlock.setAttribute("class","cd-timeline-block");
    var ImageDiv=document.createElement("div");
    ImageDiv.setAttribute("class","cd-timeline-img cd-picture");
    var Image=document.createElement("img");
    Image.setAttribute("data-id",arguments[0].target.getAttribute("data-id"));
    Image.src="img/cd-icon-location.svg";
    ImageDiv.appendChild(Image);
    timeLineBlock.appendChild(ImageDiv);
    var timeLineContent=document.createElement("div");
    timeLineContent.setAttribute("class","cd-timeline-content");
    timeLineContent.innerHTML=arguments[0].target.parentElement.previousElementSibling.previousElementSibling.children[0].innerHTML;
    timeLineBlock.appendChild(timeLineContent);
    return timeLineBlock;
}
function line()
{
    var elem=document.createElement("span");
    elem.setAttribute("class","st-line")
    elem.style.marginRight=34+'%';
    elem.style.float="right";
    elem.style.marginTop=-47+'px';
    elem.style.cursor="pointer";
    elem.innerHTML="-------------------------------------------<i class=\"fa fa-plus\"></i>";
    return elem;
}
function toggle()
{
    var elem=document.getElementById("cd-timeline");
    var plus=elem.getElementsByTagName("span")[0];
    plus.addEventListener("click",function(e)
    {
       if (e.target.getAttribute("class") == "fa fa-plus") {
           e.target.setAttribute("class", "fa fa-minus");
           selectionBox(e);
       }
       else {
               e.target.setAttribute("class", "fa fa-plus");
               removeBox(e);
       }
    });
}
function selectionBox(e)
{
    var url="controller/alchol.php";
    var data=document.getElementsByClassName("cd-timeline-img cd-picture")[0].children[0].getAttribute("data-id");
    var req=create_request(url,'checkAssigned',data);
    req.onreadystatechange=function() {
        if(req.status==200 && req.readyState==4) {
            var data=JSON.parse(req.responseText);
            var parent = e.target.parentElement.parentElement;
            parent.appendChild(checkBox(data));
            submitPrivilege();
        }
    }
}
function removeBox(e)
{
    var parent= document.getElementById("selection").parentElement;
    parent.removeChild(document.getElementById("selection"));
}
function datas()
{
    if(arguments[0]==1) {
        var div = document.createElement("div");
        div.setAttribute("class", "form-group");
        var input = document.createElement("input");
        input.setAttribute("type", "checkbox");
        input.checked = true;
        input.value = arguments[1];
        var label = document.createElement("label");
        label.setAttribute("for", "View");
        label.style.marginLeft = 4 + 'px';
        //label.style.verticalAlign = 10 + 'px';
        label.innerHTML = arguments[1];
        div.appendChild(input);
        div.appendChild(label);
        return div;
    }
    if(arguments[0]==0) {
        var div = document.createElement("div");
        div.setAttribute("class", "form-group");
        var input = document.createElement("input");
        input.setAttribute("type", "checkbox");
        input.checked = "";
        input.value = arguments[1];
        var label = document.createElement("label");
        label.setAttribute("for", "View");
        label.style.marginLeft = 4 + 'px';
        //label.style.verticalAlign = 10 + 'px';
        label.innerHTML = arguments[1];
        div.appendChild(input);
        div.appendChild(label);
        return div;
    }
}
function submitButton()
{
    var a=document.createElement("a");
    a.setAttribute("class","btn btn-rounded btn-default");
    a.innerHTML="Add-privilege";
    return a;
}
function submitPrivilege()
{
    var section=document.getElementById("selection");
    section.getElementsByClassName("btn btn-rounded btn-default")[0].addEventListener("click",function(e)
    {
    sendselection(e);
    });
}
function sendselection(e)
{
    var current=e;
    var section=document.getElementById("selection");
    var query='';
    for(var i=0;i<section.children.length;i++)
    {
        if(section.children[i].getAttribute("class")=="form-group")
        {
            if(section.children[i].children[0].checked==true)
            {
                query +=section.children[i].children[0].value+'=true&';
            }
            else
            {
                query +=section.children[i].children[0].value+'=false&';
            }
        }
    }
    query +='request1=validateSubadmin&';
    var said=document.getElementById("cd-timeline").getElementsByClassName("cd-timeline-img cd-picture")[0].children[0].getAttribute("data-id");
    query +='aid='+said;
    var url="controller/alchol.php";
    var req=createXhr();
    req.open('POST',url,true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(query);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var data=JSON.parse(req.responseText);
            if(data.state==0)
            {
                alert("Error in Assigning permission");
            }
            if(data.state==1)
            {
                alert("Permission is added");
            }
            if(data.state==2)
            {
                alert("Permission Updated");
            }
        }
    }
}
function manage_cupon()
{
    var mainContainer=document.getElementsByClassName("container-padding")[0];
    var row=mainContainer.getElementsByClassName("row")[0];
    var formGroup=row.getElementsByClassName("form-horizontal")[0];
    var couponName=document.getElementById("input2");
    couponName.focus();
    var zipCode=document.getElementById("pinCode");
    couponName.addEventListener("blur",function(e)
    {
        var data=couponName.value;
        var pattern=/^[a-zA-Z]+[a-zA-Z0-9]/;
        ValidPattern(pattern,e,data);
        validEntry(e);
    });
    couponName.addEventListener("focus",function(e)
    {
        e.target.parentElement.parentElement.removeAttribute("class");
        e.target.parentElement.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
        removeCouponImage(e);
    });
    var code=document.getElementById("couponCode");
    code.addEventListener("blur",function(e)
    {
        var data= e.target.value;
        validCode(e);
    });
    code.addEventListener("focus",function(e)
    {
        removeCodeImage(e);
    });
    zipCode.addEventListener("blur",function(e)
    {
    var data= zipCode.value;
        var pattern=/^[1-9]+[0-9]{5}/;
        ValidPattern(pattern,e,data);
    });
    zipCode.addEventListener("focus",function(e)
    {
        e.target.parentElement.parentElement.removeAttribute("class");
        e.target.parentElement.parentElement.setAttribute("class","form-group");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    var AmountDiv=formGroup.children[1];
    var cashBack=formGroup.children[2];
    var shippingCost=formGroup.children[3];
    var convenience=formGroup.children[4];
    var one=formGroup.children[5].children[1].children[0];
    var multiple=formGroup.children[5].children[1].children[1];
    var date=formGroup.children[8].children[0].children[1].children[0].children[0].children[1];
    var lifetime=formGroup.children[8].children[1];
    var selectionOption=formGroup.children[7].children[1].children[0];
    var ageGroup=formGroup.children[9].children[1];
    var pincodeAdd=document.getElementById("picode-Add-btn");
    var submitBtn=document.getElementsByClassName("form-horizontal")[0];
    FormEvents(AmountDiv);
    FormEvents(cashBack);
    FormEvents(shippingCost);
    FormEvents(convenience);
    radioSelection(one);
    radioSelection(multiple);
    lifeTime(lifetime);
    restaurantChanges(selectionOption);
    ageOption(ageGroup);
    zipAddOption(pincodeAdd);
    generateCoupon(submitBtn);
}
function edit_selector(e)
{
    var ul=document.createElement("ul");
    ul.setAttribute("id","mtdSelector");
    ul.setAttribute("class","dropdown-menu dropdown-menu-list");
    ul.style.display="block";
    var li=document.createElement("li");
    var a=document.createElement("a");
    a.addEventListener("click",function(e)
    {
        changeMtd(e);
    });
    var i=document.createElement("i");
    i.innerHTML="%";
    a.appendChild(i);
    li.appendChild(a);
    ul.appendChild(li);
    e.target.parentElement.parentElement.appendChild(ul);
}
function changeMtd(e)
{
    if(e.target.children[0].innerHTML=="%") {
        e.target.innerHTML = "";
        var newi = document.createElement("i");
        newi.setAttribute("class", "fa fa-rupee");
        e.target.appendChild(newi);
        var base_div = e.target.parentElement.parentElement.parentElement;
        var topDiv= e.target.parentElement.parentElement.parentElement.parentElement;
        topDiv.lastElementChild.setAttribute("placeholder","percent");
        topDiv.lastElementChild.setAttribute("data-type","percent");
        base_div.removeChild(base_div.children[0]);
        var d = document.createDocumentFragment();
        var ai=document.createElement("i");
        var stmt = document.createTextNode("%");
        ai.appendChild(stmt);
        var i = document.createElement("i");
        i.setAttribute("class", "fa fa-caret-down centric active");
        ai.appendChild(i);
        d.appendChild(ai);
        base_div.insertBefore(d, base_div.children[0]);
    }
    else{
        e.target.innerHTML="";
        e.target.innerHTML="%";
        var base_div = e.target.parentElement.parentElement.parentElement;
        var topDiv= e.target.parentElement.parentElement.parentElement.parentElement;
        topDiv.lastElementChild.setAttribute("placeholder","Amount");
        topDiv.lastElementChild.setAttribute("data-type","Amount");
        base_div.removeChild(base_div.childNodes[0]);
        base_div.removeChild(base_div.children[0]);
        var d = document.createDocumentFragment();
        var stmt = document.createElement("i");
        stmt.setAttribute("class","fa fa-rupee");
        var i = document.createElement("i");
        i.setAttribute("class", "fa fa-caret-down centric active");
        stmt.appendChild(i);
        d.appendChild(stmt);
        base_div.insertBefore(d, base_div.children[0]);
    }
}
function FormEvents(AmountDiv)
{
    var selector=AmountDiv.children[1].children[1];
    selector.addEventListener("click",function(e)
    {
        if(e.target==selector.children[0].children[0].children[0] && selector.children[0].lastElementChild.nodeName!="UL") {
            edit_selector(e);
        }
        else if(selector.children[0].lastElementChild.style.display=="block" && e.target==selector.children[0].children[0].children[0])
        {
            selector.children[0].lastElementChild.style.display="none";
        }
        else {
            if(selector.children[0].lastElementChild.style.display=="none"&& e.target==selector.children[0].children[0].children[0] )
            {
                selector.children[0].lastElementChild.style.display="block";
            }
        }
    });
    selector.children[1].addEventListener("blur",function(e)
    {
        var data= selector.children[1].value;
        var pattern=/[0-9](\.)?[0-9]/;
        validNumber(pattern,e,data);
    });
    selector.children[1].addEventListener("focus",function(e)
    {
        e.target.removeAttribute("style");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
}
function radioSelection(select)
{
    select.addEventListener("click",function(e)
    {
    if(e.target.children[0].value=="multiple" && e.target.parentElement.parentElement.lastElementChild.getAttribute("class")!="col-sm-10")
    {
        e.target.checked=true;
        createTextBox(e);
    }
        else
    {
        if(e.target.children[0].value==1)
        {
           if(e.target.parentElement.parentElement.lastElementChild.getAttribute("class")=="col-sm-10")
           {
               e.target.checked=true;
               e.target.parentElement.parentElement.removeChild(e.target.parentElement.parentElement.lastElementChild);
           }
        }
    }
    });
}
function createTextBox(e)
{
    var parent= e.target.parentElement.parentElement;
    var col=document.createElement("div");
    col.setAttribute("class","col-sm-10");
    var input_div=document.createElement("div");
    input_div.setAttribute("class","input-group flexible");
    var input=document.createElement("input");
    input.setAttribute("id","times");
    input.setAttribute("min",0);
    input.setAttribute("type","number");
    input.setAttribute("placeholder","Number of Times");
    input.setAttribute("class","form-control");
    input.addEventListener("blur",function(e)
    {
                var data= e.target.value;
                var pattern=/^[0-9]+[0-9]$/;
                validNumber(pattern,e,data);
    });
    input.addEventListener("focus",function(e)
    {
        e.target.removeAttribute("style");
        storage.forEach(function(data,index,array)
        {
            var id=e.target.getAttribute("id");
            if(data==id)
            {
                var index=array.indexOf(id);
                array.splice(index,1);
            }
        });
    });
    input_div.appendChild(input);
    col.appendChild(input_div);
    parent.appendChild(col);
}
function lifeTime(sketch)
{
    var btn=sketch.children[0];
    btn.addEventListener("change",function(e)
    {
        if(e.target.checked==true) {
            document.getElementById("date-picker").disabled = true;
        }
        else
        {
            if(e.target.checked==false)
            {
                document.getElementById("date-picker").disabled = false;
            }
        }
    });
}
function restaurantChanges(opt)
{
    var otions=opt.addEventListener("change",function(e)
    {
        var current= e.target;
        var index= e.target.selectedIndex;
       if(current[index].innerHTML=="Individual")
       {
           var indv= e.target.parentElement.parentElement.nextElementSibling;
            if(indv.getAttribute("data-in")!="create") {
                create_multiSelectBox(e)
            }
       }
        if(current[index].innerHTML=="All")
        {
            delete_selectBox(e);
        }

    });
}
function create_multiSelectBox(e)
{
    var parent=e.target.parentElement.parentElement.parentElement;
    var current= e.target.parentElement.parentElement;
    var neighbour=current.nextElementSibling;
    var formDiv=document.createElement("div");
    formDiv.setAttribute("data-in","create");
    formDiv.setAttribute("class","form-group");
    var label=document.createElement("label");
    label.setAttribute("class","col-sm-2 control-label form-label");
    label.innerHTML="Restaurant Names";
    formDiv.appendChild(label);
    var div=document.createElement("div");
    div.setAttribute("class","col-sm-10");
    var select=document.createElement("select");
    select.setAttribute("id","selection_value");
    select.multiple=true;
    div.appendChild(select);
    formDiv.appendChild(div);
    var url="controller/alchol.php";
    var req=create_request(url,'restaurantList');
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
            var data=JSON.parse(req.responseText);
            for(var i=0;i<data.length;i++)
            {
                var option=document.createElement("option");
                option.setAttribute("data-id",data[i].restaurat_id);
                option.innerHTML=data[i].restaurant_name;
                select.appendChild(option);
            }
        }
    };
    parent.insertBefore(formDiv,neighbour);
}
function delete_selectBox(e)
{
    var parent=e.target.parentElement.parentElement.parentElement;
    var current= e.target.parentElement.parentElement;
    var neighbour=current.nextElementSibling;
    if(neighbour.getAttribute("data-in")=="create")
    {
        parent.removeChild(neighbour);
    }
}
function ageOption(grp)
{
    var selection=grp.children[0];
    selection.addEventListener("change",function(e)
    {
    var current= e.target;
        var index= e.target.selectedIndex;
        if(current[index].innerHTML=="Individual")
        {
            create_MinMaxBox(e);
        }
        if(current[index].innerHTML=="All")
        {
            removeMinMax(e);
        }
    });
}
function create_MinMaxBox(e)
{
    var j=0;
    var sibling= e.target.parentElement.parentElement.nextElementSibling;
    var parent=sibling.parentElement;
    var vals=['Min-Age','Max-Age'];
    var box=document.createElement("div");
    box.setAttribute("class","form-group");
    box.setAttribute("id","age-section");
    box.setAttribute("data-in","age-group");
    var table=document.createElement("table");
    table.setAttribute("class","table-bordered table-striped md-form");
    var tr=document.createElement("tr");
    for(var i=0;i<2;i++)
    {
    var th=document.createElement("th");
        th.setAttribute("class","centralized");
        th.innerHTML=vals[i];
        tr.appendChild(th);
    }
    table.appendChild(tr);
    var tr=document.createElement("tr");
    var td=document.createElement("td");
    var minNumber=document.createElement("input");
    minNumber.setAttribute("type","number");
    minNumber.setAttribute("min",0);
    minNumber.setAttribute("id","min-Amount"+0);
    td.appendChild(minNumber);
    tr.appendChild(td);
    var maxTd=document.createElement("td");
    var maxNumber=document.createElement("input");
    maxNumber.setAttribute("type","number");
    maxNumber.setAttribute("min",0);
    maxNumber.setAttribute("id","max-Amount"+0);
    maxTd.appendChild(maxNumber);
    tr.appendChild(maxTd);
    var moreTr=document.createElement("tr");
    var td=document.createElement("td");
    var addMoreBtn=document.createElement("button");
    addMoreBtn.addEventListener("click",function(e)
    {
        j++;
    addNewMoreBtn(e,j);
    });
    addMoreBtn.setAttribute("type","button");
    addMoreBtn.setAttribute("class","btn btn-option3 btn-xs");
    var i=document.createElement("i");
    i.setAttribute("class","fa fa-plus");
    addMoreBtn.appendChild(i);
    var text=document.createTextNode("Add-More");
    addMoreBtn.appendChild(text);
    td.appendChild(addMoreBtn);
    moreTr.appendChild(td);
    table.appendChild(tr);
    table.appendChild(moreTr);
    box.appendChild(table);
    parent.insertBefore(box,sibling);
}
function addNewMoreBtn(e,j)
{
    var target= e.target;
    var top=target.parentElement.parentElement;
    var parent=top.parentElement;
    var previousElem=top.previousElementSibling;
    var prevMin=previousElem.children[0].children[0].value;
    var prevMax=previousElem.children[1].children[0].value;
    if(prevMin>=prevMax)
    {
        alert("max must greater than min");
    }
    else
    {
    var tr=document.createElement("tr");
        var td=document.createElement("td");
        var tdInput=document.createElement("input");
        tdInput.setAttribute("type","number");
        tdInput.setAttribute("min",0);
        tdInput.setAttribute("value",Number(prevMax)+1);
        tdInput.setAttribute("id","min-Amount"+j);
        td.appendChild(tdInput);
        tr.appendChild(td);
        var td=document.createElement("td");
        var tdInput=document.createElement("input");
        tdInput.setAttribute("type","number");
        tdInput.setAttribute("min",0);
        tdInput.setAttribute("id","max-Amount"+j);
        td.appendChild(tdInput);
        tr.appendChild(td);
        parent.insertBefore(tr,top);
    }
}
function removeMinMax(e)
{
    var top= e.target.parentElement;
    var parent=top.parentElement.parentElement;
    var nextSibling=top.parentElement.nextElementSibling;
    if(nextSibling.getAttribute("data-in")=="age-group")
    {
        parent.removeChild(nextSibling);
    }
}
function zipAddOption(tag)
{
    var div=document.getElementById("pinCode");
    var val=document.getElementById("pinCode").value;
    tag.addEventListener("click",function(e)
    {
            AddpinCode(e);
    },false);
}
function AddpinCode(e)
{
    var pinDiv=document.getElementById("pin").children[0].children[0];
    var elem= e.target.previousElementSibling.children[0].value;
    if(elem!="") {
        var div = document.createElement("div");
        div.setAttribute("class", "kode-alert alert1");
        var a = document.createElement("a");
        a.addEventListener("click", function (e) {
            closingTab(e);
        });
        a.setAttribute("class", "closed sag");
        a.innerHTML = "x";
        div.appendChild(a);
        var txt = document.createTextNode(elem);
        div.appendChild(txt);
        pinDiv.appendChild(div);
        document.getElementById("pinCode").value="";
    }
}
function closingTab(e)
{
    var target= e.target.parentElement;
    var parent=target.parentElement;
    parent.removeChild(target);
}
function generateCoupon(btn)
{
    var last=btn.lastElementChild;
    last.addEventListener("click",function(e)
    {
        e.preventDefault();
        if(storage.length==0 && Number(localStorage.coupon_code_exist)!=1 && Number(localStorage.coupon_exist)!=1)
        {
            getValues(e);
        }
        else
        {
            alert("Error");
        }
    });
}
function getValues(e)
{
    var top=document.getElementsByClassName("form-horizontal")[0];
    var form='';
    var minMax='';
    var zipCode='';
    var formData=new FormData();
    var name=top.children[0].children[1].children[0].value;
    formData.append("name",name);
    var discount=top.children[1].children[1].children[1].children[1];
    var discountType=discount.getAttribute("data-type");
    formData.append("discountType",discountType);
    var discountValue= Number(discount.value);
    formData.append("discountValue",discountValue);
    var cashBack=top.children[2].children[1].children[1].children[1];
    var cashBackType=cashBack.getAttribute("data-type");
    formData.append("cashBackType",cashBackType);
    var cashBackValue= Number(cashBack.value);
    formData.append("cashBackAmount",cashBackValue);
    var shipping=top.children[3].children[1].children[1].children[1];
    var shippngType=shipping.getAttribute("data-type");
    formData.append("shippingType",shippngType);
    var shippingValue=shipping.value;
    formData.append("shippingValue",shippingValue);
    var Convinence=top.children[4].children[1].children[1].children[1];
    var ConvinenceType=Convinence.getAttribute("data-type");
    formData.append("convinenceType",ConvinenceType);
    var convinenceValue=Convinence.value;
    formData.append("convinenceValue",convinenceValue);
    var radio=top.children[5].children[1];
    for(var i=0;i<radio.children.length;i++) {
        if (radio.children[i].children[0].checked) {
            formData.append("selection",radio.children[i].children[0].value);
            if(radio.children[i].children[0].value=="multiple")
            {
                var bar=top.children[5].children[2].children[0].children[0].value;
                formData.append("times",bar);
            }
            if(radio.children[i].children[0].value==1)
            {
                formData.append("times",1);
            }
        }
    }
    var couponCode=document.getElementById("couponCode");
    var cuponCodeValue=couponCode.value;
    formData.append("couponCode",cuponCodeValue);
    var restaurantOpt=top.children[7].children[1].children[0];
    if(restaurantOpt.value=="one")
    {
        formData.append("restOpt",restaurantOpt.value);
        var rstr=top.children[8];
        if(rstr.getAttribute("data-in")=="create")
        {
            var selectBox=top.children[8].children[1].children[0];
            for(var i=0;i<selectBox.options.length;i++)
            {
                if(selectBox.options[i].selected)
                {
                    form +=selectBox.options[i].getAttribute("data-id")+'||';

                }
            }
            var res=form.substr(0,(form.length)-2);
            formData.append("restaurant",res);
        }
    }
    if(restaurantOpt.value=="all")
    {
        formData.append("restOpt",restaurantOpt.value);
        formData.append("restaurant","all");
    }
    var date=document.getElementById("date-picker");
    var validity=date.parentElement.parentElement.parentElement.parentElement.nextElementSibling.children[0];
    if(validity.checked)
    {
        formData.append('validity',validity.value);
    }
    else
    {
        formData.append('validity',date.value);
    }
    var ageGroupOpt=document.getElementById("single");
    if(ageGroupOpt.value=="one")
    {
        if(document.getElementById("age-section")) {
            var ageSection = document.getElementById("age-section");
            var tables = ageSection.children[0];
            for (var i = 1; i < tables.children.length - 1; i++) {
                var min = tables.children[i].children[0].children[0].value;
                var max = tables.children[i].children[1].children[0].value;
                minMax +=  min + '||' + max + '&';
            }
            formData.append("minMax", minMax.substring(0,minMax.length-1));
        }
    }
    else
    {
        formData.append("minMax",'all');
    }
    var status=document.getElementById("Mstatus");
    for(var i=0;i<status.options.length;i++)
    {
        if(status.options[i].selected)
        {
            formData.append("status",status.options[i].value);
        }
    }
    var pinCode=document.getElementById("pin").children[0].children[0];
    if(pinCode.children.length==0)
    {
        formData.append("pincode","all");
    }
    else
    {
        for(var i=0;i<pinCode.children.length;i++)
        {
            var zip=Number(pinCode.children[i].childNodes[1].nodeValue);
            zipCode +=zip+'&';
        }
        formData.append("pincode",zipCode.substring(0,zipCode.length-1));
    }
    formData.append("request1","cuopon-Create");
    var req=createXhr();
    var url="controller/alchol.php";
    req.open("POST",url,true);
    req.send(formData);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
        var data=JSON.parse(req.responseText);
            if(data.status==1)
            {
            alert("Coupon created Sucessfully");
                top.reset();
            }
            else
            {
                alert("Coupon cannot be Created");
                top.reset();
            }
        }
    }
}
function ValidPattern(pattern,e,data)
{
    if(!(pattern.test(data)))
    {
        var top=e.target.parentElement.parentElement;
        top.setAttribute("class","form-group has-warning");
        storage.push(e.target.getAttribute("id"));
    }
}
function validEntry(e)
{
    var couponName = e.target.value;
    var userId= e.target.parentElement.setAttribute("id","CouponName");
    if(couponName!="") {
        var url = "controller/alchol.php";
        var req = create_request(url, 'couponNameCheck', couponName);
        req.onreadystatechange = function () {
            req.onload = function () {
                var data = JSON.parse(req.responseText);
                if (data.status == 0) {
                    CouponMark('CouponName', 'notification_error.png');
                    window.localStorage.coupon_exist=1;
                }
                else {
                    CouponMark('CouponName', 'notification_done.png');
                    window.localStorage.coupon_exist=0;
                }
            }
        }
    }
}
function CouponMark(div,src)
{
    var email_id=document.getElementById(div);
    var image=document.createElement("img");
    image.style.marginTop=-3.5+'%';
    image.style.float="right";
    image.setAttribute("class","end-image");
    image.setAttribute("src","img/"+src);
    email_id.appendChild(image);
}
function removeCouponImage(e)
{
    var parent=e.target.parentElement;
    if(parent.lastElementChild.nodeName=="IMG")
    {
        parent.removeChild(parent.lastElementChild);
    }
}
function validNumber(pattern,e,data)
{
    if(!(pattern.test(data)))
    {
        e.target.style.border="1px solid red";
        storage.push(e.target.getAttribute("id"));
    }
}
function validCode(e)
{
    var couponCode= e.target.value;
    var userId= e.target.parentElement.setAttribute("id","codeCoupon");
    if(couponCode!="") {
        var url = "controller/alchol.php";
        var req = create_request(url, 'couponCode', couponCode);
        req.onreadystatechange = function () {
            req.onload = function () {
                var data = JSON.parse(req.responseText);
                if (data.status == 0) {
                    Mark('codeCoupon', 'notification_error.png');
                    window.localStorage.coupon_code_exist = 1;
                }
                else {
                    Mark('codeCoupon', 'notification_done.png');
                    window.localStorage.coupon_code_exist = 0;
                }
            }
        }
    }
}
function Mark(div,src)
{
    var email_id=document.getElementById(div).parentElement;
    var neighbour=document.getElementById(div);
    var image=document.createElement("img");
    image.style.marginTop=0.5+'%';
    image.style.float="right";
    image.setAttribute("class","end-image");
    image.setAttribute("src","img/"+src);
    email_id.insertBefore(image,neighbour);
}
function removeCodeImage(e)
{
    var parent= e.target.parentElement.parentElement;
    if(parent.children[1].nodeName=="IMG")
    {
        parent.removeChild(parent.children[1]);
    }
}
function removeDeals()
{
    var table=document.getElementsByClassName("table table-striped")[0];
    var tBody=table.children[1];
    for(var i=0;i<tBody.children.length;i++)
    {
        var td=tBody.children[i].firstElementChild;
        td.addEventListener("click",function(e) {
            var dealId= e.target.getAttribute("id");
            location.assign("aboutDeals.php?id=" + dealId);
        });
    }
}
function DealUpdate()
{
    var locationDiv=document.getElementById("modification");
    var lat=locationDiv.getAttribute("data-lat");
    var lng=locationDiv.getAttribute("data-lng");
    sendData(lat,lng);
    var parent=locationDiv.parentElement;
    var button_submit=document.createElement("button");
    button_submit.setAttribute("id","btn-update");
    button_submit.addEventListener("click",function(e)
    {
    locationUpdate(e);
    });
    button_submit.setAttribute("type","button");
    button_submit.setAttribute("class","btn btn-default");
    button_submit.style.float="right";
    button_submit.style.marginBottom="2%";
    button_submit.innerHTML="send Location";
    parent.appendChild(button_submit);
    var btn=document.getElementById("edit-transform");
    btn.setAttribute("data-update","off");
    btn.addEventListener("click", function (e) {
        if(e.target==btn || e.target==btn.children[0]) {
            if(btn.getAttribute("data-update")=="off") {
                btn.setAttribute("data-update", "on");
                updateDetails(e);
            }
            else if(btn.getAttribute("data-update")=="on")
            {
                btn.setAttribute("data-update","off");
                sendSectionData();
            }
        }
    },true);
    priceUpdate();
}
function locationUpdate(e)
{
    var lat=arr2;
    var lan=arr3;
    var url="controller/alchol.php";
    var req=create_request(url,'DealLocationUpdate',lat,lan,loc);
    req.onreadystatechange=function()
    {
        req.onload=function()
        {
        alert("location updated");
        }
    };
}
function updateDetails(e)
{
    var table=document.getElementById("elements-node");
    for(var i=0;i<table.children.length;i++)
    {
        var ref=table.children[i].children[1];
        var value=ref.childNodes[0].nodeValue;
        var input=document.createElement("input");
        input.setAttribute("type","text");
        input.value=value;
        ref.innerHTML="";
        ref.appendChild(input);
    }
}
function sendSectionData()
{
    var table=document.getElementById("elements-node");
    var reqData='request'+1+'=updateDeals&request'+0+'='+loc+'&';
    var url="controller/alchol.php";
    for(var i=0;i<table.children.length;i++)
    {
        var ref=table.children[i].children[1];
        var value=ref.children[0].value;
        reqData +='request'+(i+2)+'='+value+'&'
    }
    var req=createXhr();
    req.open("POST",url,true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(reqData.substr(0,reqData.length-1));
    req.onreadystatechange = function()
    {
        req.onload = function()
        {
            var table=document.getElementById("elements-node");
            for(var i=0;i<table.children.length;i++)
            {
                var ref=table.children[i].children[1];
                var value=ref.children[0].value;
                ref.removeChild(ref.children[0]);
                ref.innerHTML=value;
            }
        }
    }
}
function priceUpdate()
{
    var table=document.getElementById("adding-more-table").children[0];
    for(var i=0;i<table.children.length;i++)
    {
    if(table.children[i].getAttribute("class")=="rows-cum")
    {
        var btn=table.children[i].lastElementChild;
        btn.addEventListener("click",function(e)
        {
            sendPrice(e);
        });
    }
    }
}
function sendPrice(e)
{
    var ref_id=e.target.parentElement.getAttribute("data-id");
    var min_people= e.target.parentElement.parentElement.children[0].children[0].value;
    var max_person= e.target.parentElement.parentElement.children[1].children[0].value;
    var price= e.target.parentElement.parentElement.children[2].children[0].value;
    var url="controller/alchol.php";
    var req=create_request(url,'updateDealDynamicPrice',min_people,max_person,price,ref_id);
    req.onreadystatechange = function()
    {
        req.onload = function()
        {
            var data=JSON.parse(req.responseText);
            if(data.status==1)
            {
                alert("updated sucessfully");
            }
        }
    }
}
function EventPage()
{
    var table=document.getElementsByClassName("table table-striped")[0];
    var tBody=table.children[1];
    for(var i=0;i<tBody.children.length;i++)
    {
        var td=tBody.children[i].firstElementChild;
        td.addEventListener("click",function(e) {
            var eventId= e.target.getAttribute("id");
            location.assign("aboutEvents.php?id=" + eventId);
        });
    }
}
function EventUpdate()
{
    var locationDiv=document.getElementById("modification");
    var lat=locationDiv.getAttribute("data-lat");
    var lng=locationDiv.getAttribute("data-lng");
    sendData(lat,lng);
    var parent=locationDiv.parentElement;
    var button_submit=document.createElement("button");
    button_submit.setAttribute("id","btn-update");
    button_submit.addEventListener("click",function(e)
    {
        locationUpdate(e);
    });
    button_submit.setAttribute("type","button");
    button_submit.setAttribute("class","btn btn-default");
    button_submit.style.float="right";
    button_submit.style.marginBottom="2%";
    button_submit.innerHTML="send Location";
    parent.appendChild(button_submit);
    var btn=document.getElementById("edit-transform");
    btn.setAttribute("data-update","off");
    btn.addEventListener("click", function (e) {
        if(e.target==btn || e.target==btn.children[0]) {
            if(btn.getAttribute("data-update")=="off") {
                btn.setAttribute("data-update", "on");
                updateDetails(e);
            }
            else if(btn.getAttribute("data-update")=="on")
            {
                btn.setAttribute("data-update","off");
                updateData();
            }
        }
    },true);
}
function updateData()
{
    var table=document.getElementById("elements-node");
    var reqData='request'+1+'=updateEvent&request'+0+'='+loc+'&';
    var url="controller/alchol.php";
    for(var i=0;i<table.children.length;i++)
    {
        var ref=table.children[i].children[1];
        var value=ref.children[0].value;
        reqData +='request'+(i+2)+'='+value+'&'
    }
    var req=createXhr();
    req.open("POST",url,true);
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    req.send(reqData.substr(0,reqData.length-1));
    req.onreadystatechange = function()
    {
        req.onload = function()
        {
            var table=document.getElementById("elements-node");
            for(var i=0;i<table.children.length;i++)
            {
                var ref=table.children[i].children[1];
                var value=ref.children[0].value;
                ref.removeChild(ref.children[0]);
                ref.innerHTML=value;
            }
            alert("updated sucessfully");
        }
    }
}
var Admin= {
    CheckOptions: function()
    {
        var tabs= document.getElementById("tabs");
        for(var i=0;i<tabs.children.length;i++)
        {
            var tr = tabs.children[i];
            var td = tr.children[2];
            var a = td.children[0];
            a.addEventListener("click", function (e) {
                e.preventDefault();
                Admin.background(e);
            });
        }
    },
    background : function(e)
    {
    var body = document.getElementsByTagName("body")[0];
        var firstChild = body.firstElementChild;
        body.insertBefore(this.backSlide(e),firstChild);
    },
    lightBox : function(ef)
    {
        var divDialog = document.createElement("div");
        divDialog.setAttribute("class","xDialog");
        divDialog.style.left=380+"px";
        divDialog.style.top=50+"px";
        var DiallogCon= document.createElement("div");
        DiallogCon.setAttribute("class","DialogCon");
        var divDialogTil = document.createElement("div");
        divDialogTil.setAttribute("class","DialogTit");
        var modalTitle = document.createTextNode("Modal Title");
        var a= document.createElement("a");
        a.style.cursor="pointer";
        a.setAttribute("class","DialogClose");
        a.addEventListener("click",function(e)
        {
        Admin.close(e);
        });
        a.innerHTML="X";
        divDialogTil.appendChild(modalTitle);
        divDialogTil.appendChild(a);
        var dialogArea = document.createElement("div");
        dialogArea.setAttribute("class","DialogArea");
        dialogArea.style.width=450+"px";
        dialogArea.style.height=320+"px";
        var row = this.row();
        var col = this.col();
        var ul = this.ul();
        ul.setAttribute("data-in",ef.target.getAttribute("href"));
        col.appendChild(ul);
        row.appendChild(col);
        dialogArea.appendChild(row);
        DiallogCon.appendChild(divDialogTil);
        DiallogCon.appendChild(dialogArea);
        divDialog.appendChild(DiallogCon);
        return divDialog;
    },
    backSlide : function(e)
    {
    var background=document.createElement("div");
        background.setAttribute("class","dialog-screen");
        background.appendChild(this.lightBox(e));
        return background;
    },
    close : function(e)
    {
        var parent = document.getElementsByClassName("dialog-screen")[0];
        if(parent.getAttribute("class")=="dialog-screen")
        {
            var body=document.getElementsByTagName("body")[0];
            body.removeChild(parent);
        }
    },
    row : function()
    {
       var row = document.createElement("div");
        row.setAttribute("class","row");
        return row;
    },
    col : function()
    {
        var col=document.createElement("div");
        col.setAttribute("class","col-xs-12");
        return col;
    },
    ul : function()
    {
        var ul=document.createElement("ul");
        ul.setAttribute("class","optionBox");
        ul.appendChild(this.li("user.png","ViewProfile"));
        ul.appendChild(this.li("chess.jpg","View Docs"));
        return ul;
    },
    li : function(arg,detail)
    {
        if(detail=="ViewProfile") {
            var li = document.createElement("li");
            var imag = document.createElement("img");
            imag.setAttribute("src", "img/" + arg);
            li.appendChild(imag);
            var tag = document.createElement("p");
            tag.style.cursor="pointer";
            tag.addEventListener("click",function(e)
            {
                Admin.request(e);
            });
            tag.innerHTML = detail;
            li.appendChild(tag);
            return li;
        }
        else {
            var li = document.createElement("li");
            var imag = document.createElement("img");
            imag.setAttribute("src", "img/" + arg);
            li.appendChild(imag);
            var tag = document.createElement("p");
            tag.style.cursor="pointer";
            tag.addEventListener("click",function(e)
            {
                Admin.openDocument(e);
            });
            tag.innerHTML = detail;
            li.appendChild(tag);
            return li;
        }
    },
    request : function(e)
    {
    var url=e.target.parentElement.parentElement.getAttribute("data-in");
        var win = window.open(url,"_blank");
        this.close(e);
    },
    openDocument : function(e)
    {
    var url=e.target.parentElement.parentElement.getAttribute("data-in");
        var seprator = url.split("?");
        var query=seprator[1].substr(3);
        var newUrl = "documentList.php?id="+query;
        var win = window.open(newUrl,"_blank");
        this.close(e);
    }
};
var documentList={
    lightBox : function()
    {
        var selector = document.getElementById("document-table");
        for(var i=0;i<selector.children.length;i++)
        {
            var element=selector.children[i].children[1].children[0];
            element.addEventListener("click",function(e)
            {
                e.preventDefault();
                documentList.attach(e.target.getAttribute("href"));
            });
        }
    },
    attach : function(href)
    {
        var base=document.getElementsByTagName("body")[0];
        var neighbour = base.firstElementChild;
       base.insertBefore(this.backSlide(href),neighbour);
    },
    backSlide : function(e)
    {
        var background=document.createElement("div");
        background.setAttribute("class","dialog-screen");
        background.appendChild(this.lightBoxDiv(e));
        return background;
    },
    lightBoxDiv : function(ef)
    {
        var divDialog = document.createElement("div");
        divDialog.setAttribute("class","xDialog");
        divDialog.style.left=380+"px";
        divDialog.style.top=50+"px";
        var DiallogCon= document.createElement("div");
        DiallogCon.setAttribute("class","DialogCon");
        var divDialogTil = document.createElement("div");
        divDialogTil.setAttribute("class","DialogTit");
        var modalTitle = document.createTextNode("Modal Title");
        var a= document.createElement("a");
        a.style.cursor="pointer";
        a.setAttribute("class","DialogClose");
        a.addEventListener("click",function(e)
        {
            Admin.close(e);
        });
        a.innerHTML="X";
        divDialogTil.appendChild(modalTitle);
        divDialogTil.appendChild(a);
        var dialogArea = document.createElement("div");
        dialogArea.setAttribute("class","DialogArea");
        dialogArea.style.width=450+"px";
        dialogArea.style.height=320+"px";
        var iframe = new PdfJs(450,320,ef);
        dialogArea.appendChild(iframe.iframe());
        DiallogCon.appendChild(divDialogTil);
        DiallogCon.appendChild(dialogArea);
        divDialog.appendChild(DiallogCon);
        return divDialog;
    }
};
var DateSelector={
    count:0,
    selectDate :function() {
        $( "#Start-date" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
    },
    selectEndDate :function() {
        $( "#END-DATE" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
    },
    Expiry : function()
    {
        $( "#expired" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
    },
    startTime : function(id)
    {
        $('.clockpicker').clockpicker();
    },
    EndTime : function()
    {
        $('.clockpicker').clockpicker();
    },
    create : function()
    {
        document.getElementById("create-event").addEventListener("click",function(e)
        {
            DateSelector.createDeals();
        });
    },
    createDeals : function()
    {
    var base = document.getElementById("details");
        base.innerHTML="";
        var outerArea = document.createElement("div");
        outerArea.setAttribute("id","outer_area");
        outerArea.setAttribute("class","col-md-6 modify");
        var modification = document.createElement("div");
        modification.setAttribute("id","modification");
        modification.setAttribute("class","panel panel-default");
        var PanelTitle = document.createElement("div");
        PanelTitle.setAttribute("class","panel-title");
        PanelTitle.innerHTML="Fieldset";
        var panelBody = document.createElement("div");
        panelBody.setAttribute("class","panel-body");
        PanelTitle.appendChild(panelBody);
        modification.appendChild(PanelTitle);
        outerArea.appendChild(modification);
        var fieldset = document.createElement("fieldset");
        panelBody.appendChild(fieldset);
        var legend = document.createElement("legend");
        legend.innerHTML="Create Your Deal";
        fieldset.appendChild(legend);
        var form =document.createElement("form");
        form.setAttribute("id","outer_area");
        form.setAttribute("class","fieldset-form");
        form.setAttribute("enctype","multipart/form-data");
        form.appendChild(this.CreateFormGroup("Deal-Name","input","Deal-Name","deal","text"));
        form.appendChild(this.CreateFormGroup("Deal-Description","textarea","dealDescription","Description","text"));
        form.appendChild(this.CreateFormGroup("Start-date","input","YYYY-MM-DD","Start-date","date"));
        form.appendChild(this.CreateFormGroup("End-date","input","YYYY-MM-DD","END-DATE","EndDate"));
        form.appendChild(this.CreateFormGroup("start-Time","input","HH-MM","START-TIME","time"));
        form.appendChild(this.CreateFormGroup("End-Time","input","HH-MM","END-TIME","time"));
        form.appendChild(this.CreateSelectBox("Deal-type","---------SELECT-TYPE----------------","Alcoholic","Non-Alcoholic"));
        form.appendChild(this.CreateFormGroup("Repeat-Duration","input","i.e 1hrs","repeat","text"));
        form.appendChild(this.CreateFormGroup("Deal-Capacity:","input","Capacity","capacity","number"));
        form.appendChild(this.CreateFormGroup("Deal-Expired","input","YYYY-MM-DD","expired","date"));
        form.appendChild(this.CreateFormGroup("Deal-Image","input","Image","deal-image","file"));
        form.appendChild(this.CreateFormGroupWidBtn("adding-tabs","Fee-Individual:","input","INDIVIDUAL-FEE","FEE","text"));
        form.appendChild(this.createSubmitButton("submit","btn btn-default","submit","submit"));
        fieldset.appendChild(form);
        base.appendChild(outerArea);
        $( "#Start-date" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
        $( "#END-DATE" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
        $( "#expired" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
    },
    send: function()
    {
        var deal_name=document.getElementById("deal").value;
        var description=document.getElementById("Description").value;
        var startDate=document.getElementById("Start-date").value;
        var endDate=document.getElementById("END-DATE").value;
        var startTime=document.getElementById("START-TIME").value;
        var endTime=document.getElementById("END-TIME").value;
        var type=document.getElementById("Type").value;
        var sel=document.getElementById("Type");
        var x=sel.selectedIndex;
        var repeat=document.getElementById("repeat").value;
        var capacity=document.getElementById("capacity").value;
        var expired=document.getElementById("expired").value;
        var fee=document.getElementById("FEE").value;
        var file=document.getElementById("deal-image");
        var str = [];
        try
        {
            this.validator(deal_name,"deal",/^[a-zA-Z0-9\s\-]+$/,"ONLY LETTERS ALLOWED FOLLOWED BY NUMBER");
            this.validator(description,"Description",/^[a-zA-Z]+/,"Can Be Any Words");
            this.dateValidator(startDate,endDate,"StartDate Must be smallar than EndDate","END-DATE");
            this.timeFormat(startTime,"START-TIME");
            this.timeFormat(endTime,"END-TIME");
            this.selectorFormat(type,"Type");
            this.validator(repeat,"repeat",/^[0-9]+hrs|mins/,"i.e 1 hrs or 30mins");
            this.validator(capacity,"capacity",/^[0-9]+$/,"Only Numbers Are Allowed");
            this.dateValidator(endDate,expired,"Expire Date Must be greater than EndDate","expired");
            this.FileValidator(file,"Kindly Upload Image","deal-image");
            this.validator(fee,"deal-image",/^[0-9]+(\.[0-9]){0,}/,"Only Number Allowed");
            this.priceValidator();
            var form = new FormData();
            form.append("event_name", deal_name);
            form.append("description", description);
            form.append("startDate", startDate);
            form.append("endDate", endDate);
            form.append("startTime", startTime);
            form.append("endTime", endTime);
            form.append("type", sel[x].innerHTML);
            form.append("repeat", repeat);
            form.append("capacity", capacity);
            form.append("expiry", expired);
            form.append("IndFee", fee);
            form.append("image", file.files[0]);
            form.append("cid", loc);
            form.append("request1", "deal");
            var pricing=document.querySelectorAll("#adding-tabs #adding-more-table tr.out");
            var total=pricing.length;
            if(total > 0)
            {
                for(var i=0;i<total;i++)
                {
                    var min=Number(pricing[i].children[0].children[0].value);
                    var max=Number(pricing[i].children[1].children[0].value);
                    var price=Number(pricing[i].children[2].children[0].value);
                    str.push(min+'||'+max+'||'+price);
                }
            }
            form.append("price",str.join('&'));
            var req = createXhr();
            var url = "controller/alchol.php";
            req.open('POST', url, true);
            req.send(form);
            req.onreadystatechange = function () {
                if (req.status == 200 && req.readyState == 4) {
                        var data = JSON.parse(req.responseText);
                        if (data.status == 1) {
                            alert("Deal registered Successfully");
                            document.getElementById("details").innerHTML="";
                        }
                }
            };

        }
        catch(E)
        {
            var split=E.split(":");
            if(split[1]!="START-TIME" || split[1]!="END-TIME") {
                this.showMessage(split[0], split[1]);
            }
        }
    },
    validator : function(data,id,pattern,message)
    {
        if(!pattern.test(data))
        {
            throw message+":"+id;
        }
    },
    CreateFormGroup : function(name,Box,placeholder,id,type)
    {
        var form = document.createElement("div");
        form.setAttribute("class","form-group");
        var label = document.createElement("label");
        label.setAttribute("for",name);
        label.setAttribute("class","form-label");
        label.innerHTML=name;
        form.appendChild(label);
            var input = document.createElement(Box);
            if (Box == "input") {
                input.setAttribute("type", type);
            }
            input.setAttribute("class", "form-control");
            input.setAttribute("id", id);
            input.setAttribute("placeholder", placeholder.toUpperCase());
            if(type=="file")
            {
                input.setAttribute("accept","image/*");
                input.setAttribute("required","required");
            }
            if(type=="number")
            {
            input.setAttribute("min",0);
            }
            if(name=="Start-date")
            {
                input.addEventListener("focus",function(e)
                {
                DateSelector.selectDate();
                });
            }
            if(name=="End-date")
            {
                input.addEventListener("focus",function(e)
                {
                    DateSelector.selectEndDate();
                });
            }
            if(name=="Deal-Expired")
            {
                input.addEventListener("focus",function(e)
                {
                    DateSelector.Expiry();
                });
            }
            if(name=="start-Time")
            {
                form.setAttribute("class","form-group clockpicker");
                input.addEventListener("focus",function(e){
                    DateSelector.startTime(id);
                });
            }
            if(name=="End-Time")
            {
                form.setAttribute("class","form-group clockpicker");
                input.addEventListener("focus",function(e){
                    DateSelector.EndTime(id);
                });
            }
            form.appendChild(input);
            return form;
    },
    CreateSelectBox : function(name)
    {
        var form = document.createElement("div");
        form.setAttribute("class","form-group");
        var label = document.createElement("label");
        label.setAttribute("for",name);
        label.setAttribute("class","form-label");
        label.innerHTML=name;
        form.appendChild(label);
        var select =document.createElement("select");
        select.setAttribute("id","Type");
        for(var i=0;i<3;i++)
        {
            var option=document.createElement("option");
            option.value=i;
            option.innerHTML=arguments[i+1];
            select.appendChild(option);
        }
        form.appendChild(select);
        return form;
    },
    CreateFormGroupWidBtn : function(divId,name,Box,placeholder,id,type)
    {
        var form = document.createElement("div");
        form.setAttribute("id",divId);
        form.setAttribute("class","form-group");
        var label = document.createElement("label");
        label.setAttribute("for",name);
        label.setAttribute("class","form-label");
        label.innerHTML=name;
        form.appendChild(label);
        var input = document.createElement(Box);
        if (Box == "input") {
            input.setAttribute("type", type);
        }
        input.setAttribute("class", "form-control");
        input.setAttribute("id", id);
        input.setAttribute("placeholder", placeholder.toUpperCase());
        if(type=="file")
        {
            input.setAttribute("accept","image/*");
        }

        form.appendChild(input);
        form.appendChild(document.createElement("br"));
        form.appendChild(this.CreateButton("add-on","btn btn-option3 btn-xs","Add-Item","checkbox","checkbox"));
        return form;
    },
    CreateButton :function(id,cl,action,type)
    {
    var formGroup=document.createElement("div");
        formGroup.setAttribute("class","form-group");
        formGroup.setAttribute("id",id);
        var p=document.createElement("p");
        p.setAttribute("class","form-label");
        p.innerHTML="Multiple-Price";
        formGroup.appendChild(p);
        var label=document.createElement("label");
        label.setAttribute("for","Amount");
        label.setAttribute("class","checkbox-inline form-label");
        var input=document.createElement("input");
        input.setAttribute("type",type);
        input.setAttribute("id","item");
        input.addEventListener("click",function(e)
        {
        if(e.target.checked==true)
        {
           this.CreateDynamicPrice();
        }
        else {
            this.removeInput()
        }
        }.bind(this));
        label.appendChild(input);
        label.appendChild(document.createTextNode("INDIVIDUAL-PRICE"));
        formGroup.appendChild(label);
        return formGroup;
    },
    createSubmitButton : function(id,cl,action,type)
    {
        var button = document.createElement("button");
        button.setAttribute("id",id);
        button.setAttribute("class",cl);
        button.setAttribute("type",type);
        button.addEventListener("click",function(e)
        {
            e.preventDefault();
            DateSelector.send();
        });
        button.innerHTML=action;
        return button;
    },
    CreateDynamicPrice : function() {
        var mainDiv=document.querySelector("#adding-tabs");
        var range = new AddButton(mainDiv,0,['min-People','max-People','Price'],false,"REMOVE");
        var table=range.createTable();
        range.AddRow();
    },
    dateValidator : function(dateA,dateB,message,div)
    {
    var start=this.dateSeperator(dateA,div);
    var startYear=start[0];
    var startMonth=start[1];
    var startDate=start[2];
    var end=this.dateSeperator(dateB,div);
    var endYear=end[0];
    var endMonth=end[1];
    var endDate=end[2];
        if(startYear > endYear)
        {
            throw message+":"+div;
        }
        if(startYear==endYear)
        {
            if(startMonth > endMonth)
            {
                throw message+":"+div;
            }
        }
        if((startYear==endYear)&&(startMonth==endMonth))
        {
            if(startDate > endDate)
            {
                throw message+":"+div;
            }
        }
    },
    timeFormat:function(date,div)
    {
        if(date=="")
        {
            throw "Cannot Be Left Blank :"+div
        }

    },
    dateSeperator : function(date,div)
    {
        if(date!="") {
            var dateFormat = new Date(date);
            return [dateFormat.getFullYear(), dateFormat.getMonth(), dateFormat.getDate()];
        }
        else
        {
            throw "Cannot Be Left Blank :"+div;
        }
    },
    selectorFormat : function(data,div)
    {
    if(data==0)
    {
        throw "Must Select The Party Type:"+div;
    }
    },
    FileValidator : function(file,message,div)
    {
    if('files' in file)
    {
        if(file.files.length==0)
        {
            throw message+":"+div;
        }
        if(file.files.size >6000000)
        {
            throw "SIZE SHOULD BE LESS THAN 6MB:"+div;
        }
    }
    },
    priceValidator : function()
    {
        if(document.getElementById("adding-more-table"))
        {
            var table=document.getElementById("adding-more-table");
            for(var i=1;i<table.children.length;i++)
            {
                var row=table.children[i];
                if(row.hasChildNodes())
                {
                    this.ValidValue(row.children[0].children[0].value,/^[0-9]+$/,"Must Be A valid Number","adding-more-table");
                    this.ValidValue(row.children[1].children[0].value,/^[0-9]+$/,"Must Be A valid Number","adding-more-table");
                    this.ValidValue(row.children[2].children[0].value,/^[0-9]+(\.[0-9]){0,}/,"Must Be A valid Number","adding-more-table");
                }
            }
        }
    },
    ValidValue : function(val,pattern,message,div)
    {
    if(!pattern.test(val))
    {
        throw message+":"+div;
    }
    },
    showMessage : function(message,div)
    {
        var parentDiv;
            var element = document.getElementById(div);
                parentDiv = element.parentElement;
            this.messageDispalay(parentDiv,message);

    },
    messageDispalay : function(parent,message)
    {
        var p = document.createElement("p");
        p.style.color="red";
        var text=document.createTextNode(message);
        p.appendChild(text);
        parent.appendChild(p);
        window.setTimeout(function(){
            parent.removeChild(p);
        },3000);

    },
    removeInput : function()
    {
        var element=document.querySelectorAll("#adding-tabs #adding-more-table");
        var count=element.length;
        if(count!=0)
        {
            var parent=document.querySelector("#adding-tabs");
            var child=document.querySelector("#adding-tabs #adding-more-table");
            parent.removeChild(child);
            var button=document.querySelector("#adding-tabs button");
            parent.removeChild(button);
        }
    }
};
var restaurant={
    support : function()
    {
    var div=document.getElementById("featured-req");
    div.addEventListener("click",function(e)
    {
    restaurant.create();
    });
    var Element=document.querySelector("#viewDeals");
    Element.addEventListener("click",function(e)
    {
     this.viewDeals();
    }.bind(this));
    var element=document.querySelectorAll("ul.quick-menu li.col-sm-2");
    element[2].addEventListener("click", function () {
    this.ticket();
    }.bind(this));
    },
    create : function()
    {
        var base = document.getElementById("details");
        base.innerHTML="";
        var events = new EventsDeals("Support","base");
        var header= events.createHeader();
        var Form= events.createForm();
        var select=events.SelectDropDown("SUPPORT","form-group","Option");
        var option=events.createOption(select[1],"Tech-Support","Generate-Ticket");
        Form.appendChild(select[0]);
        var subject=events.createFormGroup("Subject","input","subject","subject","text","form-group");
        Form.appendChild(subject[0]);
        var editor=events.createTextEditor("editor","message");
        Form.appendChild(editor);
        var submit=events.createSubmit("submit","submit","btn btn-default","submit");
        submit.addEventListener("click",function(e)
        {
        e.preventDefault();
        restaurant.createSupport();
        });
        Form.appendChild(submit);
        header[0].appendChild(Form);
        base.appendChild(header[1]);
        $('#editor').summernote();
    },
    createSupport : function(e)
    {
        var support=document.getElementById("SUPPORT");
        var supportIndex=support.value;
        var supportVal=support[supportIndex].innerHTML;
        var subject=document.getElementById("subject").value;
        var edit=$('#editor').code();
        try {
        this.selectorFormat(supportIndex,"SUPPORT","Select A Value");
         DateSelector.validator(subject,"subject",/^[a-zA-Z]+[a-zA-Z0-9]+$/,"can be alphanumeric");
        this.checkForEmpty(edit,"editor","Cannot be left blank");
            var formdata = new FormData();
            formdata.append("supportType",supportVal);
            formdata.append("subject",subject);
            formdata.append("message",edit);
            formdata.append("ref_id",loc);
            formdata.append("request1","CreateSupport");
            Ajax.url="controller/alchol.php";
            Ajax.loadFormData(formdata,function(xhr)
            {
            if(xhr.readyState<4)
            {
                Ajax.createFrame();
            }
            else
            {
                var data=JSON.parse(xhr.responseText);
                if(data.state==1)
                {
                   if(document.getElementById("progress"))
                   {
                       var body=document.getElementsByTagName("body")[0];
                       body.removeChild(body.children[0]);
                       alert("Query Generated");
                       var base = document.getElementById("details");
                       base.innerHTML="";
                   }
                }

            }
            });
        }
        catch(E)
        {
            var split=E.split(":");
            DateSelector.showMessage(split[0],split[1]);
        }
    },
    selectorFormat : function(data,div,message)
    {
        if(data==0)
        {
            throw message+":"+div;
        }
    },
    checkForEmpty :function(data,div,message)
    {
    if(data=="")
    {
        throw message+":"+div;
    }
    },
    viewDeals : function()
    {
        Ajax.url="controller/alchol.php";
        Ajax.setRequest("checkDeals",loc);
        Ajax.loadEncodedReq(function(xhr)
        {
            if(xhr.readyState<4)
            {
                Ajax.createFrame();
            }
            else {
                var result=JSON.parse(xhr.responseText);
                var event =new EventDealsView("View Deals");
                event.createTable("event-list",function(table)
                {
                    var base=document.getElementById("details");
                    base.innerHTML="";
                    table.appendChild(event.createHead("Event-Name","TYPE","Event-Expires","Capacity","Events-Sold"));
                    for(var i=0;i<result.length;i++) {
                        if (result[i].id!==0) {
                                table.appendChild(event.createBody(result[i].name, result[i].type, result[i].Expires, result[i].capacity, result[i].count, result[i].id, function (a) {
                                    a.addEventListener("click", function (e) {
                                        e.preventDefault();
                                    });
                                }));
                        }
                    }
                    base.appendChild(table);
                });
                if(document.getElementById("progress")) {
                    var body = document.getElementsByTagName("body")[0];
                    body.removeChild(body.children[0]);
                }
            }
        });
    },
    ticket : function()
    {
        var parent=document.querySelector("#details");
        parent.innerHTML="";
        var ticket=new CreateTicket(parent,"ENTER USER TICKET REFERENCE ID");
        ticket.createPanel(function(label,input){
            label.setAttribute("for","Ticket");
            label.innerHTML="ENTER TICKET:";
            input.setAttribute("placeholder","ENTER TICKET REFERENCE");
        });
    }
};
var Ajax={
    url : '',
    req : '',
    loadEncodedReq :function(callback) {
        var xhr;
        try {
            xhr=new XMLHttpRequest();
        } catch (e) {
            alert("unable to connect");
        }
    xhr.onreadystatechange = dataLoader;
        function dataLoader()
        {
            if(xhr.readyState < 4)
            {
                callback(xhr);
            }
            if(xhr.status!=200)
            {
                callback(-1);
            }
            if(xhr.readyState==4)
            {
                callback(xhr);
            }
        }
        xhr.open("POST",this.url,true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(this.req);
    },
    setRequest : function()
    {
        var string='';
        for(var i=1;i<=arguments.length;i++)
        {
                string +='request'+i+'='+arguments[i-1]+'&'
        }
        this.req=string.substr(0,string.length-1);
    },
    loadFormData :function(form,callback) {
        var xhr;
        try {
            xhr=new XMLHttpRequest();
        } catch (e) {
            alert("unable to coneect");
        }
        xhr.onreadystatechange = dataLoader;
        function dataLoader(e)
        {
            if(xhr.readyState < 4)
            {
                callback(xhr);
            }
            if(xhr.status!=200)
            {
                callback(-1);
            }
            if(xhr.readyState==4)
            {
                callback(xhr);
            }
        }
        xhr.open("POST",this.url,true);
        xhr.send(form);
    },
    createFrame : function()
    {
        if(!document.getElementById("progress")) {
            var body = document.getElementsByTagName("body")[0];
            var neighbour = body.firstElementChild;
            body.insertBefore(this.createBlack(), neighbour);
        }
    },
    createBlack :function()
    {
        var layer=document.createElement("div");
        layer.setAttribute("class","loading");
        layer.style.display="block";
        layer.style.opacity=0.7;
        layer.setAttribute("id","progress");
        var image=document.createElement("img");
        image.setAttribute("src","img/ajax-loader.gif");
        layer.appendChild(image);
        return layer;
    }
};
var EventManager=
{
    lat :0,
    lan : 0,
    listeners : function()
    {
    var tab=document.getElementById("event_create");
        tab.addEventListener("click",function(e)
        {
            EventManager.createEvent();
        });
    var support=document.getElementById("support");
        support.addEventListener("click",function(e){
        EventManager.createSupport();
        });
    var eventView = document.getElementById("eventView");
        eventView.addEventListener("click",function(e){
            EventManager.EventView();
        });
    this.hideSideBar();
        var element=document.querySelectorAll("ul.quick-menu li.col-sm-2");
        element[3].addEventListener("click", function () {
            this.ticket();
        }.bind(this));

    },
    createEvent : function()
    {
        var base = document.getElementById("details");
        base.innerHTML="";
        var events = new EventsDeals("Create - Event","base");
        var header= events.createHeader();
        var Form= events.createForm();
        var eventName=events.createFormGroup("Event-Name","input","Event Name","eventName","text","form-group");
        Form.appendChild(eventName[0]);
        var eventDescription=events.createFormGroup("Event-Description","textarea","Event Description","eventDescription","textarea","form-group");
        Form.appendChild(eventDescription[0]);
        var eventStartDate = events.createFormGroup("Start-Date","input","YYYY-MM-DD","StartDate","date","form-group");
        Form.appendChild(eventStartDate[0]);
        var eventEndDate=events.createFormGroup("End-Date","input","YYYY-MM-DD","EndDate","date","form-group");
        Form.appendChild(eventEndDate[0]);
        var eventStartTime=events.createFormGroup("Start-Time","input","HH:MM","StartTime","time","form-group clockpicker");
        eventStartTime[1].addEventListener("focus",function(e)
        {
            $('.clockpicker').clockpicker();
        });
        Form.appendChild(eventStartTime[0]);
        var eventEndTime = events.createFormGroup("End-Time","input","HH:MM","EndTime","time","form-group clockpicker");
        eventEndTime[1].addEventListener("focus",function(e)
        {
            $('.clockpicker').clockpicker();
        });
        Form.appendChild(eventEndTime[0]);
        var capacity = events.createFormGroup("Capacity","input","capacity","eventCapacity","number","form-group");
        Form.appendChild(capacity[0]);
        var ExpiryDate = events.createFormGroup("Expires","input","YYYY-MM-DD","expires","date","form-group");
        Form.appendChild(ExpiryDate[0]);
        var EventImage=events.createFormGroup("Event-Image","input","Event-Image","eventImage","file","form-group");
        Form.appendChild(EventImage[0]);
        var pincode = events.createFormGroup("Event-Area-PinCode","input","Pincode","pincode","text","form-group");
        Form.appendChild(pincode[0]);
        var area = events.createFormGroup("Event-Area","input","Area","Area","area","form-group");
        Form.appendChild(area[0]);
        var city = events.createFormGroup("Event-City","input","City","event","text","form-group");
        Form.appendChild(city[0]);
        var EventPrice = events.createFormWitBtn("adding-tabs","Individual-Fee","input","Individual-Fee","fee-form","text");
        Form.appendChild(EventPrice[0]);
        var submit = events.createSubmit("submit","Create-Event","btn btn-default","submit");
        submit.addEventListener("click",function(e)
        {
        e.preventDefault();
            EventManager.createEventListen();
        });
        Form.appendChild(submit);
        header[0].appendChild(Form);
        base.appendChild(header[1]);
        $( "#StartDate" ).datepicker({
            dateFormat: "yy-mm-dd"
        });
        $("#EndDate").datepicker(
            {
                dateFormat: "yy-mm-dd"
            });
        $("#expires").datepicker(
            {
                dateFormat: "yy-mm-dd"
            });
    },
    createEventListen : function()
    {
        var eventName = document.getElementById("eventName").value;
        var eventDescription = document.getElementById("eventDescription").value;
        var StartDate=document.getElementById("StartDate").value;
        var EndDate=document.getElementById("EndDate").value;
        var StartTime=document.getElementById("StartTime").value;
        var EndTime=document.getElementById("EndTime").value;
        var eventCapacity=document.getElementById("eventCapacity").value;
        var expires=document.getElementById("expires").value;
        var eventImage=document.getElementById("eventImage");
        var pincode=document.getElementById("pincode").value;
        var Area=document.getElementById("Area").value;
        var event=document.getElementById("event").value;
        var feeForm=document.getElementById("fee-form").value;
        try
        {
            DateSelector.validator(eventName,"eventName",/^[a-zA-Z0-9\s\-]+$/,"ONLY LETTERS ALLOWED FOLLOWED BY NUMBER");
            DateSelector.validator(eventDescription,"eventDescription",/^[a-zA-Z]+/,"Can Be Any Words");
            DateSelector.dateValidator(StartDate,EndDate,"Start Date Must be smallar than End Date","EndDate");
            DateSelector.timeFormat(StartTime,"StartTime");
            DateSelector.timeFormat(EndTime,"EndTime");
            DateSelector.validator(eventCapacity,"eventCapacity",/^[0-9]+$/,"Only Numbers Are Allowed");
            DateSelector.dateValidator(EndDate,expires,"Expire Date Must be greater than EndDate","expires");
            DateSelector.FileValidator(eventImage,"Kindly Upload Image","eventImage");
            DateSelector.validator(pincode,"pincode",/[0-9]{6}/,"Only Valid Pincode i.e 801503");
            DateSelector.validator(Area,"Area",/^[a-zA-Z0-9\s]+$/,"only Letters and Numbers are Allowed");
            DateSelector.validator(event,"event",/^[a-zA-Z\s0-9s]+$/,"only Letters and nubers Allowed");
            DateSelector.validator(feeForm,"fee-form",/^[0-9]+(\.[0-9]){0,}/,"Only Number Allowed");
            DateSelector.priceValidator();
            this.variation("adding-more-table","Max must greater than min");
            this.capacityCheck(eventCapacity,"adding-more-table","Max people must smaller or equal than capacity");
            var form = new FormData();
            form.append("event_name", eventName);
            form.append("description", eventDescription);
            form.append("startDate", StartDate);
            form.append("endDate", EndDate);
            form.append("startTime", StartTime);
            form.append("endTime", EndTime);
            form.append("capacity", eventCapacity);
            form.append("expiry", expires);
            form.append("IndFee", feeForm);
            form.append("image", eventImage.files[0]);
            form.append("zip", pincode);
            form.append("area", Area);
            form.append("city", event);
            form.append("cid",loc);
            form.append("request1", "event");
            var str=[];
            var pricing=document.querySelectorAll("#adding-tabs #adding-more-table tr.out");
            var total=pricing.length;
            if(total > 0)
            {
                for(var i=0;i<total;i++)
                {
                    var min=Number(pricing[i].children[0].children[0].value);
                    var max=Number(pricing[i].children[1].children[0].value);
                    var price=Number(pricing[i].children[2].children[0].value);
                    str.push(min+'||'+max+'||'+price);
                }
            }
            form.append("price",str.join('&'));
            Ajax.url="controller/alchol.php";
            Ajax.loadFormData(form,function(xhr)
            {
                if(xhr.readyState<4)
                {
                    Ajax.createFrame();
                }
                else
                {
                    var data=JSON.parse(xhr.responseText);
                    if(data.state==1)
                    {
                        if(document.getElementById("progress"))
                        {
                            var body=document.getElementsByTagName("body")[0];
                            body.removeChild(body.children[0]);
                            var base = document.getElementById("modification");
                            base.setAttribute("data-id",data.id);
                            base.innerHTML="";
                            EventManager.LoadMap(28.467077118435565, 77.5043427618408,data.id);
                        }
                    }
                }
            });

        }
        catch(E)
        {
            var split=E.split(":");
            DateSelector.showMessage(split[0],split[1]);
        }

    },
    capacityCheck : function(capacity,div,msg)
    {
        if(document.getElementById(div))
        {
            var table=document.getElementById(div);
            var lastRow=table.lastElementChild;
            var max=Number(lastRow.children[1].children[0].value);
            if(max > Number(capacity))
            {
                throw msg+":"+div;
            }
        }
    },
    variation : function(id,msg)
    {
        if(document.getElementById(id))
        {
            var table=document.getElementById(id);
            var lastRow=table.lastElementChild;
            var min=Number(lastRow.children[0].children[0].value);
            var max=Number(lastRow.children[1].children[0].value);
            if(min > max)
            {
                throw msg+":"+id;
            }
        }
    },
    LoadMap : function(lat,lng,id)
    {
        var map=new Location(lat, lng);
        map.initialize();
        var base=document.getElementById("modification").parentElement;
        var input=document.createElement("input");
        input.setAttribute("placeholder","Area/Location");
        input.setAttribute("class","form-group group-width");
        base.insertBefore(input,document.getElementById("modification").style.height="600px");
        this.button("TraceLocation","traceLocation",function(button){
            button.addEventListener("click",function(e)
            {
                navigator.geolocation.getCurrentPosition(EventManager.position)
            });
            var neighbour=base.children[1];
            base.insertBefore(button,neighbour);
        });
        this.button("SaveLocation","location",function(button){
            button.addEventListener("click",function(e)
            {
                EventManager.currentLocation(id);
            });
        base.appendChild(button);
        });
        input.addEventListener("change",function(e)
        {
            map.codeAddress(e.target.value,function(lat,lng){
                EventManager.lat=lat;
                EventManager.lan=lng;
            });
        });
    },
    currentLocation : function(id)
    {
        Ajax.url="controller/alchol.php";
        Ajax.setRequest('locations',id,this.lat,this.lan);
        Ajax.loadEncodedReq(function(xhr)
        {
        if(xhr.readyState<4)
        {
        Ajax.createFrame();
        }
        else
        {
            var data=JSON.parse(xhr.responseText);
            if(data.state==1)
            {
                if(document.getElementById("progress"))
                {
                    var body=document.getElementsByTagName("body")[0];
                    body.removeChild(body.children[0]);
                    var base = document.getElementById("outer_area");
                    base.innerHTML="";
                    alert("Event Created Sucessfully");
                }
            }
        }
        });
    },
    button : function(text,id,result)
    {
        var button =document.createElement("button");
        button.setAttribute("type","button");
        button.setAttribute("id",id);
        button.setAttribute("class","btn btn-default btn-block");
        button.innerHTML=text;
        result(button);
    },
    position : function(position)
    {
        var lat = position.coords.latitude;
        var lon = position.coords.longitude;
        this.LoadMap(lat,lon);
    },
    createSupport :function()
    {
     restaurant.create();
    },
    EventView : function()
    {
        Ajax.url="controller/alchol.php";
        Ajax.setRequest("ViewEvent",loc);
        Ajax.loadEncodedReq(function(xhr)
        {
           if(xhr.readyState<4)
           {
               Ajax.createFrame();
           }
            else {
               var result=JSON.parse(xhr.responseText);
               var event =new EventDealsView("View Events");
               event.createTable("event-list",function(table)
               {
                   var base=document.getElementById("details");
                   base.innerHTML="";
                   table.appendChild(event.createHead("Event-Name","Area","Event-Expires","Capacity","Events-Sold"));
                   for(var i=0;i<result.length;i++) {
                       if (result[i].state==1) {
                           if (result[i].visitors != null) {
                               table.appendChild(event.createBody(result[i].eventName, result[i].area, result[i].expires, result[i].capacity, result[i].sales, result[i].eid, function (a) {
                                   a.addEventListener("click", function (e) {
                                       e.preventDefault();
                                   });
                               }));
                           }
                           else {
                               table.appendChild(event.createBody(result[i].eventName, result[i].area, result[i].expires, result[i].capacity, 0, result[i].eid, function (a) {
                                   a.addEventListener("click", function (e) {
                                       e.preventDefault();
                                   });
                               }));
                           }
                       }
                   }
                   base.appendChild(table);
               });
               if(document.getElementById("progress")) {
                   var body = document.getElementsByTagName("body")[0];
                   body.removeChild(body.children[0]);
               }
           }
        });
    },
    LightBoxClose :function()
    {
        window.addEventListener("keydown",function(e)
        {
        if(e.keyCode==27)
        {
            var lightBox=new LightBoxPanel("upload-Image","file","image/*");
            lightBox.close();
        }
        });
    },
    upload : function(e)
        {
        var file=document.getElementById("js_3");
         if('files' in file)
         {
             if(file.files.length==0)
             {
                 alert("select file");
             }
             else
             {
                 this.uploadImage(e);
             }
         }
        },
    uploadImage :function(e)
    {
     AjaxUpload.url="controller/alchol.php";
        var form=new FormData();
        var file=document.getElementById("js_3");
        form.append("request1","displayPicManager");
        form.append("ref_id",loc);
        form.append("image",file.files[0]);
        var elem=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
        elem.appendChild(AjaxUpload.addProgressBar(e));
        AjaxUpload.loadFormData(form,function(e,state)
        {
            var element=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
            var progress=element.lastElementChild.children[0];
            if(state=="progress")
            {
                if(e.lengthComputable) {
                    var percent=Math.round((e.loaded/ e.total)*100);
                    progress.style.width=percent+'%';
                }
            }
            if(state=="loading")
            {
                var lightBox=new LightBoxPanel("upload-Image","file","image/*");
                var body=document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0];
                lightBox.message("Image-uploaded Sucessfully","fa fa fa-check",body,function(result)
                {
                    body.appendChild(result);
                });
            }
            if(state=="error")
            {
                alert("error");
            }
            if(e.readyState==4)
            {
                var data=JSON.parse(e.responseText);
                if(data.state==3)
                {
                    var img=document.getElementById("profile");
                    img.removeAttribute("src");
                    img.setAttribute("src",data.message);
                }
            }

        });
    },
    hideSideBar : function()
    {
    var sidebar=document.querySelector(".sidebar");
    sidebar.setAttribute("class","sidebar clearfix hidden");
        var content=document.querySelector(".content");
        content.style.marginLeft="0px";
    },
    ticket : function()
    {
        var parent=document.querySelector("#details");
        parent.innerHTML="";
        var ticket=new CreateTicket(parent,"ENTER USER TICKET REFERENCE ID");
        ticket.createPanel(function(label,input){
            label.setAttribute("for","Ticket");
            label.innerHTML="ENTER TICKET:";
            input.setAttribute("placeholder","ENTER TICKET REFERENCE");
        });
    }
};
var AjaxUpload ={
    url:'',
    loadFormData :function(form,callback) {
        var xhr;
        try {
            xhr=new XMLHttpRequest();
        } catch (e) {
            alert("unable to coneect");
        }
        xhr.upload.addEventListener("progress",function(e)
        {
            callback(e,'progress');
        });
        xhr.upload.addEventListener("load",function(e)
        {
            callback(e,'loading');
        });
        xhr.upload.addEventListener("error",function(e)
        {
            callback(e,"error");
        });
        xhr.onreadystatechange = dataLoader;
        function dataLoader()
        {
            if(xhr.readyState==4)
            {
               callback(xhr,'retrive');
            }
        }
        xhr.open("POST",this.url,true);
        xhr.send(form);
    },
    addProgressBar: function(e)
    {
        var progress=document.createElement("div");
        progress.setAttribute("class","progress progress-striped active");
        var progressBar=document.createElement("div");
        progressBar.setAttribute("class","progress-bar progress-bar-success");
        progressBar.setAttribute("role","progressbar");
        progressBar.setAttribute("aria-valuenow","60");
        progressBar.setAttribute("aria-valuemin","0");
        progressBar.setAttribute("aria-valuemax","100");
        progressBar.style.width=0+'%';
        var span=document.createElement("span");
        span.setAttribute("class","sr-only");
        span.innerHTML=60+"%completed";
        progressBar.appendChild(span);
        progress.appendChild(progressBar);
        return progress;
    }
};
var restaurantReg={
    emailExists : [],
    userExists :[],
    manageMail :[],
    changer : function()
    {
    var selector=document.querySelector("#register-changer");
    selector.addEventListener("change",function(e)
    {
    var current=e.target;
    var index=e.target.selectedIndex;
        var forms=document.querySelector("#forms");
    if(current[index].innerHTML=="Restaurants")
    {
        forms.innerHTML="";
       restaurantReg.register();
    }
    else
    {
        forms.innerHTML="";
        restaurantReg.Manager();
    }
    });
    },
    register:function()
    {
        var registrationPanel = new RegistrationPanel("#forms");
        var div=registrationPanel.formCreate();
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Name");
            label.setAttribute("for","Restaurant-Name");
            label.innerHTML="RestaurantName:";
            div.appendChild(label);
            input.setAttribute("id","restaurantName");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Email");
            label.setAttribute("for","RestaurantEmail");
            label.innerHTML="Restaurant-Email:";
            div.appendChild(label);
            input.setAttribute("id","RestaurantEmail");
            input.setAttribute("type","email");
            input.addEventListener("focus",function(e)
            {
            restaurantReg.emailExists.length=0;
            });
            input.addEventListener("blur",function(e){
                restaurantReg.emailValidator('EmailCheck');
            });
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Mobile");
            label.setAttribute("for","Mobile");
            label.innerHTML="Restaurant-Mobile:";
            div.appendChild(label);
            input.setAttribute("id","RestaurantMobile");
            input.setAttribute("type","tel");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Website");
            label.setAttribute("for","Restaurant");
            label.innerHTML="Restaurant-Website:";
            div.appendChild(label);
            input.setAttribute("id","RestaurantWebsite");
            input.setAttribute("type","url");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input,textarea){
            div.setAttribute("id","address");
            label.setAttribute("for","address");
            label.innerHTML="Restaurant-Address:";
            div.appendChild(label);
            textarea.setAttribute("id","RestaurantAddress");
            div.appendChild(textarea);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input,textarea,select){
            div.setAttribute("id","state");
            label.setAttribute("for","state");
            label.innerHTML="Restaurant-States:";
            div.appendChild(label);
            select.setAttribute("id","RestaurantState");
            select.addEventListener("change",function(e)
            {
                restaurantReg.changeCity(e);
            });
            Ajax.url="controller/alchol.php";
            Ajax.setRequest('restaurantState');
            Ajax.loadEncodedReq(function(xhr){
                if(xhr.readyState<4)
                {

                }
                else
                {
                    var data=JSON.parse(xhr.responseText);
                    for(var i=0;i<data.length;i++) {
                        if(data[i].status!=0) {
                            var option = document.createElement("option");
                            option.setAttribute("value", data[i].id);
                            option.innerHTML = data[i].state;
                            select.appendChild(option);
                        }
                    }
                    div.appendChild(select);
                }
            });
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input,textarea,select){
            div.setAttribute("id","city");
            label.setAttribute("for","city");
            label.innerHTML="Restaurant-City:";
            div.appendChild(label);
            select.setAttribute("id","RestaurantCity");
            var option=document.createElement("option");
            option.setAttribute("value",0);
            option.innerHTML="SELECT CITY";
            select.appendChild(option);
            div.appendChild(select);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","area");
            label.setAttribute("for","area");
            label.innerHTML="Restaurant-Area:";
            div.appendChild(label);
            input.setAttribute("id","RestaurantArea");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","pin");
            label.setAttribute("for","pin");
            label.innerHTML="Restaurant-Pin:";
            div.appendChild(label);
            input.setAttribute("id","RestaurantPin");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createTab(function(div,label,input,a,p,ol,skilllist,allSkillList){
            div.setAttribute("id","tags");
            label.setAttribute("for","Meta");
            label.setAttribute("class","form-label");
            label.innerHTML="Meta-Tags:";
            input.setAttribute("id","MetaTags");
            input.setAttribute("type","text");
            input.setAttribute("id","meta");
            a.setAttribute("id","edit-skill-add-btn");
            a.addEventListener("click",function(e)
            {
                var data = document.querySelector("#meta").value;
                registrationPanel.metaTagsEntry(data,function (div,a) {
                    var parent = document.querySelector(".all-skills-list .skills-list");
                    parent.appendChild(div);
                    a.addEventListener("click",function(e)
                    {
                    registrationPanel.removeTag(e);
                    });
                });
            document.querySelector("#meta").value="";
            });
            a.innerHTML="Add-MetaTag";
            p.innerHTML="You can Add 5 Tags";
            div.appendChild(skilllist);
            div.appendChild(allSkillList);
        }));
        var colDiv=document.createElement("div");
        colDiv.setAttribute("class","form-group");
        var label=document.createElement("p");
        label.setAttribute("class","form-label");
        label.innerHTML="Restaurant-Docs:";
        colDiv.appendChild(label);
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","aadhar");
            input.addEventListener("change",function(e)
            {
            registrationPanel.addFileUploader(e,function(opt,file,label){
             var divToAdd=document.querySelector("#file-verification");
             if(opt=="add") {
                 file.setAttribute("id", "aadhar-docs");
                 label.setAttribute("for","aadhar-docs");
                 label.innerHTML="ADHAR-DOCUMENT:";
                 divToAdd.appendChild(label);
                 divToAdd.appendChild(file);
             }
             else if(opt=="remove")
             {
                 if(document.querySelector("#aadhar-docs"))
                 {
                     var labels=document.querySelector("label[for=aadhar-docs]");
                     var docs=document.querySelector("#aadhar-docs");
                     divToAdd.removeChild(docs);
                     divToAdd.removeChild(labels);
                 }
             }
            });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","AdharCard");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("ADHAR-CARD");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","Voter");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "voter-docs");
                        label.setAttribute("for","Voter-docs");
                        label.innerHTML="VOTER-ID-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#voter-docs"))
                        {
                            var labels=document.querySelector("label[for=Voter-docs]");
                            var docs=document.querySelector("#voter-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","Voter-Id");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("VOTER-ID");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","shopLic");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "shopLicence-docs");
                        label.setAttribute("for","shop-Licence");
                        label.innerHTML="SHOPLICENCE-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#shopLicence-docs"))
                        {
                            var labels=document.querySelector("label[for=shop-Licence]");
                            var docs=document.querySelector("#shopLicence-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","CIN-Number");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("SHOP-LICENCE");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","pan");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "pancard-docs");
                        label.setAttribute("for","panCard-Licence");
                        label.innerHTML="PANCARD-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#pancard-docs"))
                        {
                            var labels=document.querySelector("label[for=panCard-Licence]");
                            var docs=document.querySelector("#pancard-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","Pan-card");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("PAN-CARD");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","sales");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "SalesTax-docs");
                        label.setAttribute("for","salesTax");
                        label.innerHTML="SALESTAX-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#SalesTax-docs"))
                        {
                            var labels=document.querySelector("label[for=salesTax]");
                            var docs=document.querySelector("#SalesTax-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","Sales-Tax");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("SALES-TAX");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","others");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label,input){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "other-docs");
                        label.setAttribute("for","other-docs");
                        label.innerHTML="OTHERS-DOCUMENT:";
                        divToAdd.appendChild(label);
                        input.setAttribute("type","text");
                        input.setAttribute("id","others-Value");
                        divToAdd.appendChild(input);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#other-docs"))
                        {
                            var labels=document.querySelector("label[for=other-docs]");
                            var inputForm=document.querySelector("#others-Value");
                            var docs=document.querySelector("#other-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                            divToAdd.removeChild(inputForm);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","others");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("OTHERS");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        div.appendChild(colDiv);
        div.appendChild(registrationPanel.FileUploaderDiv("file-verification"));
        var AlcholDiv=document.createElement("div");
        AlcholDiv.setAttribute("class","form-group");
        var alcholP=document.createElement("p");
        alcholP.setAttribute("class","form-label");
        alcholP.innerHTML="SERVE-ALCOHOL:";
        AlcholDiv.appendChild(alcholP);
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","alcohol");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#Alcohol-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "Alcohol-docs");
                        label.setAttribute("for","Alcohol-docs");
                        label.innerHTML="ALCOHOL-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#Alcohol-docs"))
                        {
                            var labels=document.querySelector("label[for=Alcohol-docs]");
                            var docs=document.querySelector("#Alcohol-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","alcohol");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("ALCOHOL");
            label.appendChild(input);
            label.appendChild(text);
            AlcholDiv.appendChild(label);
        });
        div.appendChild(AlcholDiv);
        div.appendChild(registrationPanel.FileUploaderDiv("Alcohol-verification"));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","username");
            label.setAttribute("for","username");
            label.innerHTML="Restaurant-Username:";
            div.appendChild(label);
            input.setAttribute("id","user");
            input.addEventListener("focus",function(e)
            {
            restaurantReg.userExists.length=0;
            });
            input.addEventListener("blur",function(e)
            {
                restaurantReg.usernameValidator("CheckUser");
            });
            input.setAttribute("type","text");
            div.appendChild(input);
        }));div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","password-div");
            label.setAttribute("for","password");
            label.innerHTML="Restaurant-Password:";
            div.appendChild(label);
            input.setAttribute("id","password");
            input.setAttribute("type","password");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.submitButton(function(result)
        {
        result.setAttribute("type","submit");
        result.setAttribute("class","btn btn-primary btn-lg");
        result.addEventListener("click",function(e)
        {
            restaurantReg.submitForm();
        });
        }));
    },
    changeCity : function(e)
    {
    var element=e.target.value;
     var loading = document.querySelector(".loading");
     Ajax.url="controller/alchol.php";
     Ajax.setRequest('LoadCity',element);
     Ajax.loadEncodedReq(function(xhr){
        if(xhr.readyState<4)
        {
        loading.style.display="block";
        }
         else
        {
         var data=JSON.parse(xhr.responseText);
         var cityList = document.querySelector("#RestaurantCity");
         cityList.innerHTML="";
         for(var i=0;i<data.length;i++)
            {
                var option=document.createElement("option");
                option.setAttribute("value",data[i].id);
                option.innerHTML=data[i].city;
                cityList.appendChild(option);
            }
            loading.style.display="none";
        }
     });
    },
    emailValidator:function()
    {
      var registrationPanel = new RegistrationPanel("#forms");
      var emailInput=document.querySelector("#RestaurantEmail").value;
      var email_id=document.querySelector("#Email");
      if(/^[a-z]+[a-z0-9_\.]+\@+[a-z0-9]+\.[a-z]+(\.)?([a-z]{2,9})/.test(emailInput))
      {
       Ajax.url="controller/alchol.php";
       Ajax.setRequest(arguments[0],emailInput);
       Ajax.loadEncodedReq(function(xhr)
       {
        if(xhr.readyState<4)
        {

            registrationPanel.QueryLoader(email_id,function(img)
            {
            img.setAttribute("src","img/ajax-loader.gif");
            img.setAttribute("width","20");
            img.setAttribute("height","10");
            img.style.float="right";
            email_id.appendChild(img);
            });
        }
        else
        {
        if(email_id.lastElementChild.nodeName=="IMG")
        {
        email_id.removeChild(email_id.lastElementChild);
        }
        var data=JSON.parse(xhr.responseText);
        if(data.status==1)
        {
        var div=document.querySelector("#Email");
        if(div.lastElementChild.nodeName!="P") {
          registrationPanel.CustomMessage("#Email : Email is Available!",function(p)
          {
            p.style.color="green";
          });
        }
        }
        else
        {
            restaurantReg.emailExists.push(1);
            registrationPanel.Message("#Email:Email Already Exists!");
        }
        }
       });
      }
      else
      {
          registrationPanel.Message("#Email:Not A Valid Format Of Email");
      }
    },
    usernameValidator : function()
    {
        var registrationPanel = new RegistrationPanel("#forms");
        var userInput=document.querySelector("#user").value;
        var usernameDiv=document.querySelector("#username");
        if(/^[a-zA-Z]+[a-z0-9_\-_A-Z]{5,}/.test(userInput))
        {
            Ajax.url="controller/alchol.php";
            Ajax.setRequest(arguments[0],userInput);
            Ajax.loadEncodedReq(function(xhr){
                if(xhr.readyState<4)
                {
                    registrationPanel.QueryLoader(usernameDiv,function(img)
                    {
                        img.setAttribute("src","img/ajax-loader.gif");
                        img.setAttribute("width","20");
                        img.setAttribute("height","10");
                        img.style.float="right";
                        usernameDiv.appendChild(img);
                    });
                }
                else
                {
                if(usernameDiv.lastElementChild.nodeName=="IMG")
                {
                        usernameDiv.removeChild(usernameDiv.lastElementChild);
                }
                var data=JSON.parse(xhr.responseText);
                if(data.state==1)
                {
                    var div=document.querySelector("#username");
                    if(div.lastElementChild.nodeName!="P") {
                        registrationPanel.CustomMessage("#username : USERNAME IS AVAILABLE!",function(p)
                        {
                            p.style.color="green";
                        });
                    }
                }
                else
                {
                    restaurantReg.userExists.push(1);
                    registrationPanel.Message("#username:USERNAME ALREADY EXISTS!");
                }
                }
            });
        }
        else
        {
            registrationPanel.Message("#username:NOT A VALID USERNAME ONLY LETTERS AND NUMBERS ARE ALLOWED");
        }
    },
    submitForm : function()
    {
    var registrationPanel = new RegistrationPanel("#forms");
    try
    {
    this.emailCheck("#Email:EMAIL IS NOT VALID");
    this.userCheck("#username: NOT A VALID USERNAME");
    var restaurantName=document.querySelector("#restaurantName").value;
    this.validation(/^[a-zA-Z]+.{5,}/,restaurantName,"#Name:NOT A VALID RESTAURANT NAME CAN START WITH LETTERS ONLY ATLEAST 5 CHARACTERS");
    var restaurantEmail=document.querySelector("#RestaurantEmail").value;
    this.validation(/^[a-z]+[a-z0-9_\.]+\@+[a-z0-9]+\.[a-z]+(\.)?([a-z]{2,9})/,restaurantEmail,"#Email:NOT A VALID EMAIL");
    var mobile=document.querySelector("#RestaurantMobile").value;
    this.validation(/^[0-9]{10}$/,mobile,"#Mobile : MOBILE NUMBER CAN BE 10 DIGITS ONLY IN FORMAT [xxxxxxxxxxx]");
    var website=document.querySelector("#RestaurantWebsite").value;
    this.validation(/^$|(^(www)+\.[a-z]{3,}\..)/,website,"#Website : CAN BE IN A FORMAT OF www.example.com");
    var address=document.querySelector("#RestaurantAddress").value;
    this.validation(/^[0-9A-Za-z#\*\-\_]+./,address,"#address : ONLY START WITH NAME,NUMBER,#,*,-,_");
    var state=document.querySelector("#RestaurantState");
    this.dropDown(state.value,"#state:SELECT A VALID STATE");
    var area=document.querySelector("#RestaurantArea").value;
    this.validation(/^[a-zA-Z0-9]+./,area,"#area:AREA CAN START FROM NAME AND NUMBER");
    var pin=document.querySelector("#RestaurantPin").value;
    this.validation(/^[0-9]{6}$/,pin,"#pin : PIN CAN BE NUMBERS ONLY OF LENGTH 6");
    if(document.querySelector("#aadhar-docs"))
    {
     var adharCard=document.querySelector("#aadhar-docs");
     this.filesValidator(adharCard,"#file-verification: UPLOAD YOUR ADHAR CARD");
    }
    if(document.querySelector("#voter-docs"))
     {
        var voter_docs=document.querySelector("#voter-docs");
        this.filesValidator(voter_docs,"#file-verification: UPLOAD YOUR VOTER ID");
     }
    if(document.querySelector("#shopLicence-docs"))
    {
        var shopLic=document.querySelector("#shopLicence-docs");
        this.filesValidator(shopLic,"#file-verification: UPLOAD YOUR SHOP LICENCE");
    }
    if(document.querySelector("#pancard-docs"))
    {
        var panCard=document.querySelector("#pancard-docs");
        this.filesValidator(panCard,"#file-verification: UPLOAD YOUR PAN CARD");
    }
    if(document.querySelector("#SalesTax-docs"))
    {
        var salesTax=document.querySelector("#SalesTax-docs");
        this.filesValidator(salesTax,"#file-verification: UPLOAD YOUR SALES TAX DOCUMENTS")
    }
    if(document.querySelector("#others-Value") && document.querySelector("#other-docs"))
    {
     var othersValue = document.querySelector("#others-Value").value;
     this.validation(/^[a-zA-Z]+[0-9a-zA-Z]./,othersValue,"#file-verification: ONLY NAMES AND NUMBERS ARE ALLOWED IN DOCUMENT TYPES");
     var otherFiles=document.querySelector("#other-docs");
     this.filesValidator(otherFiles,"#file-verification : UPLOAD A VALID DOCUMENT");
    }
    if(document.querySelector("#Alcohol-docs"))
    {
      var alcohol=document.querySelector("#Alcohol-docs");
      this.filesValidator(alcohol,"#Alcohol-verification: UPLOAD A LIQUOR LICENSE DOCUMENT");
    }
    var password=document.querySelector("#password").value;
    this.validation(/^([a-zA-Z0-9]).{6,}/,password,"#password-div : PASSWORD WILL START WITH LETTERS AND NUMBERS AND MINIMUM OF 6 CHARACTERS");
    var username =document.querySelector("#user").value;
    this.validation(/^[a-zA-Z]+[a-z0-9_\-_A-Z]{5,}/,username,"#username : ONLY LETTERS AND NUMBERS ARE ALLOWED OF MINIMUM 5 CHARACTERS");
        Ajax.url="controller/alchol.php";
        var formdata =new FormData();
    formdata.append("name",restaurantName);
    formdata.append("email",restaurantEmail);
    formdata.append("mobile",mobile);
    if(website=="")
    {
        formdata.append("website",0);
    }
    else
    {
        formdata.append("website",website);
    }
    formdata.append("address",address);
    var stateList=document.querySelector("#RestaurantState");
    var stateIndex=stateList.selectedIndex;
    var stateValues=stateList[stateIndex].innerHTML;
     formdata.append("states",stateValues);
    var cityList=document.querySelector("#RestaurantCity");
    var cityIndex=cityList.selectedIndex;
    var cityValue =cityList[cityIndex].innerHTML;
    formdata.append("city",cityValue);
    formdata.append("area",area);
    formdata.append("pin",pin);
    if(document.querySelector("#aadhar-docs"))
    {
        var adharDoc=document.querySelector("#aadhar-docs");
        formdata.append("adhar",adharDoc.files[0]);
        formdata.append("adhar-check",1);
    }
        if(!document.querySelector("#aadhar-docs"))
    {

        formdata.append("adhar-check",0);
    }
    if(document.querySelector("#voter-docs"))
    {
        var voterDoc=document.querySelector("#voter-docs");
        formdata.append("voter",voterDoc.files[0]);
        formdata.append("voter-check",1);
    }
        if(!document.querySelector("#voter-docs"))
    {

        formdata.append("voter-check",0);
    }
    if(document.querySelector("#shopLicence-docs"))
    {
            var shopLicDoc=document.querySelector("#shopLicence-docs");
            formdata.append("shoplic",shopLicDoc.files[0]);
            formdata.append("shopLic-check",1);
    }
        if(!document.querySelector("#shopLicence-docs"))
    {
            formdata.append("shopLic-check",0);
    }
    if(document.querySelector("#pancard-docs"))
    {
        var pancard=document.querySelector("#pancard-docs");
        formdata.append("pancard",pancard.files[0]);
        formdata.append("pancard-check",1);
    }
        if(!document.querySelector("#pancard-docs"))
    {
        formdata.append("pancard-check",0);
    }
    if(document.querySelector("#SalesTax-docs"))
    {
        var salesTaxDoc=document.querySelector("#SalesTax-docs");
        formdata.append("salestax",salesTaxDoc.files[0]);
        formdata.append("salesTax",1);
    }
        if(!document.querySelector("#SalesTax-docs"))
    {
        formdata.append("salesTax-check",0);
    }
    if(document.querySelector("#other-docs"))
    {
        var othersValues = document.querySelector("#others-Value").value;
        formdata.append("others",othersValues);
        var othersFile=document.querySelector("#other-docs");
        formdata.append("others",otherFiles.files[0]);
    }
    if(document.querySelector("#Alcohol-docs"))
    {
        var alcoholDoc=document.querySelector("#Alcohol-docs");
        formdata.append("alcohol",1);
        formdata.append("alcholDocs",alcoholDoc.files[0]);
    }
    if(!document.querySelector("#other-docs"))
    {
        formdata.append("others",0);
    }
        if(!document.querySelector("#Alcohol-docs"))
    {
        formdata.append("alcohol",0);
    }
    var metaTag=document.querySelector(".all-skills-list .skills-list");
     var Tag='';
      for(var i=0;i<metaTag.children.length;i++)
      {
        var tag=metaTag.children[i].childNodes[1].nodeValue;
         Tag +=tag+',';
      }
    formdata.append("metaTag",Tag.substr(0,Tag.length-1));
    formdata.append("username",document.querySelector("#user").value);
    formdata.append("password",document.querySelector("#password").value);
    formdata.append('request1',"restaurantReg");
    Ajax.loadFormData(formdata,function(xhr)
    {
        var loading = document.querySelector(".loading");
    if(xhr.readyState<4)
    {
        loading.style.display="block";
    }
    else
    {
        var Plat,Plan;
        loading.style.display="none";
        var base=document.querySelector("#modification");
        base.style.height=600+"px";
        base.innerHTML="";
        var data=JSON.parse(xhr.responseText);
        restaurantReg.LoadMap(data.city,data.area,data.pin,data.rid);

    }
    });
    }
     catch(e)
     {
        registrationPanel.Message(e);
     }
    },
    validation :function(pattern,data,msg)
    {
    if(!pattern.test(data))
    {
    throw msg;
    }
    },
    dropDown :function(data,message)
    {
    if(data==0)
    {
        throw message;
    }
    },
    filesValidator : function(files,message)
    {
        if(files.files.length==0)
        {
            throw  message;
        }
        if(files.files[0].size>2000000)
        {
            throw message+""+"MUST LOWER THAN 2MB";
        }
    },
    emailCheck:function(message)
    {
        if(this.emailExists.length!=0)
        {
            throw message;
        }
    },
    userCheck : function(message)
    {
        if(this.userExists.length!=0)
        {
            throw message;
        }
    },
    LoadMap:function(city,area,pin,rid)
    {
        var base=document.querySelector("#modification");
        base.style.height="600px";
        base.innerHTML="";
        var map=new Location(28.473301807459258,77.50009414276121);
        map.initialize();
        map.codeAddress(city+''+area+''+pin,function(lat,lan)
        {
           restaurantReg.MapButton(lat,lan,rid);
            base.setAttribute("data-lat",lat);
            base.setAttribute("data-lng",lan);
        });
    },
    MapButton :function(lat,lan,rid)
    {
        if(document.querySelector("#outer_area").lastElementChild.nodeName!="BUTTON") {
            var base=document.querySelector("#modification");
            var button = document.createElement("button");
            button.setAttribute("class", "btn btn-primary btn-block");
            button.setAttribute("data-id", rid);
            button.innerHTML = "SET LOCATION";
            button.addEventListener("click", function (e) {
                Ajax.url="controller/alchol.php";
                Ajax.setRequest('RestaurantLocation',base.getAttribute("data-lat"),base.getAttribute("data-lng"),rid);
                Ajax.loadEncodedReq(function(xhr){
                    var loading = document.querySelector(".loading");
                    if(xhr.readyState<4)
                    {
                    loading.style.display="block";
                    }
                    else if(xhr.readyState==4)
                    {
                    loading.style.display="none";
                    alert("successfully ! Registered");
                    location.assign("resturant_registration.php");
                    }
                });
            });
            document.querySelector("#outer_area").appendChild(button);
        }
    },
    Manager:function()
    {
        var registrationPanel = new RegistrationPanel("#forms");
        var div=registrationPanel.formCreate();
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","agentName");
            label.setAttribute("for","AGENT-NAME");
            label.innerHTML="AGENT-NAME:";
            div.appendChild(label);
            input.setAttribute("id","AgentName");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","agencyName");
            label.setAttribute("for","AGENCY-Name");
            label.innerHTML="AGENCY-NAME:";
            div.appendChild(label);
            input.setAttribute("id","AgencyName");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Email");
            label.setAttribute("for","Manger-Email");
            label.innerHTML="EMAIL:";
            div.appendChild(label);
            input.setAttribute("id","Manager-Email");
            input.setAttribute("type","email");
            input.addEventListener("focus",function(e)
            {
                restaurantReg.manageMail.length=0;
            });
            input.addEventListener("blur",function(e){
                restaurantReg.MailValidator('ManagerMail');
            });
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Mobile");
            label.setAttribute("for","Mobile");
            label.innerHTML="MOBILE:";
            div.appendChild(label);
            input.setAttribute("id","managermobile");
            input.setAttribute("type","tel");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","Website");
            label.setAttribute("for","manager-website");
            label.innerHTML="WEBSITE:";
            div.appendChild(label);
            input.setAttribute("id","managerWebite");
            input.setAttribute("type","url");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input,textarea){
            div.setAttribute("id","address");
            label.setAttribute("for","address");
            label.innerHTML="Address:";
            div.appendChild(label);
            textarea.setAttribute("id","managerAddress");
            div.appendChild(textarea);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input,textarea,select){
            div.setAttribute("id","state");
            label.setAttribute("for","state");
            label.innerHTML="STATE:";
            div.appendChild(label);
            select.setAttribute("id","managerstate");
            select.addEventListener("change",function(e)
            {
                restaurantReg.changeCity(e);
            });
            Ajax.url="controller/alchol.php";
            Ajax.setRequest('restaurantState');
            Ajax.loadEncodedReq(function(xhr){
                var loading = document.querySelector(".loading");
                if(xhr.readyState<4)
                {
                loading.style.display="block";
                }
                else
                {
                    var data=JSON.parse(xhr.responseText);
                    for(var i=0;i<data.length;i++) {
                        if(data[i].status!=0) {
                            var option = document.createElement("option");
                            option.setAttribute("value", data[i].id);
                            option.innerHTML = data[i].state;
                            select.appendChild(option);
                        }
                    }
                    div.appendChild(select);
                    loading.style.display="none";
                }
            });
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input,textarea,select){
            div.setAttribute("id","city");
            label.setAttribute("for","city");
            label.innerHTML="CITY:";
            div.appendChild(label);
            select.setAttribute("id","RestaurantCity");
            var option=document.createElement("option");
            option.setAttribute("value",0);
            option.innerHTML="SELECT CITY";
            select.appendChild(option);
            div.appendChild(select);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","area");
            label.setAttribute("for","area");
            label.innerHTML="AREA:";
            div.appendChild(label);
            input.setAttribute("id","ManagerArea");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createField(function(div,label,input){
            div.setAttribute("id","pin");
            label.setAttribute("for","pin");
            label.innerHTML="PINCODE:";
            div.appendChild(label);
            input.setAttribute("id","RestaurantPin");
            input.setAttribute("type","text");
            div.appendChild(input);
        }));
        div.appendChild(registrationPanel.createTab(function(div,label,input,a,p,ol,skilllist,allSkillList){
            div.setAttribute("id","tags");
            label.setAttribute("for","Meta");
            label.setAttribute("class","form-label");
            label.innerHTML="Meta-Tags:";
            input.setAttribute("id","MetaTags");
            input.setAttribute("type","text");
            input.setAttribute("id","meta");
            a.setAttribute("id","edit-skill-add-btn");
            a.addEventListener("click",function(e)
            {
                var data = document.querySelector("#meta").value;
                registrationPanel.metaTagsEntry(data,function (div,a) {
                    var parent = document.querySelector(".all-skills-list .skills-list");
                    parent.appendChild(div);
                    a.addEventListener("click",function(e)
                    {
                        registrationPanel.removeTag(e);
                    });
                });
                document.querySelector("#meta").value="";
            });
            a.innerHTML="Add-MetaTag";
            p.innerHTML="You can Add 5 Tags";
            div.appendChild(skilllist);
            div.appendChild(allSkillList);
        }));
        var colDiv=document.createElement("div");
        colDiv.setAttribute("class","form-group");
        var label=document.createElement("p");
        label.setAttribute("class","form-label");
        label.innerHTML="MANAGER-DOCS:";
        colDiv.appendChild(label);
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","aadhar");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "aadhar-docs");
                        label.setAttribute("for","aadhar-docs");
                        label.innerHTML="ADHAR-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#aadhar-docs"))
                        {
                            var labels=document.querySelector("label[for=aadhar-docs]");
                            var docs=document.querySelector("#aadhar-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","AdharCard");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("ADHAR-CARD");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","Voter");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "voter-docs");
                        label.setAttribute("for","Voter-docs");
                        label.innerHTML="VOTER-ID-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#voter-docs"))
                        {
                            var labels=document.querySelector("label[for=Voter-docs]");
                            var docs=document.querySelector("#voter-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","Voter-Id");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("VOTER-ID");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","shopLic");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "shopLicence-docs");
                        label.setAttribute("for","shop-Licence");
                        label.innerHTML="SHOPLICENCE-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#shopLicence-docs"))
                        {
                            var labels=document.querySelector("label[for=shop-Licence]");
                            var docs=document.querySelector("#shopLicence-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","CIN-Number");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("SHOP-LICENCE");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","pan");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "pancard-docs");
                        label.setAttribute("for","panCard-Licence");
                        label.innerHTML="PANCARD-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#pancard-docs"))
                        {
                            var labels=document.querySelector("label[for=panCard-Licence]");
                            var docs=document.querySelector("#pancard-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","Pan-card");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("PAN-CARD");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","sales");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "SalesTax-docs");
                        label.setAttribute("for","salesTax");
                        label.innerHTML="SALESTAX-DOCUMENT:";
                        divToAdd.appendChild(label);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#SalesTax-docs"))
                        {
                            var labels=document.querySelector("label[for=salesTax]");
                            var docs=document.querySelector("#SalesTax-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","Sales-Tax");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("SALES-TAX");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        registrationPanel.createCheckBox(function(input,label)
        {
            input.setAttribute("id","others");
            input.addEventListener("change",function(e)
            {
                registrationPanel.addFileUploader(e,function(opt,file,label,input){
                    var divToAdd=document.querySelector("#file-verification");
                    if(opt=="add") {
                        file.setAttribute("id", "other-docs");
                        label.setAttribute("for","other-docs");
                        label.innerHTML="OTHERS-DOCUMENT:";
                        divToAdd.appendChild(label);
                        input.setAttribute("type","text");
                        input.setAttribute("id","others-Value");
                        divToAdd.appendChild(input);
                        divToAdd.appendChild(file);
                    }
                    else if(opt=="remove")
                    {
                        if(document.querySelector("#other-docs"))
                        {
                            var labels=document.querySelector("label[for=other-docs]");
                            var inputForm=document.querySelector("#others-Value");
                            var docs=document.querySelector("#other-docs");
                            divToAdd.removeChild(docs);
                            divToAdd.removeChild(labels);
                            divToAdd.removeChild(inputForm);
                        }
                    }
                });
            });
            input.setAttribute("type","checkbox");
            label.setAttribute("for","others");
            label.setAttribute("class","checkbox-inline");
            var text=document.createTextNode("OTHERS");
            label.appendChild(input);
            label.appendChild(text);
            colDiv.appendChild(label);
        });
        div.appendChild(colDiv);
        div.appendChild(registrationPanel.FileUploaderDiv("file-verification"));
        div.appendChild(registrationPanel.submitButton(function(result)
        {
            result.setAttribute("type","submit");
            result.setAttribute("class","btn btn-primary btn-lg");
            result.addEventListener("click",function(e)
            {
                restaurantReg.registerManager();
            });
        }));
    },
    MailValidator : function()
    {
        var registrationPanel = new RegistrationPanel("#forms");
        var emailInput=document.querySelector("#Manager-Email").value;
        var email_id=document.querySelector("#Email");
        if(/^[a-z]+[a-z0-9_\.]+\@+[a-z0-9]+\.[a-z]+(\.)?([a-z]{2,9})/.test(emailInput))
        {
            Ajax.url="controller/alchol.php";
            Ajax.setRequest(arguments[0],emailInput);
            Ajax.loadEncodedReq(function(xhr)
            {
                if(xhr.readyState<4)
                {

                    registrationPanel.QueryLoader(email_id,function(img)
                    {
                        img.setAttribute("src","img/ajax-loader.gif");
                        img.setAttribute("width","20");
                        img.setAttribute("height","10");
                        img.style.float="right";
                        email_id.appendChild(img);
                    });
                }
                else
                {
                    if(email_id.lastElementChild.nodeName=="IMG")
                    {
                        email_id.removeChild(email_id.lastElementChild);
                    }
                    var data=JSON.parse(xhr.responseText);
                    if(data.status==1)
                    {
                        var div=document.querySelector("#Email");
                        if(div.lastElementChild.nodeName!="P") {
                            registrationPanel.CustomMessage("#Email : Email is Available!",function(p)
                            {
                                p.style.color="green";
                            });
                        }
                    }
                    else
                    {
                        restaurantReg.manageMail.push(1);
                        registrationPanel.Message("#Email:Email Already Exists!");
                    }
                }
            });
        }
        else
        {
            registrationPanel.Message("#Email:Not A Valid Format Of Email");
        }
    },
    registerManager : function()
    {
        var registrationPanel = new RegistrationPanel("#forms");
    try {
        this.ManagerMail("#Email: EMAIL ALREADY EXISTS");
        var agentname=document.querySelector("#AgentName").value;
        this.validation(/^[a-zA-Z]+.{5,}/,agentname,"#agentName:NOT A VALID AGENT NAME CAN START WITH LETTERS AND ATLEAST 5 CHARACTERS");
        var agencyName=document.querySelector("#AgencyName").value;
        this.validation(/^[a-zA-Z]+.{5,}/,agencyName,"#agencyName:NOT A VALID AGENCY NAME CAN START WITH LETTERS AND ATLEAST 5 CHARACTERS");
        var ManagerEmail=document.querySelector("#Manager-Email").value;
        this.validation(/^[a-z]+[a-z0-9_\.]+\@+[a-z0-9]+\.[a-z]+(\.)?([a-z]{2,9})/,ManagerEmail,"#Email:NOT A VALID EMAIL");
        var mobile=document.querySelector("#managermobile").value;
        this.validation(/^[0-9]{10}$/,mobile,"#Mobile:MOBILE NUMBER CAN BE 10 DIGITS ONLY IN FORMAT [xxxxxxxxxxx]");
        var website=document.querySelector("#managerWebite").value;
        this.validation(/^$|(^(www)+\.[a-z]{3,}\..)/,website,"#Website:CAN BE IN A FORMAT OF www.example.com");
        var address=document.querySelector("#managerAddress").value;
        this.validation(/^[0-9A-Za-z#\*\-\_]+./,address,"#address:ONLY START WITH NAME,NUMBER,#,*,-,_");
        var state=document.querySelector("#managerstate");
        this.dropDown(state.value,"#state:SELECT A VALID STATE");
        var area=document.querySelector("#ManagerArea").value;
        this.validation(/^[a-zA-Z0-9]+./,area,"#area:AREA CAN START FROM NAME AND NUMBER");
        var pin=document.querySelector("#RestaurantPin").value;
        this.validation(/^[0-9]{6}$/,pin,"#pin:PIN CAN BE NUMBERS ONLY OF LENGTH 6");
        if(document.querySelector("#aadhar-docs"))
        {
            var adharCard=document.querySelector("#aadhar-docs");
            this.filesValidator(adharCard,"#file-verification: UPLOAD YOUR ADHAR CARD");
        }
        if(document.querySelector("#voter-docs"))
        {
            var voter_docs=document.querySelector("#voter-docs");
            this.filesValidator(voter_docs,"#file-verification: UPLOAD YOUR VOTER ID");
        }
        if(document.querySelector("#shopLicence-docs"))
        {
            var shopLic=document.querySelector("#shopLicence-docs");
            this.filesValidator(shopLic,"#file-verification: UPLOAD YOUR SHOP LICENCE");
        }
        if(document.querySelector("#pancard-docs"))
        {
            var panCard=document.querySelector("#pancard-docs");
            this.filesValidator(panCard,"#file-verification: UPLOAD YOUR PAN CARD");
        }
        if(document.querySelector("#SalesTax-docs"))
        {
            var salesTax=document.querySelector("#SalesTax-docs");
            this.filesValidator(salesTax,"#file-verification: UPLOAD YOUR SALES TAX DOCUMENTS")
        }
        if(document.querySelector("#others-Value") && document.querySelector("#other-docs"))
        {
            var othersValue = document.querySelector("#others-Value").value;
            this.validation(/^[a-zA-Z]+[0-9a-zA-Z]./,othersValue,"#file-verification: ONLY NAMES AND NUMBERS ARE ALLOWED IN DOCUMENT TYPES");
            var otherFiles=document.querySelector("#other-docs");
            this.filesValidator(otherFiles,"#file-verification : UPLOAD A VALID DOCUMENT");
        }
        var formdata=new FormData();
        Ajax.url="controller/alchol.php";
        formdata.append("AgentName",agentname);
        formdata.append("AgencyName",agencyName);
        formdata.append("Email",ManagerEmail);
        formdata.append("mobile",mobile);
        if(website=="")
        {
            formdata.append("website",0);
        }
        else
        {
            formdata.append("website",website);
        }
        formdata.append("address",address);
        var stateList=document.querySelector("#managerstate");
        var stateIndex=stateList.selectedIndex;
        var stateValues=stateList[stateIndex].innerHTML;
        formdata.append("states",stateValues);
        var cityList=document.querySelector("#RestaurantCity");
        var cityIndex=cityList.selectedIndex;
        var cityValue =cityList[cityIndex].innerHTML;
        formdata.append("city",cityValue);
        formdata.append("area",area);
        formdata.append("pin",pin);
        if(document.querySelector("#aadhar-docs"))
        {
            var adharDoc=document.querySelector("#aadhar-docs");
            formdata.append("adhar",adharDoc.files[0]);
            formdata.append("adhar-check",1);
        }
        if(!document.querySelector("#aadhar-docs"))
        {

            formdata.append("adhar-check",0);
        }
        if(document.querySelector("#voter-docs"))
        {
            var voterDoc=document.querySelector("#voter-docs");
            formdata.append("voter",voterDoc.files[0]);
            formdata.append("voter-check",1);
        }
        if(!document.querySelector("#voter-docs"))
        {

            formdata.append("voter-check",0);
        }
        if(document.querySelector("#shopLicence-docs"))
        {
            var shopLicDoc=document.querySelector("#shopLicence-docs");
            formdata.append("shoplic",shopLicDoc.files[0]);
            formdata.append("shopLic-check",1);
        }
        if(!document.querySelector("#shopLicence-docs"))
        {
            formdata.append("shopLic-check",0);
        }
        if(document.querySelector("#pancard-docs"))
        {
            var pancard=document.querySelector("#pancard-docs");
            formdata.append("pancard",pancard.files[0]);
            formdata.append("pancard-check",1);
        }
        if(!document.querySelector("#pancard-docs"))
        {
            formdata.append("pancard-check",0);
        }
        if(document.querySelector("#SalesTax-docs"))
        {
            var salesTaxDoc=document.querySelector("#SalesTax-docs");
            formdata.append("salestax",salesTaxDoc.files[0]);
            formdata.append("salesTax",1);
        }
        if(!document.querySelector("#SalesTax-docs"))
        {
            formdata.append("salesTax-check",0);
        }
        if(document.querySelector("#other-docs"))
        {
            var othersValues = document.querySelector("#others-Value").value;
            formdata.append("others",othersValues);
            var othersFile=document.querySelector("#other-docs");
            formdata.append("others",otherFiles.files[0]);
        }
        if(!document.querySelector("#other-docs"))
        {
            formdata.append("others",0);
        }
        var metaTag=document.querySelector(".all-skills-list .skills-list");
        var Tag='';
        for(var i=0;i<metaTag.children.length;i++)
        {
            var tag=metaTag.children[i].childNodes[1].nodeValue;
            Tag +=tag+',';
        }
        formdata.append("metaTag",Tag.substr(0,Tag.length-1));
         formdata.append("request1","ManagerRegister");
        Ajax.loadFormData(formdata,function(xhr)
        {
            var loading = document.querySelector(".loading");
        if(xhr.readyState<4)
        {
        loading.style.display="block";
        }
        else if(xhr.readyState==4){
            loading.display="none";
            alert("Congratulations! Successfully Registered");
            location.assign("resturant_registration.php");
            }
        });
    }
    catch(e)
    {
        registrationPanel.Message(e);
    }
    },
    ManagerMail:function(message)
    {
        if(this.manageMail.length!=0)
        {
            throw message;
        }
    }
};
var Coupon={
    type: null,
    restaurant : [],
    events:[],
    deals : [],
    couponCode:0,
    Name : 0,
    Action : function()
    {
        var selectors = document.querySelector("#discount .input-group-addon");
        var discount=document.querySelector("#Discount-val");
        this.changeDropDown(selectors,discount);
        var cashbackDiv=document.querySelector("#cashBack .input-group-addon");
        var cashback=document.querySelector("#CashBack-val");
        this.changeDropDown(cashbackDiv,cashback);
        var shipping=document.querySelector("#shipping .input-group-addon");
        var shippingDiscount=document.querySelector("#Shipping-val");
        this.changeDropDown(shipping,shippingDiscount);
        var convenience=document.querySelector("#convenience .input-group-addon");
        var convenienceDiscount=document.querySelector("#Convenience-val");
        this.changeDropDown(convenience,convenienceDiscount);
        var checkbox=document.querySelector("#numbersSelect");
        var event=document.querySelector("#EVENTS");
        var deals=document.querySelector("#DEALS");
        var city=document.querySelector("#city-val");
        var all=document.querySelector("#ALL");
        var usage=document.querySelector("#peoples");
        var endDate=document.querySelector("#ends .hang");
        var ageGroup=document.querySelector("#check-age");
        var allage=document.querySelector("#all-age");
        var btn=document.querySelector("#picode-Add-btn");
        var pincode=document.querySelector("#AreaCode #pinCode");
        var pinDiv=document.querySelector("#Code-div .col-sm-10");
        var submitButton=document.querySelector("#gen-coupon");
        var couponCode=document.querySelector("#couponCode");
        couponCode.addEventListener("blur",function(e){
        this.CouponCheck(e);
        }.bind(this));
        var couponName = document.querySelector("#input2");
        couponName.addEventListener("blur",function(e){
        this.couponName(e)
        }.bind(this));
        submitButton.addEventListener("click",function(e){
            e.preventDefault();
        this.submitCoupon();
        }.bind(this));
        var zip =new Pincode(pincode,btn,pinDiv,city);
        zip.AddPin();
        city.addEventListener("focus",function(e)
        {
        if(checkbox.checked==true)
        {
            checkbox.checked=false;
        }
        if(event.checked==true)
        {
           event.checked=false;
        }
        if(deals.checked==true)
        {
            deals.checked=false;
        }
        if(all.checked==true)
        {
            all.checked=false;
        }
        });
        checkbox.addEventListener("change",function(e)
        {
        if(e.target.checked==true)
        {
        Coupon.searchRestaurants(e);
        if(all.checked==true)
        {
            all.checked=false;
        }
        }
        else
        {
        Coupon.removeRestaurant();
        }
        });
        event.addEventListener("change",function(e)
        {
         if(e.target.checked==true)
            {
                Coupon.searchEvents(e);
                if(all.checked==true)
                {
                    all.checked=false;
                }
            }
         else
            {
                Coupon.removeAllEvent(e);
            }
        });
        deals.addEventListener("change",function(e){
            if(e.target.checked==true)
            {
                Coupon.searchDeals(e);
                if(all.checked==true)
                {
                    all.checked=false;
                }
            }
            else
            {
                Coupon.removeAllDeal(e);
            }
        });
        all.addEventListener("change",function(e){
            if(e.target.checked==true)
            {
                checkbox.checked=false;
                event.checked=false;
                deals.checked=false;
                Coupon.closeAll();
            }
        });
        usage.addEventListener("change",function(e){
            if(e.target.checked==true)
            {
            Coupon.addTextBox(e);
            }
            else
            {
            Coupon.removeTextBox(e);
            }
        });
        endDate.addEventListener("change",function(e){
            if(e.target.checked==true)
            {
                Coupon.enableExpiry(e);
            }
            else
            {
                Coupon.disableExpiry(e);
            }
        });
        ageGroup.addEventListener("change",function(e){
            if(e.target.checked==true)
            {
                this.addTables();
                allage.checked=false;
            }
            else {
              this.removeAll();
            }
        }.bind(this));
       allage.addEventListener("change",function(e){
        if(e.target.checked==true)
        {
            this.removeAll();
        }
       }.bind(this));
    },
    changeDropDown: function(selectors,discount)
    {
        var coupon=new CouponType(selectors,discount.getAttribute("data-type"));
        selectors.addEventListener("click",function(e){
            coupon.createSelector(function(a){
                a.addEventListener("click",function()
                {
                    coupon.change(function(state){
                        discount.setAttribute("placeholder",state.toUpperCase());
                        discount.setAttribute("data-type",state);
                    });
                });
            });},false);
        discount.addEventListener("focus",function(e)
        {
        coupon.close();
        });
    },
    searchRestaurants : function(e)
    {
        var city=document.querySelector("#city-val").value;
        try {
            if (city == "") {
                e.target.checked=false;
                throw "#city:CANNOT BE LEFT BLANK";
            }
            else
            {
                this.createInput(city,'ENTER THE RESTAURANT NAME','LoadRestaurant','restaurant','SEARCH RESTAURANT','restaurant');
            }
        }
        catch(E)
        {
        alert(E);
        }
    },
    createInput : function(city,placeholder,search,type,str,item)
    {
        var particular=document.querySelector("#particulars");
        var div=document.createElement("div");
        div.setAttribute("class","col-sm-10 "+type);
        var input=document.createElement("input");
        input.setAttribute("type","text");
        input.setAttribute("class","form-control");
        input.setAttribute("placeholder",placeholder);
        div.appendChild(input);
        particular.appendChild(div);
        input.addEventListener("keyup",function(e)
        {
            var items=document.querySelector("#particulars .col-sm-10."+item+" ul");
            Request.url="controller/alchol.php";
            Request.setRequest(search,e.target.value,city);
            Request.method="POST";
            Request.createRequest({
                open:function()
                {

                },
                loading:function()
                {
                items.innerHTML="";
                },
                progress : function()
                {
                    items.innerHTML="";
                },
                load : function(xhr)
                {
                var data=JSON.parse(xhr.responseText);
                for(var i=0;i<data.length;i++)
                {
                    var li=document.createElement("li");
                    var a=document.createElement("a");
                    if(data[i].state!=0) {
                        a.setAttribute("href", data[i].id);
                        a.innerHTML = data[i].name;
                        a.addEventListener("click",function(e){
                                e.preventDefault();
                                Coupon.addTag(e,type);
                            Coupon.clicked(e);
                        });
                        li.appendChild(a);
                        items.appendChild(li);
                    }
                    else
                    {
                      a.setAttribute("href","#");
                        a.innerHTML="NO RESULTS FOUND";
                       li.appendChild(a);
                        items.appendChild(li);
                    }
                }
                },
                error : function()
                {

                }
            });
        });
       input.addEventListener("focus",function(e)
       {
        if(!div.childNodes[1]) {
            div.appendChild(Coupon.Search(str));
        }
       });
    },
    Search : function(str)
    {
        var ul=document.createElement("ul");
        ul.setAttribute("class","results");
        var li=document.createElement("li");
        var a=document.createElement("a");
        a.innerHTML=str;
        li.appendChild(a);
        ul.appendChild(li);
        return ul;
    },
    addTag : function(e,type)
    {
        try {

                this.filter(e);
                this.eventFilter(e);
                this.dealFilter(e);
                var parent = document.querySelector("#selectedVal .col-sm-10");
                var div = document.createElement("div");
                div.setAttribute("class", "kode-alert alert1 col-sm-3 seperator");
                div.setAttribute("data-type",type);
                var a = document.createElement("a");
                a.setAttribute("href", e.target.getAttribute("href"));
                if(type=="restaurant") {
                    a.addEventListener("click", function (e) {
                        e.preventDefault();
                        Coupon.remove(e);
                    });
                }
                if(type=="event")
                {
                    a.addEventListener("click", function (e) {
                        e.preventDefault();
                        Coupon.removeEvent(e);
                    });
                }
                if(type=="deal")
                {
                    a.addEventListener("click", function (e) {
                        e.preventDefault();
                        Coupon.removeDeal(e);
                    });
                }
                a.setAttribute("class", "closed");
                a.innerHTML = "x";
                var text = document.createTextNode(e.target.innerHTML);
                div.appendChild(text);
                div.appendChild(a);
                parent.appendChild(div);
                if(type=="restaurant") {
                    this.restaurant.push({'id': e.target.getAttribute("href"), 'value': e.target.innerHTML});
                }
                if(type=="event")
                {
                    this.events.push({'id':e.target.getAttribute("href"),'value':e.target.innerHTML});
                }
                if(type=="deal")
                {
                    this.deals.push({'id':e.target.getAttribute("href"),'value':e.target.innerHTML});
                }
        }
        catch (e)
        {
            alert(e);
        }
    },
    filter :function(e)
    {
        this.restaurant.forEach(function(v,a,i){
            if(e.target.getAttribute("href")==v.id)
            {
                throw "Already Exist";
            }
        });
    },
    eventFilter :function(e)
    {
        this.events.forEach(function(v,a,i){
            if(e.target.getAttribute("href")==v.id)
            {
                throw "Already Exist";
            }
        });
    },
    dealFilter : function(e)
    {
        this.deals.forEach(function(v,a,i){
            if(e.target.getAttribute("href")==v.id)
            {
                throw "Already Exist";
            }
        });
    },
    remove : function(e)
    {
        var parent = document.querySelector("#selectedVal .col-sm-10");
        var href=e.target.getAttribute("href");
        this.restaurant.forEach(function(v,a,i){
            if(href==v.id)
            {
                var index=Coupon.restaurant.indexOf(v);
                Coupon.restaurant.splice(index,1);
            }
        });
        var element=e.target.parentElement;
        parent.removeChild(element);
    },
    removeRestaurant : function()
    {
        var parent=document.querySelector("#particulars");
        var element=document.querySelector("#particulars .restaurant");
        parent.removeChild(element);
        var i=0;
        var tagDivs=document.querySelector("#selectedVal .col-sm-10");
        var tags=tagDivs.querySelectorAll("[data-type=restaurant]");
        while(i<tags.length)
        {
            tagDivs.removeChild(tags[i]);
            i++;
        }
    this.restaurant.length=0;
    },
    searchEvents : function(e)
    {
        var city=document.querySelector("#city-val").value;
        try {
            if (city == "") {
                e.target.checked=false;
                throw "#city:CANNOT BE LEFT BLANK";
            }
            else
            {
                this.createInput(city,'ENTER THE EVENT NAME','LoadEvent','event','SEARCH EVENTS','event');
            }
        }
        catch(E)
        {
            alert(E);
        }
    },
    removeEvent : function(e)
    {
        var parent = document.querySelector("#selectedVal .col-sm-10");
        var href=e.target.getAttribute("href");
        this.events.forEach(function(v,a,i){
            if(href==v.id)
            {
                var index=Coupon.events.indexOf(v);
                Coupon.events.splice(index,1);
            }
        });
        var element=e.target.parentElement;
        parent.removeChild(element);
    },
    removeAllEvent : function()
    {
        var parent=document.querySelector("#particulars");
        var element=document.querySelector("#particulars .event");
        parent.removeChild(element);
        var i=0;
        var tagDivs=document.querySelector("#selectedVal .col-sm-10");
        var tags=tagDivs.querySelectorAll("[data-type=event]");
        while(i<tags.length)
        {
            tagDivs.removeChild(tags[i]);
            i++;
        }
        this.events.length=0;
    },
    searchDeals : function(e)
    {
        var city=document.querySelector("#city-val").value;
        try {
            if (city == "") {
                e.target.checked=false;
                throw "#city:CANNOT BE LEFT BLANK";
            }
            else
            {
                this.createInput(city,'ENTER THE DEAL NAME','LoadDeals','deal','SEARCH DEALS','deal');
            }
        }
        catch(E)
        {
            alert(E);
        }
    },
    removeDeal :function(e)
    {
        var parent = document.querySelector("#selectedVal .col-sm-10");
        var href=e.target.getAttribute("href");
        this.deals.forEach(function(v,a,i){
            if(href==v.id)
            {
                var index=Coupon.deals.indexOf(v);
                Coupon.deals.splice(index,1);
            }
        });
        var element=e.target.parentElement;
        parent.removeChild(element);
    },
    removeAllDeal : function(e)
    {
        var parent=document.querySelector("#particulars");
        var element=document.querySelector("#particulars .deal");
        parent.removeChild(element);
        var i=0;
        var tagDivs=document.querySelector("#selectedVal .col-sm-10");
        var tags=tagDivs.querySelectorAll("[data-type=deal]");
        while(i<tags.length)
        {
            tagDivs.removeChild(tags[i]);
            i++;
        }
        this.deals.length=0;
    },
    closeAll : function()
    {
        if(document.querySelector("#particulars .col-sm-10"))
        {
            var i=0;
            var parent=document.querySelector("#particulars");
            var allSearches=document.querySelectorAll("#particulars .col-sm-10");
            var totalItems=allSearches.length;
            while(i<totalItems)
            {
            parent.removeChild(allSearches[i]);
            i++;
            }
            var selectedVal=document.querySelector("#selectedVal .col-sm-10");
            var total=selectedVal.childElementCount;
            var j=0;
            while(j<=total)
            {
                selectedVal.removeChild(selectedVal.children[0]);
                j++;
            }

        }
    },
    addTextBox : function(e)
    {
        var externalDIv=document.createElement("div");
        externalDIv.setAttribute("class","col-sm-10");
    var input=document.createElement("input");
     input.setAttribute("class","form-control form-control-radius");
        input.setAttribute("placeholder","ENTER THE NUMBER OF USAGE");
        externalDIv.appendChild(input);
     var parent=document.querySelector("#numbers");
     parent.appendChild(externalDIv);
    },
    removeTextBox : function(e)
    {
    var element=document.querySelector("#numbers .col-sm-10");
     var parent=document.querySelector("#numbers");
     parent.removeChild(element);
    },
    enableExpiry : function(e)
    {
        var div=document.querySelector("#ends #date-picker");
        div.setAttribute("disabled","true");

    },
    disableExpiry : function(e)
    {
        var div=document.querySelector("#ends #date-picker");
        div.removeAttribute("disabled");
    },
    addTables : function(e)
    {
        var mainDiv=document.querySelector("#rangeOfAge .col-sm-10");
        try {
            var range = new Range(mainDiv,0,['min-age','max-age'],false,"REMOVE");
            var table=range.createTable();
            range.AddRow();
            }
        catch(ex)
        {
        alert(ex);
        }
    },
    removeAll : function()
    {
        if(document.querySelector("#rangeOfAge .col-sm-10").children.length!=0) {
            var element = document.querySelector("#rangeOfAge .col-sm-10");
            element.removeChild(element.children[0]);
            element.removeChild(element.children[0]);
            var selection = document.querySelector("#check-age");
            selection.checked = false;
        }
    },
    clicked : function()
    {
        window.setTimeout(function(){
        var ele=document.querySelector("#particulars .results");
            ele.innerHTML="";
        },5000);
    },
    searchPin : function(value)
    {
        var city=document.querySelector("#city-val").value;
        try {
            if (city == "") {
                e.target.checked=false;
                throw "CANNOT BE LEFT BLANK :#city";
            }
            else
            {

            }
        }
        catch(E)
        {
            alert(E);
        }
    },
    submitCoupon : function()
    {
        var registrationPanel = new RegistrationPanel("#forms");
    try {
        var couponName = document.querySelector("#input2");
        var coupon=document.querySelector("#couponName");
        validator.checkData(couponName.value,/^[a-zA-Z0-9\s]+$/,"#couponName .col-sm-10","Enter the Coupon-Name");
        var discount_Val=document.querySelector("#Discount-val");
        var discount=document.querySelector("#discount");
        validator.checkData(discount_Val.value,/^([0-9]+(\.[0-9]+)?)$/,"#discount .col-sm-10","Enter the Discount Amount");
        validator.checkData(discount_Val.getAttribute("data-type"),/amount|percent/,"#discount .col-sm-10","Entered type is not valid");
        var cashbackVal=document.querySelector("#CashBack-val");
        var cashback=document.querySelector("#cashBack");
        validator.checkData(cashbackVal.value,/^([0-9]+(\.[0-9]+)?)$/,"#cashBack .col-sm-10","ENTER THE CASHBACK AMOUNT");
        validator.checkData(cashbackVal.getAttribute("data-type"),/amount|percent/,"#cashBack .col-sm-10","Entered type is not valid");
        var shippingDiscount=document.querySelector("#Shipping-val");
        var shipping=document.querySelector("#shipping");
        validator.checkData(shippingDiscount.value,/^([0-9]+(\.[0-9]+)?)$/,"#shipping .col-sm-10","ENTER THE SHIPPING DISCOUNT");
        validator.checkData(shippingDiscount.getAttribute("data-type"),/amount|percent/,"#shipping .col-sm-10","Entered type is not valid");
        var convinenceDiscount=document.querySelector("#Convenience-val");
        var convenience=document.querySelector("#convenience");
        validator.checkData(convinenceDiscount.value,/^([0-9]+(\.[0-9]+)?)$/,"#convenience .col-sm-10","ENTER THE CONVINENCE DISCOUNT");
        validator.checkData(convinenceDiscount.getAttribute("data-type"),/amount|percent/,"#convenience .col-sm-10","Entered type is not valid");
        var usageDiv=document.querySelector("#coponUsage label");
        validator.checked("#coponUsage label","#coponUsage","PLEASE SELECT ONE OF THE OPTION",
            function(data){
            if(document.querySelector("#"+data).checked==true && data!="ALL")
            {
              var element=document.querySelector("#selectedVal .col-sm-10");
                if(element.children.length==0)
                {
                    throw "Not a valid Value:#coponUsage";
                }
            }
        });
        var couponcode=document.querySelector("#couponCode");
        var CodeCoupon=document.querySelector("#code");
        validator.checkData(couponcode.value,/^[a-zA-Z0-9]+/,"#code .col-sm-10","ENTER A VALID COUPON CODE");
        var usage=document.querySelector("#numbers label");
        validator.checked("#numbers label","#numbers","ENTER A VALID NUMBER OF USAGE",function(data)
        {
        if(document.querySelector("#"+data).checked==true && data=="peoples" )
        {
            var element=document.querySelector("#numbers .col-sm-10");
            var input=element.children[0];
            validator.checkData(input.value,/^[0-9]+$/,"#numbers .col-sm-10","ENTER A VALID NUMBER");
        }
        });
        var startDate=document.querySelector("#start-date-picker");
        var lifetime=document.querySelector("#ends label input");
        if(lifetime.checked==false)
        {
            var endDate=document.querySelector("#date-picker");
            validator.dateValidator(startDate.value,endDate.value,"START DATE VALUE MUST LESS THAN END-DATE","#starts .col-sm-10");
        }
        validator.checked("#age-group label","#age-group","SELECT AGE GROUPS",function(data){
           if(document.querySelector("#"+data).checked==true && data=="check-age")
           {
               var element=document.querySelector("#rangeOfAge .col-sm-10 #adding-more-table");
               var last=element.lastElementChild;
               var inputBox=last.querySelectorAll("td input");
               for(var i=0;i<inputBox.length;i++)
               {
                if(inputBox[i].value=="")
                {
                    throw "CANT BE LEFT BLANK :#rangeOfAge";
                }
               }
           }
        });
        var codeDiv=document.querySelector("#Code-div .col-sm-10");
        if(codeDiv.children.length==0)
        {
            throw "ENTER A VALID ZIPCODE :#AreaCode .col-sm-10";
        }
        if(this.couponCode==1)
        {
            throw "COUPON CODE ALREADY EXISTS: #code .col-sm-10";
        }
        if(this.Name==1)
        {
            throw "COUPON NAME ALREADY EXISTS: #couponName .col-sm-10";
        }
        this.CreateCoupon();
        }
    catch(e)
    {
        registrationPanel.MessageDiv(e);
    }
    },
    CouponCheck : function(e)
    {
        var registrationPanel = new RegistrationPanel("#forms");
        var code= e.target.value;
        if(code!="") {
                Request.url = "controller/alchol.php";
                Request.method = "POST";
                Request.setRequest("couponCode", code);
                Request.createRequest({
                    open: function (xhr) {

                    },
                    loading: function (xhr) {

                    },
                    progress: function (xhr) {

                    },
                    load: function (xhr) {
                        try {
                            var data = JSON.parse(xhr.responseText);
                            if (data.status == 0) {
                                Coupon.couponCode = 1;
                                throw "Coupon Code Already Exists:#code .col-sm-10";
                            }
                            else
                            {
                                Coupon.couponCode=0;
                            }
                        }
                        catch (e)
                        {
                        registrationPanel.MessageDiv(e);
                        }
                    },
                    error: function (xhr) {

                    }
                });
        }
    },
    couponName : function(e)
    {
        var registrationPanel = new RegistrationPanel("#forms");
        var name= e.target.value;
        if(name!="")
        {
            Request.url = "controller/alchol.php";
            Request.method = "POST";
            Request.setRequest("couponNameCheck", name);
            Request.createRequest({
                open: function (xhr) {

                },
                loading: function (xhr) {

                },
                progress: function (xhr) {

                },
                load: function (xhr) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data.status == 0) {
                            Coupon.Name = 1;
                            throw "Coupon Name Already Exists: #couponName .col-sm-10";
                        }
                        else
                        {
                            Coupon.Name=0;
                        }
                    }
                    catch (e)
                    {
                        registrationPanel.MessageDiv(e);
                    }
                },
                error: function (xhr) {

                }
            });
        }
    },
    CreateCoupon : function()
    {
        var formData=new FormData();
        var type='';
        var restaurant=[];
        var deals=[];
        var events=[];
        var age=[];
        var times=0;
        var pincode=[];
        var couponName=document.querySelector("#input2").value;
        formData.append("name",couponName);
        var discount=document.querySelector("#Discount-val");
        var discountType=discount.getAttribute("data-type");
        formData.append("discountType",discountType);
        var discountVal=discount.value;
        formData.append("discountValue",discountVal);
        var cashBack=document.querySelector("#CashBack-val");
        var cashBackVal=cashBack.value;
        var cashBackType=cashBack.getAttribute("data-type");
        formData.append("cashBackType",cashBackType);
        formData.append("cashBackAmount",cashBackVal);
        var shippingDisc=document.querySelector("#Shipping-val");
        var shippingDiscVal=shippingDisc.value;
        var shippingDiscType=shippingDisc.getAttribute("data-type");
        formData.append("shippingType",shippingDiscType);
        formData.append("shippingValue",shippingDiscVal);
        var convinence=document.querySelector("#Convenience-val");
        var convinenceDisc=convinence.value;
        var convinenceType=convinence.getAttribute("data-type");
        formData.append("convinenceType",convinenceType);
        formData.append("convinenceValue",convinenceDisc);
        var couponAvailableFor=document.querySelectorAll("#coponUsage label");
        var totalAvailable=couponAvailableFor.length;
        for(var i=0;i<totalAvailable;i++)
        {
            if(couponAvailableFor[i].children[0].getAttribute("id")=="ALL" && couponAvailableFor[i].children[0].checked==true)
            {
            type +="all&";
            }
            if(couponAvailableFor[i].children[0].getAttribute("id")!="ALL") {
                if (couponAvailableFor[i].children[0].getAttribute("id") == "DEALS" && couponAvailableFor[i].children[0].checked == true) {
                    type += "deals&";
                }
                if (couponAvailableFor[i].children[0].getAttribute("id") == "EVENTS" && couponAvailableFor[i].children[0].checked == true) {
                    type += "events&";
                }
                if (couponAvailableFor[i].children[0].getAttribute("id") == "numbersSelect" && couponAvailableFor[i].children[0].checked == true) {
                    type += "restaurant&";
                }

            }
        }
        formData.append("couuponfor",type.substring(0,type.length-1));
        if(document.querySelector("#ALL").checked!=true)
        {
            var selectedVal=document.querySelectorAll("#selectedVal .col-sm-10 div");
            for(var j=0;j<selectedVal.length;j++)
            {
                if(String(selectedVal[j].getAttribute("data-type"))=="restaurant")
                {
                restaurant.push(selectedVal[j].querySelector("a").getAttribute("href"));
                }
                if(String(selectedVal[j].getAttribute("data-type"))=="event")
                {
                    events.push(selectedVal[j].querySelector("a").getAttribute("href"));
                }
                if(String(selectedVal[j].getAttribute("data-type"))=="deal")
                {
                    deals.push(selectedVal[j].querySelector("a").getAttribute("href"));
                }
            }
        }
        formData.append("restaurant",restaurant.join('&'));
        formData.append("event",events.join('&'));
        formData.append("deals",deals.join('&'));
        var couponcode=document.querySelector("#couponCode").value;
        formData.append("code",couponcode);
        var usage=document.querySelectorAll("#numbers label");
        for(var k=0;k<usage.length;k++)
        {
            if(usage[k].children[0].getAttribute("id")=="once" && usage[k].children[0].checked==true)
            {
            times=1;
            }
            if(usage[k].children[0].getAttribute("id")=="peoples" && usage[k].children[0].checked==true)
            {
                times=Number(document.querySelector("#numbers .col-sm-10 input").value);
            }
            if(usage[k].children[0].getAttribute("id")=="infinite" && usage[k].children[0].checked==true)
            {
                times=-1;
            }
        }
        formData.append("usage",times);
        var startDate=document.querySelector("#start-date-picker").value;
        formData.append("start",startDate);
        var expires=document.querySelector("#ends .expires");
        if(expires.children[0].checked==false)
        {
            formData.append("expires",document.querySelector("#date-picker").value);
        }
        else
        {
            formData.append("expires","lifetime");
        }
        var ages=document.querySelectorAll("#age-group label");
        for(var l=0;l<ages.length;l++)
        {
            if(ages[l].children[0].getAttribute("id")=="check-age" && ages[l].children[0].checked==true)
            {
            var tables=document.querySelectorAll("#adding-more-table .out");
                for(var n=0;n<tables.length;n++)
                {
                    var min=Number(tables[n].children[0].querySelector("input").value);
                    var max=Number(tables[n].children[1].querySelector("input").value);
                    age.push(min+'||'+max);
                    formData.append('ageGroups',age.join(','));
                }
                break;
            }
            else
            {
                formData.append('ageGroups',"all");
            }
        }
        var maritalStatus=document.querySelector("#Mstatus");
        var index=maritalStatus.selectedIndex;
        var val=maritalStatus[index].innerHTML;
        formData.append("status",val);
        var pin=document.querySelectorAll("#Code-div .col-sm-10 div");
        for(var o=0;o<pin.length;o++)
        {
            pincode.push(pin[o].childNodes[1].nodeValue);
        }
        formData.append("pincode",pincode.join('&'));
        formData.append("request1","CouponCreate");
        Request.url="controller/alchol.php";
        Request.req=formData;
        Request.method="POST";
        Request.FormRequest({
        open:function(xhr)
        {

        },
        loading: function(xhr)
        {
            var loader=document.querySelector("#loader");
            loader.style.display="block";
        },
        progress : function(xhr)
        {

        },
        load : function(xhr)
        {
        var loader=document.querySelector("#loader");
            loader.style.display="none";
        var data=JSON.parse(xhr.responseText);
        var specific=document.querySelector("#selectedVal .col-sm-10");
        specific.innerHTML="";
        var res=document.querySelector("#particulars");
        res.innerHTML="";
        if(document.querySelector("#numbers div"))
        {
            document.querySelector("#numbers").removeChild(document.querySelector("#numbers div.col-sm-10"));
        }
        var ageRange=document.querySelector("#rangeOfAge div");
        ageRange.innerHTML="";
        var Code_div=document.querySelector("#Code-div div");
         Code_div.innerHTML="";
        if(data.status==1)
        {
            var form=document.querySelector(".container-padding form");
         form.reset();
         alert("Coupon Created SuccessFully");
        }
        },
        error : function(arg)
        {

        }
        });
    }

};
var Request={
    req : '',
    url : '',
    method :'',
    out:{},
    createRequest : function(callback)
    {
        var xhr=new XMLHttpRequest();
        xhr.onreadystatechange=function(e)
        {
            switch (xhr.readyState)
            {
                case 0 :callback.open(xhr);
                    break;
                case 1: callback.loading(xhr);
                    break;
                case 2 : callback.progress(xhr);
                    break;
                case 3 : callback.progress(xhr);
                    break;
                case 4 : callback.load(xhr);
                    break;
                default : callback.error(-1);
                    break;
            }
        };
    xhr.open(this.method,this.url,true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send(this.req);
    },
    setRequest : function()
    {
        var string='';
        for(var i=1;i<=arguments.length;i++)
        {
            string +='request'+i+'='+arguments[i-1]+'&'
        }
        this.req=string.substr(0,string.length-1);
    },
    FormRequest : function(callback)
    {
        var xhr=new XMLHttpRequest();
        xhr.onreadystatechange=function(e)
        {
            switch (xhr.readyState)
            {
                case 0 :callback.open(xhr);
                    break;
                case 1: callback.loading(xhr);
                    break;
                case 2 : callback.progress(xhr);
                    break;
                case 3 : callback.progress(xhr);
                    break;
                case 4 : callback.load(xhr);
                    break;
                default : callback.error(-1);
                    break;
            }
        };
        xhr.open(this.method,this.url,true);
        xhr.send(this.req);
    }
};
var validator = {
    checkData : function(data,pattern,div,message)
    {
        if(!pattern.test(data)) {
            throw message+':'+div;
        }
    },
    checked : function(main,pardiv,message,callback)
    {
        var count=0;
        var div=document.querySelectorAll(main);
        var total=div.length;
        for(var i=0;i<total;i++)
        {
            var element=div[i].children[0];
            if(element.checked==true)
            {
                count++;
            }
            callback(element.getAttribute("id"));
        }
        if(count==0)
        {
            throw message+':'+pardiv;
        }
    },
    dateValidator : function(dateA,dateB,message,div)
    {
        var start=this.dateSeperator(dateA,div);
        var startYear=start[0];
        var startMonth=start[1];
        var startDate=start[2];
        var end=this.dateSeperator(dateB,div);
        var endYear=end[0];
        var endMonth=end[1];
        var endDate=end[2];
        if(startYear > endYear)
        {
            throw message+":"+div;
        }
        if(startYear==endYear)
        {
            if(startMonth > endMonth)
            {
                throw message+":"+div;
            }
        }
        if((startYear==endYear)&&(startMonth==endMonth))
        {
            if(startDate > endDate)
            {
                throw message+":"+div;
            }
        }
    },
    timeFormat:function(date,div)
    {
        if(date=="")
        {
            throw "Cannot Be Left Blank :"+div
        }

    },
    dateSeperator : function(date,div)
    {
        if(date!="") {
            var dateFormat = new Date(date);
            return [dateFormat.getFullYear(), dateFormat.getMonth(), dateFormat.getDate()];
        }
        else
        {
            throw "Cannot Be Left Blank :"+div;
        }
    }
};