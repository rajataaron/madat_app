/**
 * Created by niteshkumar on 19/12/15.
 */
window.addEventListener("load",function(e)
{
var path=window.location.pathname.split('/');
    if(path[path.length-1]=="approval.php")
    {
    Notification.startNotification();
    }
});
var Notification={
    startNotification : function()
    {
        window.setInterval(this.checkNotification,50000);
    },
    checkNotification : function()
    {
      Ajax.url="controller/alchol.php";
      Ajax.setRequest('RegistrationNotification');
      Ajax.loadEncodedReq(function(xhr)
      {
        if(xhr.readyState<4)
        {

        }
        else {

        }
      });
    }
};
var Ajax={
    url : '',
    req : '',
    loadEncodedReq :function(callback) {
        var xhr;
        try {
            xhr=new XMLHttpRequest();
        } catch (e) {
            alert("unable to connect");
        }
        xhr.onreadystatechange = dataLoader;
        function dataLoader()
        {
            if(xhr.readyState < 4)
            {
                callback(xhr,xhr.readyState);
            }
            if(xhr.status!=200)
            {
                callback(xhr,-1);
            }
            if(xhr.readyState==4)
            {
                callback(xhr,xhr.readyState);
            }
        }
        xhr.open("POST",this.url,true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.send(this.req);
    },
    setRequest : function()
    {
        var string='';
        for(var i=1;i<=arguments.length;i++)
        {
            string +='request'+i+'='+arguments[i-1]+'&'
        }
        this.req=string.substr(0,string.length-1);
    },
    loadFormData :function(form,callback) {
        var xhr;
        try {
            xhr=new XMLHttpRequest();
        } catch (e) {
            alert("unable to coneect");
        }
        xhr.onreadystatechange = dataLoader;
        function dataLoader()
        {
            if(xhr.readyState < 4)
            {
                callback(xhr,xhr.readyState);
            }
            if(xhr.status!=200)
            {
                callback(xhr,-1);
            }
            if(xhr.readyState==4)
            {
                callback(xhr,xhr.readyState);
            }
        }
        xhr.open("POST",this.url,true);
        xhr.send(form);
    },
    createFrame : function()
    {
        if(!document.getElementById("progress")) {
            var body = document.getElementsByTagName("body")[0];
            var neighbour = body.firstElementChild;
            body.insertBefore(this.createBlack(), neighbour);
        }
    },
    createBlack :function()
    {
        var layer=document.createElement("div");
        layer.setAttribute("class","loading");
        layer.style.display="block";
        layer.style.opacity=0.7;
        layer.setAttribute("id","progress");
        var image=document.createElement("img");
        image.setAttribute("src","img/ajax-loader.gif");
        layer.appendChild(image);
        return layer;
    }
};