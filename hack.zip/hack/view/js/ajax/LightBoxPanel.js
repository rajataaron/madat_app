/**
 * Created by niteshkumar on 01/12/15.
 */
function LightBoxPanel(panelName,type,accept)
{
    this.name=panelName;
    this.type=type;
    this.accept=accept;
}
LightBoxPanel.prototype={
  constructor : LightBoxPanel,
  createBody : function()
  {
      if(!document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0]) {
          var accept=this.accept;
          var panelName=this.name;
          var base = this.createDiv(function (div) {
              div.setAttribute("class", "_10 uiLayer _4-hy _3qw");
              div.style.top = "180px";
              return div;
          });
          var innerLayer = this.createDiv(function (div) {
              div.setAttribute("class", "_59s7");
              return div;
          });
          var header = this.createDiv(function (div) {
              div.setAttribute("class", "_4-hz");
              return div;
          });
          var opacity = this.createDiv(function (div) {
              div.style.opacity = 1;
              div.style.width = "100%";
              return div;
          });
          var openDiv = this.createDiv(function (div) {
              return div;
          });
          var openDivHeader = this.createDiv(function (div) {
              div.setAttribute("id", "u_1_0");
              div.setAttribute("class", "_4-i0");
              return div;
          });
          var openDivHeaderChild = this.createDiv(function (div) {
              div.setAttribute("class", "clearfix");
              return div;
          });
          var clearFxChild = this.createDiv(function (div) {
              div.setAttribute("class", "lfloat _ohe");
              var h3 = document.createElement("h3");
              h3.setAttribute("class", "_52c9");
              h3.innerHTML = panelName;
              div.appendChild(h3);
              return div;
          });
          var floatRight = this.createDiv(function (div) {
              div.setAttribute("class", "_51-u rfloat _ohf");
              var a = document.createElement("a");
              a.setAttribute("class", "_42ft _5upp _50zy layerCancel _51-t _50-0 _50z-");
              a.addEventListener("click", function (e) {
                  LightBoxPanel.prototype.close.call(LightBoxPanel, e);
              });
              a.innerHTML = "[x]";
              div.appendChild(a);
              return div;
          });
          openDivHeaderChild.appendChild(clearFxChild);
          openDivHeaderChild.appendChild(floatRight);
          openDivHeader.appendChild(openDivHeaderChild);
          openDiv.appendChild(openDivHeader);
          var middleSec = this.createDiv(function (div) {
              div.setAttribute("id", "u_1_1");
              div.setAttribute("class", "_4-i2 _50f4");
              return div;
          });
          var middleChild = this.createDiv(function (div) {
              div.setAttribute("class", "_5h2b _4w61");
              var i = document.createElement("i");
              i.setAttribute("class", "fa fa-plus");
              div.appendChild(i);
              var span = document.createElement("span");
              span.setAttribute("class", "_17w8 _c24 _50f5 _50f7");
              span.innerHTML = panelName;
              div.appendChild(span);
              return div;
          });
          var middleInnerChild = this.createDiv(function (div) {
              div.setAttribute("id", "u_1_2");
              div.setAttribute("class", "_6a _5u5j _m autofocus _5uar");
              var a = document.createElement("a");
              a.setAttribute("id", "u_1_3");
              a.setAttribute("class", "_3cia");
              var div1 = document.createElement("div");
              div1.setAttribute("class", "_3jk");
              var form = document.createElement("form");
              form.setAttribute("id", "profile-pic");
              form.setAttribute("enctype", "multipart/form-data");
              var inputFile = document.createElement("input");
              inputFile.setAttribute("id", "js_3");
              inputFile.setAttribute("class", "_n _5f0v");
              inputFile.setAttribute("type", "file");
              inputFile.setAttribute("accept", accept);
              form.appendChild(inputFile);
              div1.appendChild(form);
              a.appendChild(div1);
              div.appendChild(a);
              return div;
          });
          middleChild.appendChild(middleInnerChild);
          middleSec.appendChild(middleChild);
          openDiv.appendChild(middleSec);
          var a = document.createElement("a");
          a.setAttribute("id", "u_1_3");
          a.setAttribute("class", "_3cia");
          a.appendChild(this.createButton(function (btn) {
              btn.addEventListener("click", function (e) {
                  LightBoxPanel.prototype.listen.call(LightBoxPanel, e);
              });
          }));
          openDiv.appendChild(a);
          opacity.appendChild(openDiv);
          header.appendChild(opacity);
          innerLayer.appendChild(header);
          base.appendChild(innerLayer);
          return base;
      }
  },
  createDiv : function(outPut)
    {
     var div=document.createElement("div");
      outPut(div);
      return div;
    },
    listen : function(e)
    {
    e.preventDefault();
        EventManager.upload(e);
    },
    createButton : function(button)
    {
        var btn = document.createElement("button");
        btn.setAttribute("id","display_pic");
        btn.setAttribute("class","btn-submit");
        btn.setAttribute("type","submit");
        btn.innerHTML="Send";
        button(btn);
        return btn;
    },
    close : function()
    {
    var top =document.getElementsByTagName("body")[0];
        if(document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0])
        {
        top.removeChild(document.getElementsByClassName("_10 uiLayer _4-hy _3qw")[0]);
        }
    },
    message : function(message,icon,body,result)
    {
            var div =document.createElement("div");
            div.setAttribute("class","kode-alert kode-alert-icon alert3 mcd");
            var i=document.createElement("i");
            i.setAttribute("class",icon);
            div.appendChild(i);
            var a=document.createElement("a");
            //a.addEventListener("click",);
            a.setAttribute("class","closed");
            a.innerHTML='x';
            div.appendChild(a);
            var text=document.createTextNode(message);
            div.appendChild(text);
            result(div);
            window.setTimeout(function() {
                var alert_box=body.children[1];
                body.removeChild(alert_box);
            },3000);

    }
};