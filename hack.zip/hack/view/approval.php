<?php require_once'menu_sidebar/menu.php';
head();
?>
<!-- END SIDEBAR -->
<!-- //////////////////////////////////////////////////////////////////////////// --> 

 <!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTENT -->
<div class="content">

  <!-- Start Page Header -->
  <div class="page-header">


    <!-- Start Page Header Right Div -->

    <!-- End Page Header Right Div -->

  </div>
  <!-- End Page Header -->

  <!-- Start Presentation -->

  <!-- End Presentation -->


 <!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START CONTAINER -->
<div class="container-padding">


  <!-- Start Row -->
  <div class="row">

    <!-- Start Panel -->
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-title">
          Approval Table
        </div>
        <div class="panel-body table-responsive">
        Search:<input type="search" id="searchkey" list="search-key"/>
          <div id="search-result" class="search-list">
     <div id="search-value" class="search-results">
       <ul></ul>
     </div>
            </div>
          <table class="table table-hover">
            <thead>
              <tr>
                <td class="text-center"><i class="fa fa-sort-amount-desc"></i></td>
                <td>Client ID</td>
                <td>Restaurant Name</td>
                <td>Client Name</td>
                <td>Date</td>
                <td>Active/Inactive</td>
                <td>Featured/Non-Featured</td>
                <td>Rating</td>
              </tr>
            </thead>
            <tbody id="tabs">
            <?php require_once'panel_controls/class.restaurantapproval.php';
            $obj=new restaurantApproval();
            $res=$obj->showRestaurants();
            foreach($res as $row)
            {
              $id=$row->getValue('rid');
              $encid=$row->getEncoded('rid');
            ?>
              <tr>
                <td class="text-center"><div class="checkbox margin-t-0"><input id="<?php echo $id;?>" type="checkbox"><label for="checkbox1"></label></div></td>
                <td> <b><?php echo $row->getValue('rid');?></b></td>
                <td><a href="restaurants.php?id=<?php echo $encid ?>"><?php echo $row->getValue('rname'); ?></a></td>
                <td><?php echo $row->getValue('username'); ?></td>
                <td><?php $stamp=$row->getValue('doreg'); $date_string=strtotime($stamp); $date=getdate($date_string);
                  $day=$date['mday'];
                  $mon=$date['mon'];
                  $year=$date['year'];
                  echo $day.'/'.$mon.'/'.$year;
                  ?></td>
                <?php $approve=$row->getValue('active_status'); if($approve==0){ ?>
                <td> <button type="button" id="approved<?php echo $id;?>" class="btn btn-default" onclick="approve('<?php echo $id; ?>')"> Approve</button> </td>
                <?php } else { ?>
                  <td> <button type="button" id="reject<?php echo $id;?>" class="btn btn-default" onclick="reject('<?php echo $id; ?>')"> Reject</button> </td>
                <?php } ?>
                <?php $featured=$row->getValue('featured_status');if($featured==0){?>
                <td> <button type="button" id="featured<?php echo $id;?>" class="btn btn-default" onclick="nonfeatured('<?php echo $id ?>')">Featured</button></td>
                <?php }
                else{?>
                    <td><button type="button" id="un-featured<?php echo $id;?>" class="btn btn-default" onclick="featured('<?php echo $id;?>')">Non-Featured</button></td>
                <?php }?>
                <td><select id="change_select<?php echo $id;?>" onchange="change_rating('<?php echo $id; ?>')" data-id="<?php echo $id; ?>" name="rating">
                    <?php $rate=$row->getValue('rating');
                    for($i=0;$i<=5;$i++){?>
                      <option value="<?php echo $i;?>"<?php if($i==$rate) echo 'selected'; ?>><?php echo $i ?></option><?php }?>
                  </select> </td>
              </tr>
            <?php }?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
    <!-- End Panel -->

    <!-- Start Panel -->
   <!-- <div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          Striped rows
        </div>

        <div class="panel-body table-responsive">
          <p>Use <code>.table-striped</code> to add zebra-striping to any table row within the <code>&lt;tbody&gt;</code>.</p>

          <table class="table table-striped">
            <thead>
              <tr>
                <td>Order ID</td>
                <td>Product</td>
                <td>Buyer</td>
                <td>Date</td>
                <td>Order Note</td>
                <td>Payment</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td># <b>9652</b></td>
                <td>Kode Gaming Laptop</td>
                <td>John Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
              <tr>
                <td># <b>1963</b></td>
                <td>New Season Jacket</td>
                <td>Jane Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Paypal</td>
              </tr>
              <tr>
                <td># <b>9652</b></td>
                <td>IO Mouse</td>
                <td>Jonathan Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
              <tr>
                <td># <b>9651</b></td>
                <td>Doe Bike</td>
                <td>Jonathan Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
              <tr>
                <td># <b>6962</b></td>
                <td>Zets Baseball Bat</td>
                <td>Jonathan Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
    <!-- End Panel -->


    <!-- Start Panel -->
    <!--<div class="col-md-12">
      <div class="panel panel-default">

        <div class="panel-title">
          Bordered table
        </div>

        <div class="panel-body">
          <p>Add <code>.table-bordered</code> for borders on all sides of the table and cells.</p>

          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <td>Order ID</td>
                <td>Product</td>
                <td>Buyer</td>
                <td>Date</td>
                <td>Order Note</td>
                <td>Payment</td>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td># <b>9652</b></td>
                <td>Kode Gaming Laptop</td>
                <td>John Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
              <tr>
                <td># <b>1963</b></td>
                <td>New Season Jacket</td>
                <td>Jane Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Paypal</td>
              </tr>
              <tr>
                <td># <b>9652</b></td>
                <td>IO Mouse</td>
                <td>Jonathan Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
              <tr>
                <td># <b>9651</b></td>
                <td>Doe Bike</td>
                <td>Jonathan Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
              <tr>
                <td># <b>6962</b></td>
                <td>Zets Baseball Bat</td>
                <td>Jonathan Doe</td>
                <td>12/10/2015</td>
                <td>As we got further and further away, it [the Earth] diminished in size.</td>
                <td>Credit Card</td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
    <!-- End Panel -->

    <!-- Start Panel -->
    <!--   <div class="col-md-12">
        <div class="panel panel-default">

          <div class="panel-title">
            Contextual classes
          </div>

          <div class="panel-body">
            <p>Use contextual classes to color table rows or individual cells.</p>
            <table class="table table-bordered table-striped">
              <colgroup>
                <col class="col-xs-1">
                <col class="col-xs-7">
              </colgroup>
              <thead>
                <tr>
                  <th>Class</th>
                  <th>Description</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">
                    <code>.active</code>
                  </th>
                  <td>Applies the hover color to a particular row or cell</td>
                </tr>
                <tr>
                  <th scope="row">
                    <code>.success</code>
                  </th>
                  <td>Indicates a successful or positive action</td>
                </tr>
                <tr>
                  <th scope="row">
                    <code>.info</code>
                  </th>
                  <td>Indicates a neutral informative change or action</td>
                </tr>
                <tr>
                  <th scope="row">
                    <code>.warning</code>
                  </th>
                  <td>Indicates a warning that might need attention</td>
                </tr>
                <tr>
                  <th scope="row">
                    <code>.danger</code>
                  </th>
                  <td>Indicates a dangerous or potentially negative action</td>
                </tr>
              </tbody>
            </table>

              <br>

             <table class="table">
               <thead>
                 <tr>
                   <td>Order ID</td>
                   <td>Product</td>
                   <td>Buyer</td>
                   <td>Date</td>
                   <td>Order Note</td>
                   <td>Payment</td>
                 </tr>
               </thead>
               <tbody>
                <tr class="active">
                   <td># <b>9652</b></td>
                   <td >Kode Gaming Laptop</td>
                   <td>John Doe</td>
                   <td>12/10/2015</td>
                   <td>As we got further and further away, it [the Earth] diminished in size.</td>
                   <td>Credit Card</td>
                 </tr>
                 <tr class="success">
                   <td># <b>1963</b></td>
                   <td>New Season Jacket</td>
                   <td>Jane Doe</td>
                   <td>12/10/2015</td>
                   <td>As we got further and further away, it [the Earth] diminished in size.</td>
                   <td>Paypal</td>
                 </tr>
                 <tr class="warning">
                   <td># <b>9652</b></td>
                   <td>IO Mouse</td>
                   <td>Jonathan Doe</td>
                   <td>12/10/2015</td>
                   <td>As we got further and further away, it [the Earth] diminished in size.</td>
                   <td>Credit Card</td>
                 </tr>
                 <tr class="danger">
                   <td># <b>9651</b></td>
                   <td>Doe Bike</td>
                   <td>Jonathan Doe</td>
                   <td>12/10/2015</td>
                   <td>As we got further and further away, it [the Earth] diminished in size.</td>
                   <td>Credit Card</td>
                 </tr>
                 <tr class="info">
                   <td># <b>6962</b></td>
                   <td>Zets Baseball Bat</td>
                   <td>Jonathan Doe</td>
                   <td>12/10/2015</td>
                   <td>As we got further and further away, it [the Earth] diminished in size.</td>
                   <td>Credit Card</td>
                 </tr>
               </tbody>
             </table>
         </div>

       </div>
     </div>-->
     <!-- End Panel -->







  </div>
  <!-- End Row -->






</div>
<!-- END CONTAINER -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 


<!-- Start Footer -->
<div class="row footer">
  <div class="col-md-6 text-left">
  Copyright © 2015 deception All rights reserved.
  </div>
  <!--<div class="col-md-6 text-right">
    Design and Developed by <a href="https://www.credanceinfotech.com" target="_blank">Credance Infotech Pvt. Ltd.</a>
  </div>-->
</div>
<!-- End Footer -->


</div>
<!-- End Content -->
 <!-- //////////////////////////////////////////////////////////////////////////// --> 

<!-- //////////////////////////////////////////////////////////////////////////// --> 
<!-- START SIDEPANEL -->
<div role="tabpanel" class="sidepanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#today" aria-controls="today" role="tab" data-toggle="tab">TODAY</a></li>
    <li role="presentation"><a href="#tasks" aria-controls="tasks" role="tab" data-toggle="tab">TASKS</a></li>
    <li role="presentation"><a href="#chat" aria-controls="chat" role="tab" data-toggle="tab">CHAT</a></li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">

    <!-- Start Today -->
    <div role="tabpanel" class="tab-pane active" id="today">

      <div class="sidepanel-m-title">
        Today
        <span class="left-icon"><a href="#"><i class="fa fa-refresh"></i></a></span>
        <span class="right-icon"><a href="#"><i class="fa fa-file-o"></i></a></span>
      </div>

      <div class="gn-title">NEW</div>

      <ul class="list-w-title">
        <li>
          <a href="#">
            <span class="label label-danger">ORDER</span>
            <span class="date">9 hours ago</span>
            <h4>New Jacket 2.0</h4>
            Etiam auctor porta augue sit amet facilisis. Sed libero nisi, scelerisque.
          </a>
        </li>
        <li>
          <a href="#">
            <span class="label label-success">COMMENT</span>
            <span class="date">14 hours ago</span>
            <h4>Bill Jackson</h4>
            Etiam auctor porta augue sit amet facilisis. Sed libero nisi, scelerisque.
          </a>
        </li>
        <li>
          <a href="#">
            <span class="label label-info">MEETING</span>
            <span class="date">at 2:30 PM</span>
            <h4>Developer Team</h4>
            Etiam auctor porta augue sit amet facilisis. Sed libero nisi, scelerisque.
          </a>
        </li>
        <li>
          <a href="#">
            <span class="label label-warning">EVENT</span>
            <span class="date">3 days left</span>
            <h4>Birthday Party</h4>
            Etiam auctor porta augue sit amet facilisis. Sed libero nisi, scelerisque.
          </a>
        </li>
      </ul>

    </div>
    <!-- End Today -->

    <!-- Start Tasks -->
    <div role="tabpanel" class="tab-pane" id="tasks">

      <div class="sidepanel-m-title">
        To-do List
        <span class="left-icon"><a href="#"><i class="fa fa-pencil"></i></a></span>
        <span class="right-icon"><a href="#"><i class="fa fa-trash"></i></a></span>
      </div>

      <div class="gn-title">TODAY</div>

      <ul class="todo-list">
        <li class="checkbox checkbox-primary">
          <input id="checkboxside1" type="checkbox"><label for="checkboxside1">Add new products</label>
        </li>
        
        <li class="checkbox checkbox-primary">
          <input id="checkboxside2" type="checkbox"><label for="checkboxside2"><b>May 12, 6:30 pm</b> Meeting with Team</label>
        </li>
        
        <li class="checkbox checkbox-warning">
          <input id="checkboxside3" type="checkbox"><label for="checkboxside3">Design Facebook page</label>
        </li>
        
        <li class="checkbox checkbox-info">
          <input id="checkboxside4" type="checkbox"><label for="checkboxside4">Send Invoice to customers</label>
        </li>
        
        <li class="checkbox checkbox-danger">
          <input id="checkboxside5" type="checkbox"><label for="checkboxside5">Meeting with developer team</label>
        </li>
      </ul>

      <div class="gn-title">TOMORROW</div>
      <ul class="todo-list">
        <li class="checkbox checkbox-warning">
          <input id="checkboxside6" type="checkbox"><label for="checkboxside6">Redesign our company blog</label>
        </li>
        
        <li class="checkbox checkbox-success">
          <input id="checkboxside7" type="checkbox"><label for="checkboxside7">Finish client work</label>
        </li>
        
        <li class="checkbox checkbox-info">
          <input id="checkboxside8" type="checkbox"><label for="checkboxside8">Call Johnny from Developer Team</label>
        </li>

      </ul>
    </div>    
    <!-- End Tasks -->

    <!-- Start Chat -->
    <div role="tabpanel" class="tab-pane" id="chat">

      <div class="sidepanel-m-title">
        Friend List
        <span class="left-icon"><a href="#"><i class="fa fa-pencil"></i></a></span>
        <span class="right-icon"><a href="#"><i class="fa fa-trash"></i></a></span>
      </div>

      <div class="gn-title">ONLINE MEMBERS (3)</div>
      <ul class="group">
        <li class="member"><a href="#"><img src="img/profileimg.png" alt="img"><b>Allice Mingham</b>Los Angeles</a><span class="status online"></span></li>
        <li class="member"><a href="#"><img src="img/profileimg2.png" alt="img"><b>James Throwing</b>Las Vegas</a><span class="status busy"></span></li>
        <li class="member"><a href="#"><img src="img/profileimg3.png" alt="img"><b>Fred Stonefield</b>New York</a><span class="status away"></span></li>
        <li class="member"><a href="#"><img src="img/profileimg4.png" alt="img"><b>Chris M. Johnson</b>California</a><span class="status online"></span></li>
      </ul>

      <div class="gn-title">OFFLINE MEMBERS (8)</div>
     <ul class="group">
        <li class="member"><a href="#"><img src="img/profileimg5.png" alt="img"><b>Allice Mingham</b>Los Angeles</a><span class="status offline"></span></li>
        <li class="member"><a href="#"><img src="img/profileimg6.png" alt="img"><b>James Throwing</b>Las Vegas</a><span class="status offline"></span></li>
      </ul>

      <form class="search">
        <input type="text" class="form-control" placeholder="Search a Friend...">
      </form>
    </div>
    <!-- End Chat -->

  </div>

</div>
<!-- END SIDEPANEL -->
<!-- //////////////////////////////////////////////////////////////////////////// --> 



<!-- ================================================
jQuery Library
================================================ -->

<!-- ================================================
Bootstrap Core JavaScript File
================================================ -->

<!-- ================================================
Plugin.js - Some Specific JS codes for Plugin Settings
================================================ -->
<script type="text/javascript" src="js/Approval.js"></script>
<script type="text/javascript" src="js/ajax.js"></script>

</body>
</html>