<?php
/**
 * Created by PhpStorm.
 * User: Nitesh
 * Date: 19-05-2015
 * Time: 11:07
 */
function head()
{?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Kode is a Premium Bootstrap Admin Template, It's responsive, clean coded and mobile friendly">
    <meta name="keywords" content="bootstrap, admin, dashboard, flat admin template, responsive," />
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <link rel="stylesheet" href="css/plugin/font-awesome-4.5.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/ajax/ajax.js"></script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" rel="stylesheet" />
    <script type="text/javascript" src="js/maps/maps.js"></script>
    <title>Admin</title>
    <?php require_once 'panel_controls/class.session.php';
  session::start();
    $user=session::get('username');
    ?>
    <!-- ========== Css Files ========== -->
    <link href="css/root.css" rel="stylesheet">


</head>
<body>
<!-- Start Page Loading -->
<div id="loader" class="loading"><img src="img/loading.gif" alt="loading-img"></div>
<!-- End Page Loading -->
<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START TOP -->
<div id="top" class="clearfix">

    <!-- Start App Logo -->
    <div class="applogo">
        <a href="#" class="logo">Gopartynow</a>
    </div>
    <!-- End App Logo -->

    <!-- Start Sidebar Show Hide Button -->
    <a href="#" class="sidebar-open-button"><i class="fa fa-bars"></i></a>
    <a href="#" class="sidebar-open-button-mobile"><i class="fa fa-bars"></i></a>
    <!-- End Sidebar Show Hide Button -->

    <!-- Start Searchbox -->
    <form class="searchform">
        <input type="text" class="searchbox" id="searchbox" placeholder="Search">
        <span class="searchbutton"><i class="fa fa-search"></i></span>
    </form>
    <!-- End Searchbox -->

    <!-- Start Top Menu -->
    <ul class="topmenu">
        <li><a href="#">Files</a></li>
        <li><a href="#">Authors</a></li>
        <li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">My Files <span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><a href="#">Videos</a></li>
                <li><a href="#">Pictures</a></li>
                <li><a href="#">Blog Posts</a></li>
            </ul>
        </li>
    </ul>
    <!-- End Top Menu -->

    <!-- Start Sidepanel Show-Hide Button -->
    <a href="#sidepanel" class="sidepanel-open-button"><i class="fa fa-outdent"></i></a>
    <!-- End Sidepanel Show-Hide Button -->

    <!-- Start Top Right -->
    <ul class="top-right">

        <li class="dropdown link">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle hdbutton">Create New <span class="caret"></span></a>
            <ul class="dropdown-menu dropdown-menu-list">
                <li><a><i class="fa falist fa-paper-plane-o"></i>Add States</a></li>
                <li><a><i class="fa falist fa-font"></i>Add Cities</a></li>
                <li><a href="#"><i class="fa falist fa-file-image-o"></i>Image Gallery</a></li>
                <li><a href="#"><i class="fa falist fa-file-video-o"></i>Video Gallery</a></li>
            </ul>
        </li>

        <li id="notification" class="link">
            <a href="#" class="notifications">
            </a>
        </li>
        
        <li class="dropdown link">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle profilebox"><b><?php
                    if(isset($_SESSION['username']) && ($_SESSION['username']!==null))
                    {
                        echo $user;
                    }
                    else{
                        echo '<script>window.location.assign(index.phtmll")</script>';

                    }
                    ?></b><span class="caret"></span></a>
            <ul class="dropdown-menu dropdown-menu-list dropdown-menu-right">
                <li role="presentation" class="dropdown-header">Profile</li>
                <li><a href="#"><i class="fa falist fa-inbox"></i>Inbox<span class="badge label-danger">4</span></a></li>
                <li><a href="#"><i class="fa falist fa-file-o"></i>Files</a></li>
                <li><a href="#"><i class="fa falist fa-wrench"></i>Settings</a></li>
                <li class="divider"></li>
                <li><a href="#"><i class="fa falist fa-lock"></i> Lockscreen</a></li>
                <li><a onclick="logout();"><i class="fa falist fa-power-off"></i> Logout</a></li>
            </ul>
        </li>

    </ul>
    <!-- End Top Right -->

</div>
<!-- END TOP -->
<!-- //////////////////////////////////////////////////////////////////////////// -->


<!-- //////////////////////////////////////////////////////////////////////////// -->
<!-- START SIDEBAR -->
<div class="sidebar clearfix">

    <ul class="sidebar-panel nav">
        <li class="sidetitle">MAIN</li>
        <li><a href="approval.php"><span class="icon color11"><i class="fa fa-diamond"></i></span>Approve Restaurants</a></li>
        <li><a href="eventmanager.php"><span class="icon color5"><i class="fa fa-home"></i></span>Approve Manager<span class="label label-default"></span></a></li>
        <li><a href="register.php"><span class="icon color6"><i class="fa fa-envelope-o"></i></span>Create-SubAdmin</a></li>
        <li><a href="subadmin.php"><span class="icon color7"><i class="fa fa-flask"></i></span>View-SubAdmin</a></li>
        <li><a href="cupon.php"><span class="icon color8"><i class="fa fa-bar-chart"></i></span>coupon</a></li>
        <li><a href="deals.php"><span class="icon color9"><i class="fa fa-th"></i></span>View Deals</a></li>
        <li><a href="events.php"><span class="icon color10"><i class="fa fa-check-square-o"></i></span>View Events</a></li>
        <li><a href="#"><span class="icon color8"><i class="fa fa-calendar-o"></i></span>Calendar</a></li>
        <li><a href="#"><span class="icon color12"><i class="fa fa-font"></i></span>Typography</a></li>
        <li><a href="#"><span class="icon color14"><i class="fa fa-paper-plane-o"></i></span>Extra Pages</a></li>
    </ul>
</div>
<?php }?>