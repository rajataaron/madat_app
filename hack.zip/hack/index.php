<?php
/**
 * Created by PhpStorm.
 * User: niteshkumar
 * Date: 17/03/16
 * Time: 12:50
 */
use App\user\userRegister\controller\Register;
use App\Police\policeHeadquater\controller as police;
use App\user\userLogin\controller\Login;
use App\user\userComplain\controller\emergency;
use App\User\userComplain\controller\Register as fir;
use App\police\policeRegister\controller\addLocation;
use App\police\Assign\controller\policeAssign;

require_once "vendor/autoload.php";
$data = json_decode(file_get_contents('php://input'), true);
switch($data['req'])
{
    case 'Complain':
        $obj = new police\stateChange('stateChange',array('complain'=>$data['complainId'],'state'=>$data['val']));
        $obj->secureHandler();
        break;
    case 'xml':
        $obj=new Register('Register',array('email'=>$data['email'],'phone'=>$data['phone'],'imei'=>$data['imei'],'name'=>$data['name'],'qrCode'=>$data['qrCode']));
        $obj->secureHandler();
        break;
    case 'login':
        $obj=new Login('Login',array('email'=>$data['email'],'password'=>$data['password']));
        $obj->secureHandler();
        break;
    case 'emergency':
        $obj = new emergency\emergency('emergency',array('aadhar'=>$data['aadhar'],'xCo'=>$data['xCo'],'yCo'=>$data['yCo']));
        $obj->secureHandler();
        break;
    case 'fir':
        $obj=new fir('fir',array('aadhar'=>$data['aadhar'],'sub'=>$data['sub'],'msg'=>$data['msg'],'xCo'=>$data['xCo'],'yCo'=>$data['yCo'],'img'=>$data['img']));
        $obj->secureHandler();
        break;
    case 'update':
        $obj=new addLocation('location',array('imei'=>$data['imei'],'xCo'=>$data['xCo'],'yCo'=>$data['yCo']));
        $obj->secureHandler();
        break;
    case "ComplainAssign":
        $obj = new policeAssign('assign',array('com_id'=>$data['complainId']));
        $obj->secureHandler();
        break;


}